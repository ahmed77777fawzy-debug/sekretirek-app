const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write appointments, tasks, memos, or contacts", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection(`users/${ALICE_UID}/appointments`).get()
  );
  await assertFails(
    unauthDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").set({
      userId: ALICE_UID,
      title: "Unauthorized",
      dateKey: "2026-11-20",
      startMinute: 540,
      endMinute: 600,
      allDay: false,
      category: "MEETING",
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      completed: false,
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/tasks`).get());
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/memos`).get());
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/contacts`).get());
});

test("Owner: valid Kotlin appointment with linkedContactIds create, partial update, and delete succeed; invalid payloads fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").set({
      userId: ALICE_UID,
      title: "Quarterly Board Sync",
      dateKey: "2026-11-20",
      startMinute: 600,
      endMinute: 660,
      allDay: false,
      category: "MEETING",
      location: "Conference Room B",
      attendees: "Elena Rostova, Marcus Vance",
      linkedContactIds: ["contact_1", "contact_2"],
      notes: "Bring Q4 forecast",
      reminderEnabled: true,
      reminderMinutesBefore: 30,
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").update({
      completed: true,
      linkedContactIds: ["contact_1"],
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field & @DocumentId 'id' injection
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_2").set({
      id: "appt_2",
      userId: ALICE_UID,
      title: "Shadow",
      dateKey: "2026-11-20",
      startMinute: 600,
      endMinute: 660,
      allDay: false,
      category: "MEETING",
      reminderEnabled: false,
      reminderMinutesBefore: 0,
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject endMinute <= startMinute
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_3").set({
      userId: ALICE_UID,
      title: "Invalid time",
      dateKey: "2026-11-20",
      startMinute: 700,
      endMinute: 600,
      allDay: false,
      category: "CALL",
      reminderEnabled: false,
      reminderMinutesBefore: 0,
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject immutable createdAt mutation
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").delete()
  );
});

test("Cross-user isolation: Bob cannot read or modify Alice's appointments, tasks, memos, or contacts", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const now = new Date(Date.now() - 10000);
    await db.collection(`users/${ALICE_UID}/appointments`).doc("a1").set({
      userId: ALICE_UID,
      title: "Confidential 1:1",
      dateKey: "2026-11-20",
      startMinute: 540,
      endMinute: 570,
      allDay: false,
      category: "MEETING",
      reminderEnabled: true,
      reminderMinutesBefore: 10,
      completed: false,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/tasks`).doc("t1").set({
      userId: ALICE_UID,
      title: "Review contract",
      priority: "HIGH",
      completed: false,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/memos`).doc("m1").set({
      userId: ALICE_UID,
      title: "Board Notes",
      body: "Key takeaways",
      pinned: true,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/contacts`).doc("c1").set({
      userId: ALICE_UID,
      name: "Elena Rostova",
      role: "VP Strategy",
      company: "Northstar Capital",
      email: "elena@northstar.example",
      phone: "+1 555-0192",
      category: "CLIENT",
      notes: "Prefers morning briefings",
      favorite: true,
      createdAt: now,
      updatedAt: now,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection(`users/${ALICE_UID}/appointments`).get());
  await assertFails(
    bobDb.collection(`users/${ALICE_UID}/appointments`).doc("a1").get()
  );
  await assertFails(
    bobDb
      .collection(`users/${ALICE_UID}/appointments`)
      .doc("a1")
      .update({ title: "Hijacked" })
  );
  await assertFails(bobDb.collection(`users/${ALICE_UID}/tasks`).get());
  await assertFails(bobDb.collection(`users/${ALICE_UID}/memos`).get());
  await assertFails(bobDb.collection(`users/${ALICE_UID}/contacts`).get());
  await assertFails(
    bobDb.collection(`users/${ALICE_UID}/contacts`).doc("c1").get()
  );

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/appointments`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/tasks`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/memos`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/contacts`).get());
});

test("Owner: task creation, agenda linking, editing, and completion succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/tasks`).doc("task_1").set({
      userId: ALICE_UID,
      title: "Prepare quarterly deck",
      details: "Include revenue slides",
      dueDateKey: "2026-11-20",
      linkedAppointmentId: "appt_1",
      linkedAppointmentTitle: "Quarterly Board Sync",
      priority: "HIGH",
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/tasks`).doc("task_1").update({
      completed: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/tasks`).doc("task_1").update({
      userId: BOB_UID,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Owner: contact create, favorite update, delete, and invalid schema rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_1").set({
      userId: ALICE_UID,
      name: "Marcus Vance",
      role: "General Counsel",
      company: "Vance Advisory",
      email: "marcus@vance.example",
      phone: "+1 555-0148",
      location: "450 Market St, San Francisco",
      category: "LEADERSHIP",
      notes: "Send agenda 24h prior",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_1").update({
      favorite: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject oversized location (>200 chars)
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_long_loc").set({
      userId: ALICE_UID,
      name: "Long Location",
      location: "x".repeat(201),
      category: "PERSONAL",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject invalid category enum
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_bad").set({
      userId: ALICE_UID,
      name: "Invalid Group",
      category: "UNKNOWN_GROUP",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject ghost field
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_ghost").set({
      id: "contact_ghost",
      userId: ALICE_UID,
      name: "Ghost Field",
      category: "PERSONAL",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_1").delete()
  );
});
