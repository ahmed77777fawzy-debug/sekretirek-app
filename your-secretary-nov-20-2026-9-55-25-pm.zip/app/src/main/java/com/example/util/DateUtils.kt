package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class MonthGridCell(
    val dateKey: String,
    val dayOfMonth: Int,
    val inCurrentMonth: Boolean
)

object DateUtils {
    private val dateKeyRegex = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")

    fun todayDateKey(): String = calendarToDateKey(Calendar.getInstance())

    fun isValidDateKey(dateKey: String): Boolean = dateKeyRegex.matches(dateKey)

    fun calendarToDateKey(cal: Calendar): String {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
    }

    fun dateKeyToCalendar(dateKey: String): Calendar {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (!isValidDateKey(dateKey)) return cal
        val parts = dateKey.split("-")
        cal.set(Calendar.YEAR, parts[0].toInt())
        cal.set(Calendar.MONTH, parts[1].toInt() - 1)
        cal.set(Calendar.DAY_OF_MONTH, parts[2].toInt())
        return cal
    }

    fun dateKeyToUtcMidnightMillis(dateKey: String): Long {
        val parts = if (isValidDateKey(dateKey)) dateKey.split("-") else return System.currentTimeMillis()
        val utc = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        utc.set(Calendar.YEAR, parts[0].toInt())
        utc.set(Calendar.MONTH, parts[1].toInt() - 1)
        utc.set(Calendar.DAY_OF_MONTH, parts[2].toInt())
        utc.set(Calendar.HOUR_OF_DAY, 0)
        utc.set(Calendar.MINUTE, 0)
        utc.set(Calendar.SECOND, 0)
        utc.set(Calendar.MILLISECOND, 0)
        return utc.timeInMillis
    }

    fun utcMidnightMillisToDateKey(utcMillis: Long): String {
        val utc = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        utc.timeInMillis = utcMillis
        val y = utc.get(Calendar.YEAR)
        val m = utc.get(Calendar.MONTH) + 1
        val d = utc.get(Calendar.DAY_OF_MONTH)
        return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
    }

    fun shiftDateKey(dateKey: String, deltaDays: Int): String {
        val cal = dateKeyToCalendar(dateKey)
        cal.add(Calendar.DAY_OF_MONTH, deltaDays)
        return calendarToDateKey(cal)
    }

    fun shiftMonth(dateKey: String, deltaMonths: Int): String {
        val cal = dateKeyToCalendar(dateKey)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, deltaMonths)
        return calendarToDateKey(cal)
    }

    fun weekDateKeys(anchorDateKey: String): List<String> {
        val cal = dateKeyToCalendar(anchorDateKey)
        // Align to Monday
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val daysFromMonday = when (dow) {
            Calendar.MONDAY -> 0
            Calendar.TUESDAY -> 1
            Calendar.WEDNESDAY -> 2
            Calendar.THURSDAY -> 3
            Calendar.FRIDAY -> 4
            Calendar.SATURDAY -> 5
            Calendar.SUNDAY -> 6
            else -> 0
        }
        cal.add(Calendar.DAY_OF_MONTH, -daysFromMonday)
        return List(7) { idx ->
            val key = calendarToDateKey(cal)
            if (idx < 6) cal.add(Calendar.DAY_OF_MONTH, 1)
            key
        }
    }

    fun monthGridCells(anchorDateKey: String): List<MonthGridCell> {
        val cal = dateKeyToCalendar(anchorDateKey)
        val targetMonth = cal.get(Calendar.MONTH)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val firstDow = cal.get(Calendar.DAY_OF_WEEK)
        // Monday-first grid offset (0..6)
        val leadingDays = when (firstDow) {
            Calendar.MONDAY -> 0
            Calendar.TUESDAY -> 1
            Calendar.WEDNESDAY -> 2
            Calendar.THURSDAY -> 3
            Calendar.FRIDAY -> 4
            Calendar.SATURDAY -> 5
            Calendar.SUNDAY -> 6
            else -> 0
        }
        cal.add(Calendar.DAY_OF_MONTH, -leadingDays)
        return List(42) {
            val cell = MonthGridCell(
                dateKey = calendarToDateKey(cal),
                dayOfMonth = cal.get(Calendar.DAY_OF_MONTH),
                inCurrentMonth = cal.get(Calendar.MONTH) == targetMonth
            )
            cal.add(Calendar.DAY_OF_MONTH, 1)
            cell
        }
    }

    fun formatFullDate(dateKey: String): String {
        val cal = dateKeyToCalendar(dateKey)
        return SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(cal.time)
    }

    fun formatMonthYear(dateKey: String): String {
        val cal = dateKeyToCalendar(dateKey)
        return SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
    }

    fun formatShortDate(dateKey: String): String {
        val cal = dateKeyToCalendar(dateKey)
        return SimpleDateFormat("MMM d", Locale.getDefault()).format(cal.time)
    }

    fun dayOfWeekShort(dateKey: String): String {
        val cal = dateKeyToCalendar(dateKey)
        return SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time)
    }

    fun dayNumber(dateKey: String): Int {
        val cal = dateKeyToCalendar(dateKey)
        return cal.get(Calendar.DAY_OF_MONTH)
    }

    fun formatMinuteOfDay(minute: Int): String {
        val clamped = minute.coerceIn(0, 1440)
        val hour24 = (clamped / 60) % 24
        val min = clamped % 60
        val amPm = if (hour24 < 12) "AM" else "PM"
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        return String.format(Locale.US, "%d:%02d %s", hour12, min, amPm)
    }

    fun formatTimeRange(startMinute: Long, endMinute: Long, allDay: Boolean): String {
        if (allDay) return "All day"
        return "${formatMinuteOfDay(startMinute.toInt())} – ${formatMinuteOfDay(endMinute.toInt())}"
    }

    fun formatReminderLabel(minutesBefore: Long): String = when (minutesBefore) {
        0L -> "At time of event"
        10L -> "10 min before"
        15L -> "15 min before"
        30L -> "30 min before"
        60L -> "1 hour before"
        1440L -> "1 day before"
        else -> "$minutesBefore min before"
    }

    fun computeReminderTriggerMillis(
        dateKey: String,
        startMinute: Long,
        minutesBefore: Long
    ): Long? {
        if (!isValidDateKey(dateKey)) return null
        val cal = dateKeyToCalendar(dateKey)
        val startMinInt = startMinute.toInt().coerceIn(0, 1439)
        cal.set(Calendar.HOUR_OF_DAY, startMinInt / 60)
        cal.set(Calendar.MINUTE, startMinInt % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis - (minutesBefore * 60_000L)
    }

    fun greetingPrefix(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
    }
}
