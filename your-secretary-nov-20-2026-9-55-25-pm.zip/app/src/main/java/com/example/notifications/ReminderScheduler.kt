package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.model.Appointment
import com.example.util.DateUtils

class ReminderScheduler(context: Context) {
    private val appContext = context.applicationContext
    private val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    init {
        ReminderBroadcastReceiver.ensureNotificationChannel(appContext)
    }

    fun syncReminders(appointments: List<Appointment>) {
        appointments.forEach { appointment ->
            if (appointment.reminderEnabled && !appointment.completed && appointment.id.isNotBlank()) {
                scheduleForAppointment(appointment)
            } else if (appointment.id.isNotBlank()) {
                cancelReminder(appointment.id)
            }
        }
    }

    fun scheduleForAppointment(appointment: Appointment) {
        if (!appointment.reminderEnabled || appointment.completed || appointment.id.isBlank()) {
            if (appointment.id.isNotBlank()) cancelReminder(appointment.id)
            return
        }
        val effectiveStartMinute = if (appointment.allDay) 540L else appointment.startMinute
        val triggerMillis = DateUtils.computeReminderTriggerMillis(
            dateKey = appointment.dateKey,
            startMinute = effectiveStartMinute,
            minutesBefore = appointment.reminderMinutesBefore
        ) ?: return

        if (triggerMillis <= System.currentTimeMillis()) {
            cancelReminder(appointment.id)
            return
        }

        val pendingIntent = buildPendingIntent(
            appointmentId = appointment.id,
            title = appointment.title,
            timeLabel = DateUtils.formatTimeRange(
                appointment.startMinute,
                appointment.endMinute,
                appointment.allDay
            ),
            location = appointment.location
        )

        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerMillis,
            pendingIntent
        )
    }

    fun cancelReminder(appointmentId: String) {
        if (appointmentId.isBlank()) return
        val pendingIntent = buildPendingIntent(
            appointmentId = appointmentId,
            title = "",
            timeLabel = "",
            location = ""
        )
        alarmManager.cancel(pendingIntent)
    }

    private fun buildPendingIntent(
        appointmentId: String,
        title: String,
        timeLabel: String,
        location: String
    ): PendingIntent {
        val intent = Intent(appContext, ReminderBroadcastReceiver::class.java).apply {
            action = "com.example.ACTION_APPOINTMENT_REMINDER.$appointmentId"
            putExtra(ReminderBroadcastReceiver.EXTRA_APPOINTMENT_ID, appointmentId)
            putExtra(ReminderBroadcastReceiver.EXTRA_TITLE, title)
            putExtra(ReminderBroadcastReceiver.EXTRA_TIME_LABEL, timeLabel)
            putExtra(ReminderBroadcastReceiver.EXTRA_LOCATION, location)
        }
        return PendingIntent.getBroadcast(
            appContext,
            appointmentId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
