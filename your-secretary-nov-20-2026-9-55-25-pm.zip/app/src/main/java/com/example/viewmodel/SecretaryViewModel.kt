package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SecretaryAiRepository
import com.example.data.SecretaryRepository
import com.example.model.AiActionProposal
import com.example.model.Appointment
import com.example.model.AppointmentCategory
import com.example.model.ChatMessage
import com.example.model.ContactGroup
import com.example.model.ExecutiveMemo
import com.example.model.ProposalKind
import com.example.model.ScheduleViewMode
import com.example.model.SecretaryContact
import com.example.model.SecretaryTask
import com.example.model.SmartBriefingState
import com.example.model.TaskPriority
import com.example.model.UiState
import com.example.notifications.ReminderScheduler
import com.example.util.DateUtils
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.UUID

class SecretaryViewModel(
    private val repository: SecretaryRepository,
    private val aiRepository: SecretaryAiRepository,
    private val reminderScheduler: ReminderScheduler,
    private val currentUserId: String,
    val userDisplayName: String
) : ViewModel() {

    val appointmentsState: StateFlow<UiState<List<Appointment>>> =
        repository.observeAppointments(currentUserId)
            .onEach { list -> reminderScheduler.syncReminders(list) }
            .map<List<Appointment>, UiState<List<Appointment>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing appointments", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load schedule"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val tasksState: StateFlow<UiState<List<SecretaryTask>>> =
        repository.observeTasks(currentUserId)
            .map<List<SecretaryTask>, UiState<List<SecretaryTask>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing tasks", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load tasks"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val memosState: StateFlow<UiState<List<ExecutiveMemo>>> =
        repository.observeMemos(currentUserId)
            .map<List<ExecutiveMemo>, UiState<List<ExecutiveMemo>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing memos", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load memos"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val contactsState: StateFlow<UiState<List<SecretaryContact>>> =
        repository.observeContacts(currentUserId)
            .map<List<SecretaryContact>, UiState<List<SecretaryContact>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing contacts", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load contacts"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    private val _selectedDateKey = MutableStateFlow(DateUtils.todayDateKey())
    val selectedDateKey: StateFlow<String> = _selectedDateKey.asStateFlow()

    private val _scheduleViewMode = MutableStateFlow(ScheduleViewMode.DAY)
    val scheduleViewMode: StateFlow<ScheduleViewMode> = _scheduleViewMode.asStateFlow()

    private val _smartBriefingState = MutableStateFlow<SmartBriefingState>(SmartBriefingState.Idle)
    val smartBriefingState: StateFlow<SmartBriefingState> = _smartBriefingState.asStateFlow()

    private val _isParsingCommand = MutableStateFlow(false)
    val isParsingCommand: StateFlow<Boolean> = _isParsingCommand.asStateFlow()

    private val _pendingProposal = MutableStateFlow<AiActionProposal?>(null)
    val pendingProposal: StateFlow<AiActionProposal?> = _pendingProposal.asStateFlow()

    private val _commandError = MutableStateFlow<String?>(null)
    val commandError: StateFlow<String?> = _commandError.asStateFlow()

    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "welcome",
                isUser = false,
                text = "Good day, ${userDisplayName.substringBefore(" ").ifBlank { "Executive" }}. Ask me to review your week, find open time slots, draft meeting follow-ups, or prepare for upcoming appointments."
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _draftingMemoId = MutableStateFlow<String?>(null)
    val draftingMemoId: StateFlow<String?> = _draftingMemoId.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    private var briefingJob: Job? = null
    private var chatJob: Job? = null
    private var hasAutoGeneratedBriefing = false

    init {
        viewModelScope.launch {
            combine(appointmentsState, tasksState) { appts, tasks -> appts to tasks }
                .collect { (appts, tasks) ->
                    if (!hasAutoGeneratedBriefing &&
                        appts is UiState.Success &&
                        tasks is UiState.Success
                    ) {
                        val todayKey = DateUtils.todayDateKey()
                        val hasTodayAppts = appts.data.any { it.dateKey == todayKey }
                        val hasPendingTasks = tasks.data.any { !it.completed }
                        if (hasTodayAppts || hasPendingTasks) {
                            hasAutoGeneratedBriefing = true
                            generateSmartDailyBriefing()
                        }
                    }
                }
        }
    }

    fun selectDate(dateKey: String) {
        if (DateUtils.isValidDateKey(dateKey)) {
            _selectedDateKey.value = dateKey
        }
    }

    fun jumpToToday() {
        _selectedDateKey.value = DateUtils.todayDateKey()
    }

    fun setScheduleViewMode(mode: ScheduleViewMode) {
        _scheduleViewMode.value = mode
    }

    fun navigatePeriod(forward: Boolean) {
        val step = if (forward) 1 else -1
        val current = _selectedDateKey.value
        _selectedDateKey.value = when (_scheduleViewMode.value) {
            ScheduleViewMode.DAY -> DateUtils.shiftDateKey(current, step)
            ScheduleViewMode.WEEK -> DateUtils.shiftDateKey(current, step * 7)
            ScheduleViewMode.MONTH -> DateUtils.shiftMonth(current, step)
        }
    }

    fun saveAppointment(
        existingId: String?,
        title: String,
        dateKey: String,
        startMinute: Int,
        endMinute: Int,
        allDay: Boolean,
        category: AppointmentCategory,
        location: String,
        attendees: String,
        linkedContactIds: List<String> = emptyList(),
        notes: String,
        reminderEnabled: Boolean,
        reminderMinutesBefore: Int,
        completed: Boolean = false
    ) {
        viewModelScope.launch {
            val result = repository.saveAppointment(
                existingId = existingId,
                title = title,
                dateKey = dateKey,
                startMinute = startMinute,
                endMinute = endMinute,
                allDay = allDay,
                category = category,
                location = location,
                attendees = attendees,
                linkedContactIds = linkedContactIds,
                notes = notes,
                reminderEnabled = reminderEnabled,
                reminderMinutesBefore = reminderMinutesBefore,
                completed = completed
            )
            result.onSuccess { savedId ->
                val savedModel = Appointment(
                    id = savedId,
                    userId = currentUserId,
                    title = title.trim(),
                    dateKey = dateKey,
                    startMinute = if (allDay) 0L else startMinute.toLong(),
                    endMinute = if (allDay) 1440L else endMinute.toLong(),
                    allDay = allDay,
                    category = category.name,
                    location = location.trim(),
                    attendees = attendees.trim(),
                    linkedContactIds = linkedContactIds,
                    notes = notes.trim(),
                    reminderEnabled = reminderEnabled,
                    reminderMinutesBefore = reminderMinutesBefore.toLong(),
                    completed = completed
                )
                if (reminderEnabled && !completed) {
                    reminderScheduler.scheduleForAppointment(savedModel)
                    _snackbarMessages.tryEmit("Appointment saved with reminder")
                } else {
                    reminderScheduler.cancelReminder(savedId)
                    _snackbarMessages.tryEmit("Appointment saved")
                }
            }.onFailure { error ->
                _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to save appointment")
            }
        }
    }

    fun linkContactToAppointment(contact: SecretaryContact, appointment: Appointment) {
        if (contact.id.isBlank() || appointment.id.isBlank()) return
        val updatedIds = (appointment.linkedContactIds + contact.id).distinct().take(25)
        val existingNames = appointment.attendees
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
        val nextAttendees = if (existingNames.any { it.equals(contact.name, ignoreCase = true) }) {
            appointment.attendees
        } else {
            (existingNames + contact.name).joinToString(", ").take(300)
        }
        viewModelScope.launch {
            repository.updateAppointmentLinkedContacts(appointment.id, updatedIds, nextAttendees)
                .onSuccess { _snackbarMessages.tryEmit("Linked ${contact.name} to ${appointment.title}") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to link contact")
                }
        }
    }

    fun unlinkContactFromAppointment(contact: SecretaryContact, appointment: Appointment) {
        if (contact.id.isBlank() || appointment.id.isBlank()) return
        val updatedIds = appointment.linkedContactIds.filterNot { it == contact.id }
        val nextAttendees = appointment.attendees
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.equals(contact.name, ignoreCase = true) }
            .joinToString(", ")
            .take(300)
        viewModelScope.launch {
            repository.updateAppointmentLinkedContacts(appointment.id, updatedIds, nextAttendees)
                .onSuccess { _snackbarMessages.tryEmit("Removed ${contact.name} from ${appointment.title}") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to unlink contact")
                }
        }
    }

    fun toggleAppointmentCompleted(appointment: Appointment) {
        viewModelScope.launch {
            val nextCompleted = !appointment.completed
            repository.toggleAppointmentCompleted(appointment.id, nextCompleted)
                .onSuccess {
                    if (nextCompleted) {
                        reminderScheduler.cancelReminder(appointment.id)
                    } else if (appointment.reminderEnabled) {
                        reminderScheduler.scheduleForAppointment(appointment.copy(completed = false))
                    }
                }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Could not update appointment")
                }
        }
    }

    fun deleteAppointment(appointmentId: String) {
        viewModelScope.launch {
            reminderScheduler.cancelReminder(appointmentId)
            repository.deleteAppointment(appointmentId)
                .onSuccess { _snackbarMessages.tryEmit("Appointment deleted") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to delete appointment")
                }
        }
    }

    fun saveTask(
        existingId: String?,
        title: String,
        details: String,
        dueDateKey: String,
        linkedAppointmentId: String = "",
        linkedAppointmentTitle: String = "",
        priority: TaskPriority,
        completed: Boolean = false
    ) {
        viewModelScope.launch {
            repository.saveTask(
                existingId = existingId,
                title = title,
                details = details,
                dueDateKey = dueDateKey,
                linkedAppointmentId = linkedAppointmentId,
                linkedAppointmentTitle = linkedAppointmentTitle,
                priority = priority,
                completed = completed
            )
                .onSuccess { _snackbarMessages.tryEmit("Task saved") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to save task")
                }
        }
    }

    fun toggleTaskCompleted(task: SecretaryTask) {
        viewModelScope.launch {
            repository.toggleTaskCompleted(task.id, !task.completed)
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Could not update task")
                }
        }
    }

    fun deleteTask(taskId: String) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
                .onSuccess { _snackbarMessages.tryEmit("Task deleted") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to delete task")
                }
        }
    }

    fun saveMemo(
        existingId: String?,
        title: String,
        body: String,
        pinned: Boolean,
        aiDraft: String = ""
    ) {
        viewModelScope.launch {
            repository.saveMemo(existingId, title, body, pinned, aiDraft)
                .onSuccess { _snackbarMessages.tryEmit("Memo saved") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to save memo")
                }
        }
    }

    fun toggleMemoPinned(memo: ExecutiveMemo) {
        viewModelScope.launch {
            repository.toggleMemoPinned(memo.id, !memo.pinned)
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Could not update memo")
                }
        }
    }

    fun deleteMemo(memoId: String) {
        viewModelScope.launch {
            repository.deleteMemo(memoId)
                .onSuccess { _snackbarMessages.tryEmit("Memo deleted") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to delete memo")
                }
        }
    }

    fun saveContact(
        existingId: String?,
        name: String,
        role: String,
        company: String,
        email: String,
        phone: String,
        location: String = "",
        group: ContactGroup,
        notes: String,
        favorite: Boolean = false,
        onSavedId: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            repository.saveContact(
                existingId = existingId,
                name = name,
                role = role,
                company = company,
                email = email,
                phone = phone,
                location = location,
                group = group,
                notes = notes,
                favorite = favorite
            )
                .onSuccess { savedId ->
                    _snackbarMessages.tryEmit("Contact saved")
                    onSavedId?.invoke(savedId)
                }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to save contact")
                }
        }
    }

    fun toggleContactFavorite(contact: SecretaryContact) {
        viewModelScope.launch {
            repository.toggleContactFavorite(contact.id, !contact.favorite)
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Could not update contact")
                }
        }
    }

    fun deleteContact(contactId: String) {
        viewModelScope.launch {
            repository.deleteContact(contactId)
                .onSuccess { _snackbarMessages.tryEmit("Contact deleted") }
                .onFailure { error ->
                    _snackbarMessages.tryEmit(error.localizedMessage ?: "Failed to delete contact")
                }
        }
    }

    fun generateMemoFollowUpDraft(memo: ExecutiveMemo) {
        if (_draftingMemoId.value != null) return
        viewModelScope.launch {
            _draftingMemoId.value = memo.id
            var latestText = ""
            try {
                aiRepository.streamMemoFollowUpDraft(memo.title, memo.body).collect { partial ->
                    latestText = partial
                }
                if (latestText.isNotBlank()) {
                    repository.updateMemoAiDraft(memo.id, latestText)
                        .onSuccess { _snackbarMessages.tryEmit("Follow-up draft ready") }
                        .onFailure { _snackbarMessages.tryEmit("Could not save draft") }
                } else {
                    _snackbarMessages.tryEmit("Secretary returned an empty draft.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Memo draft timed out", e)
                _snackbarMessages.tryEmit("Draft timed out after 60 seconds. Please retry.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Memo draft failed", e)
                _snackbarMessages.tryEmit(e.localizedMessage ?: "Failed to draft follow-up")
            } finally {
                _draftingMemoId.value = null
            }
        }
    }

    fun generateSmartDailyBriefing() {
        hasAutoGeneratedBriefing = true
        briefingJob?.cancel()
        briefingJob = viewModelScope.launch {
            _smartBriefingState.value = SmartBriefingState.Loading
            val todayKey = DateUtils.todayDateKey()
            val nowCal = Calendar.getInstance()
            val currentMinuteOfDay = nowCal.get(Calendar.HOUR_OF_DAY) * 60 + nowCal.get(Calendar.MINUTE)
            val appts = (appointmentsState.value as? UiState.Success)?.data.orEmpty()
            val todayAppointments = appts.filter { it.dateKey == todayKey }
            val tasks = (tasksState.value as? UiState.Success)?.data.orEmpty()
            val pendingTasks = tasks.filter { !it.completed }

            try {
                val content = aiRepository.generateSmartDailyBriefing(
                    todayDateKey = todayKey,
                    currentMinuteOfDay = currentMinuteOfDay,
                    userName = userDisplayName.ifBlank { "Executive" },
                    todayAppointments = todayAppointments,
                    pendingTasks = pendingTasks
                )
                _smartBriefingState.value = SmartBriefingState.Success(content)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Smart briefing timed out", e)
                _smartBriefingState.value = SmartBriefingState.Error(
                    "Briefing timed out after 60 seconds. Please try again."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Smart briefing failed", e)
                _smartBriefingState.value = SmartBriefingState.Error(
                    e.localizedMessage ?: "Could not prepare your smart daily briefing."
                )
            }
        }
    }

    fun parseQuickCommand(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank() || _isParsingCommand.value) return
        viewModelScope.launch {
            _isParsingCommand.value = true
            _commandError.value = null
            try {
                val proposal = aiRepository.parseNaturalLanguageCommand(trimmed, DateUtils.todayDateKey())
                _pendingProposal.value = proposal
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Quick command timed out", e)
                _commandError.value = "Request timed out after 60 seconds. Please try again."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Quick command parse failed", e)
                _commandError.value = e.localizedMessage ?: "Could not understand command."
            } finally {
                _isParsingCommand.value = false
            }
        }
    }

    fun dismissProposal() {
        _pendingProposal.value = null
        _commandError.value = null
    }

    fun confirmProposal() {
        val proposal = _pendingProposal.value ?: return
        _pendingProposal.value = null
        when (proposal.kind) {
            ProposalKind.APPOINTMENT -> {
                _selectedDateKey.value = proposal.dateKey
                saveAppointment(
                    existingId = null,
                    title = proposal.title,
                    dateKey = proposal.dateKey,
                    startMinute = proposal.startMinute,
                    endMinute = proposal.endMinute,
                    allDay = proposal.allDay,
                    category = proposal.category,
                    location = proposal.location,
                    attendees = proposal.attendees,
                    notes = proposal.notes,
                    reminderEnabled = proposal.reminderEnabled,
                    reminderMinutesBefore = proposal.reminderMinutesBefore
                )
            }
            ProposalKind.TASK -> {
                saveTask(
                    existingId = null,
                    title = proposal.title,
                    details = proposal.notes,
                    dueDateKey = proposal.dateKey,
                    linkedAppointmentId = "",
                    linkedAppointmentTitle = "",
                    priority = proposal.priority
                )
            }
            ProposalKind.MEMO -> {
                saveMemo(
                    existingId = null,
                    title = proposal.title,
                    body = proposal.notes.ifBlank { proposal.title },
                    pinned = false
                )
            }
        }
    }

    fun sendChatMessage(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return
        chatJob?.cancel()

        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            text = trimmed
        )
        val assistantMsgId = UUID.randomUUID().toString()
        val placeholderMsg = ChatMessage(
            id = assistantMsgId,
            isUser = false,
            text = "",
            isStreaming = true
        )
        val historySnapshot = _chatMessages.value
        _chatMessages.value = historySnapshot + userMsg + placeholderMsg

        chatJob = viewModelScope.launch {
            val appts = (appointmentsState.value as? UiState.Success)?.data.orEmpty()
            val tasks = (tasksState.value as? UiState.Success)?.data.orEmpty()
            val memos = (memosState.value as? UiState.Success)?.data.orEmpty()
            var finalText = ""
            try {
                aiRepository.streamSecretaryChat(
                    history = historySnapshot,
                    userMessage = trimmed,
                    todayDateKey = DateUtils.todayDateKey(),
                    appointments = appts,
                    tasks = tasks,
                    memos = memos
                ).collect { accumulated ->
                    finalText = accumulated
                    updateChatMessage(assistantMsgId) {
                        it.copy(text = accumulated, isStreaming = true, isError = false)
                    }
                }
                if (finalText.isNotBlank()) {
                    updateChatMessage(assistantMsgId) {
                        it.copy(text = finalText, isStreaming = false, isError = false)
                    }
                } else {
                    updateChatMessage(assistantMsgId) {
                        it.copy(
                            text = "I didn't receive a response. Please try again.",
                            isStreaming = false,
                            isError = true
                        )
                    }
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Chat timed out", e)
                updateChatMessage(assistantMsgId) {
                    it.copy(
                        text = "Response timed out after 60 seconds. Please try again.",
                        isStreaming = false,
                        isError = true
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Secretary chat failed", e)
                updateChatMessage(assistantMsgId) {
                    it.copy(
                        text = e.localizedMessage ?: "Unable to reach your AI secretary.",
                        isStreaming = false,
                        isError = true
                    )
                }
            }
        }
    }

    private fun updateChatMessage(id: String, transform: (ChatMessage) -> ChatMessage) {
        _chatMessages.update { list ->
            list.map { if (it.id == id) transform(it) else it }
        }
    }

    private companion object {
        const val TAG = "SecretaryVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
