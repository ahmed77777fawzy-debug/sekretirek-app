package com.example.location

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Build
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

object LocationHelper {

    @SuppressLint("MissingPermission")
    suspend fun fetchCurrentLocationLabel(context: Context): Result<String> {
        return try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val cts = CancellationTokenSource()
            val location: Location? = withContext(Dispatchers.IO) {
                runCatching {
                    client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token).await()
                }.getOrNull() ?: runCatching {
                    client.lastLocation.await()
                }.getOrNull()
            }
            if (location == null) {
                return Result.failure(
                    IllegalStateException("Unable to determine current location. Ensure GPS/location is enabled.")
                )
            }
            val addressText = reverseGeocode(context, location.latitude, location.longitude)
            val label = addressText.ifBlank {
                String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            }.take(200)
            Result.success(label)
        } catch (e: SecurityException) {
            Result.failure(IllegalStateException("Location permission is required.", e))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun reverseGeocode(
        context: Context,
        latitude: Double,
        longitude: Double
    ): String = withContext(Dispatchers.IO) {
        if (!Geocoder.isPresent()) return@withContext ""
        val geocoder = Geocoder(context, Locale.getDefault())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            suspendCancellableCoroutine { cont ->
                try {
                    geocoder.getFromLocation(
                        latitude,
                        longitude,
                        1,
                        object : Geocoder.GeocodeListener {
                            override fun onGeocode(addresses: MutableList<Address>) {
                                if (cont.isActive) {
                                    cont.resume(formatAddress(addresses.firstOrNull()))
                                }
                            }

                            override fun onError(errorMessage: String?) {
                                if (cont.isActive) {
                                    cont.resume("")
                                }
                            }
                        }
                    )
                } catch (_: Exception) {
                    if (cont.isActive) cont.resume("")
                }
            }
        } else {
            @Suppress("DEPRECATION")
            val list = runCatching { geocoder.getFromLocation(latitude, longitude, 1) }.getOrNull()
            formatAddress(list?.firstOrNull())
        }
    }

    private fun formatAddress(address: Address?): String {
        if (address == null) return ""
        val line0 = address.getAddressLine(0)?.trim().orEmpty()
        if (line0.isNotBlank()) return line0.take(200)
        return listOfNotNull(
            address.thoroughfare,
            address.locality,
            address.adminArea,
            address.countryName
        ).filter { it.isNotBlank() }.joinToString(", ").take(200)
    }

    fun openLocationInMaps(context: Context, locationQuery: String) {
        val trimmed = locationQuery.trim()
        if (trimmed.isBlank()) return
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(trimmed)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(webIntent) }
            return
        }
        val geoUri = Uri.parse("geo:0,0?q=${Uri.encode(trimmed)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(mapIntent)
        } catch (_: ActivityNotFoundException) {
            val fallbackUri = Uri.parse("https://maps.google.com/?q=${Uri.encode(trimmed)}")
            val fallbackIntent = Intent(Intent.ACTION_VIEW, fallbackUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(fallbackIntent) }
        }
    }
}
