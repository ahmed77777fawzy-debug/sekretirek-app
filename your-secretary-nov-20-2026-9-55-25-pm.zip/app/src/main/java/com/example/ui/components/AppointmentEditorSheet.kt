package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.location.LocationHelper
import com.example.model.Appointment
import com.example.model.AppointmentCategory
import com.example.model.ContactGroup
import com.example.model.SecretaryContact
import com.example.util.DateUtils
import kotlinx.coroutines.launch

private val REMINDER_OPTIONS = listOf(0, 10, 15, 30, 60, 1440)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentEditorSheet(
    initialDateKey: String,
    editingAppointment: Appointment?,
    initialLinkedContactIds: List<String> = emptyList(),
    availableContacts: List<SecretaryContact> = emptyList(),
    onQuickCreateContact: (
        name: String,
        role: String,
        company: String,
        group: ContactGroup,
        onCreated: (String) -> Unit
    ) -> Unit,
    onDismiss: () -> Unit,
    onSave: (
        existingId: String?,
        title: String,
        dateKey: String,
        startMinute: Int,
        endMinute: Int,
        allDay: Boolean,
        category: AppointmentCategory,
        location: String,
        attendees: String,
        linkedContactIds: List<String>,
        notes: String,
        reminderEnabled: Boolean,
        reminderMinutesBefore: Int,
        completed: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val startingContactIds = remember(editingAppointment, initialLinkedContactIds) {
        editingAppointment?.linkedContactIds ?: initialLinkedContactIds
    }
    val initialAttendeeNames = remember(editingAppointment, startingContactIds, availableContacts) {
        val raw = editingAppointment?.attendees.orEmpty()
        if (raw.isNotBlank()) {
            raw
        } else {
            availableContacts
                .filter { it.id in startingContactIds }
                .joinToString(", ") { it.name }
        }
    }

    var title by remember { mutableStateOf(editingAppointment?.title.orEmpty()) }
    var dateKey by remember { mutableStateOf(editingAppointment?.dateKey ?: initialDateKey) }
    var startMinute by remember {
        mutableIntStateOf((editingAppointment?.startMinute ?: 540L).toInt())
    }
    var endMinute by remember {
        mutableIntStateOf((editingAppointment?.endMinute ?: 600L).toInt())
    }
    var allDay by remember { mutableStateOf(editingAppointment?.allDay ?: false) }
    var category by remember {
        mutableStateOf(editingAppointment?.resolvedCategory() ?: AppointmentCategory.MEETING)
    }
    var location by remember { mutableStateOf(editingAppointment?.location.orEmpty()) }
    var attendees by remember { mutableStateOf(initialAttendeeNames) }
    var linkedContactIds by remember { mutableStateOf(startingContactIds) }
    var notes by remember { mutableStateOf(editingAppointment?.notes.orEmpty()) }
    var reminderEnabled by remember { mutableStateOf(editingAppointment?.reminderEnabled ?: true) }
    var reminderMinutesBefore by remember {
        mutableIntStateOf((editingAppointment?.reminderMinutesBefore ?: 15L).toInt())
    }

    var showDatePicker by remember { mutableStateOf(false) }
    var showStartTimePicker by remember { mutableStateOf(false) }
    var showEndTimePicker by remember { mutableStateOf(false) }
    var showContactPicker by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var notificationPermissionNote by remember { mutableStateOf<String?>(null) }
    var isFetchingLocation by remember { mutableStateOf(false) }
    var locationError by remember { mutableStateOf<String?>(null) }

    fun requestCurrentLocation() {
        if (isFetchingLocation) return
        scope.launch {
            isFetchingLocation = true
            locationError = null
            LocationHelper.fetchCurrentLocationLabel(context)
                .onSuccess { resolved ->
                    location = resolved
                }
                .onFailure { err ->
                    locationError = err.localizedMessage ?: "Unable to determine current location."
                }
            isFetchingLocation = false
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true) ||
            (grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
        if (granted) {
            requestCurrentLocation()
        } else {
            locationError = "Location permission denied. You can still type an address or link."
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            notificationPermissionNote =
                "Notification permission was denied. Reminder preference is saved, and you can enable notifications in system settings."
        } else {
            notificationPermissionNote = null
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (editingAppointment == null) "New Appointment" else "Edit Appointment",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it.take(120)
                    validationError = null
                },
                label = { Text("Appointment title") },
                placeholder = { Text("e.g., Q4 Strategy Review with Elena") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("appointment_title_input")
            )

            // Category chips
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Category",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppointmentCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.label) },
                            modifier = Modifier.testTag("category_chip_${cat.name.lowercase()}")
                        )
                    }
                }
            }

            // Date & All Day
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("appointment_date_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CalendarToday,
                        contentDescription = "Select date",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(DateUtils.formatFullDate(dateKey))
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("All day", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = allDay,
                        onCheckedChange = { allDay = it },
                        modifier = Modifier.testTag("appointment_all_day_switch")
                    )
                }
            }

            // Start & End Time Pickers
            if (!allDay) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { showStartTimePicker = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("appointment_start_time_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AccessTime,
                            contentDescription = "Start time",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start: ${DateUtils.formatMinuteOfDay(startMinute)}")
                    }

                    OutlinedButton(
                        onClick = { showEndTimePicker = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("appointment_end_time_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AccessTime,
                            contentDescription = "End time",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("End: ${DateUtils.formatMinuteOfDay(endMinute)}")
                    }
                }
            }

            // Reminder Section
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = "Reminder",
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Column {
                                Text(
                                    text = "Event Reminder",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = if (reminderEnabled) {
                                        DateUtils.formatReminderLabel(reminderMinutesBefore.toLong())
                                    } else {
                                        "No alert scheduled"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = reminderEnabled,
                            onCheckedChange = { enabled ->
                                reminderEnabled = enabled
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    val hasPermission = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!hasPermission) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }
                            },
                            modifier = Modifier.testTag("appointment_reminder_switch")
                        )
                    }

                    if (reminderEnabled) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            REMINDER_OPTIONS.forEach { mins ->
                                FilterChip(
                                    selected = reminderMinutesBefore == mins,
                                    onClick = { reminderMinutesBefore = mins },
                                    label = { Text(DateUtils.formatReminderLabel(mins.toLong())) },
                                    modifier = Modifier.testTag("reminder_option_$mins")
                                )
                            }
                        }
                    }

                    if (notificationPermissionNote != null) {
                        Text(
                            text = notificationPermissionNote.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            OutlinedTextField(
                value = location,
                onValueChange = {
                    location = it.take(200)
                    locationError = null
                },
                label = { Text("Location or meeting link (optional)") },
                placeholder = { Text("Address, room, video link, or tap GPS") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = {
                            val hasFine = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            val hasCoarse = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasFine || hasCoarse) {
                                requestCurrentLocation()
                            } else {
                                locationPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        },
                        enabled = !isFetchingLocation,
                        modifier = Modifier.testTag("appointment_use_current_location_button")
                    ) {
                        if (isFetchingLocation) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.MyLocation,
                                contentDescription = "Use current location",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("appointment_location_input")
            )

            if (locationError != null) {
                Text(
                    text = locationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            val linkedContactLocations = remember(availableContacts, linkedContactIds) {
                availableContacts.filter { it.id in linkedContactIds && it.location.isNotBlank() }
            }
            if (linkedContactLocations.isNotEmpty()) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    linkedContactLocations.forEach { contact ->
                        AssistChip(
                            onClick = {
                                location = contact.location
                                locationError = null
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = {
                                Text("Use ${contact.name.substringBefore(" ")}'s location")
                            },
                            modifier = Modifier.testTag("use_contact_location_${contact.id}")
                        )
                    }
                }
            }

            // Linked Contacts Section
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val selectedContacts = remember(availableContacts, linkedContactIds) {
                    availableContacts.filter { it.id in linkedContactIds }
                }
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Linked Contacts (${selectedContacts.size})",
                            style = MaterialTheme.typography.titleSmall
                        )
                        TextButton(
                            onClick = { showContactPicker = true },
                            modifier = Modifier.testTag("link_contacts_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (selectedContacts.isEmpty()) "Add Contact" else "Edit Links")
                        }
                    }

                    if (selectedContacts.isEmpty()) {
                        Text(
                            text = "Link saved contacts as meeting attendees.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            selectedContacts.forEach { contact ->
                                InputChip(
                                    selected = true,
                                    onClick = {
                                        linkedContactIds = linkedContactIds.filterNot { it == contact.id }
                                        attendees = attendees
                                            .split(",")
                                            .map { it.trim() }
                                            .filter { it.isNotBlank() && !it.equals(contact.name, ignoreCase = true) }
                                            .joinToString(", ")
                                            .take(300)
                                    },
                                    label = { Text(contact.name) },
                                    trailingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.Close,
                                            contentDescription = "Remove ${contact.name}",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    modifier = Modifier.testTag("linked_contact_chip_${contact.id}")
                                )
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = attendees,
                onValueChange = { attendees = it.take(300) },
                label = { Text("Attendees (optional)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("appointment_attendees_input")
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it.take(1000) },
                label = { Text("Agenda or preparation notes (optional)") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("appointment_notes_input")
            )

            if (validationError != null) {
                Text(
                    text = validationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text("Cancel")
                }

                Button(
                    onClick = {
                        if (title.trim().isEmpty()) {
                            validationError = "Please enter an appointment title."
                            return@Button
                        }
                        if (!allDay && endMinute <= startMinute) {
                            validationError = "End time must be after start time."
                            return@Button
                        }
                        if (reminderEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val hasPermission = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) == PackageManager.PERMISSION_GRANTED
                            if (!hasPermission) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                        onSave(
                            editingAppointment?.id,
                            title,
                            dateKey,
                            startMinute,
                            endMinute,
                            allDay,
                            category,
                            location,
                            attendees,
                            linkedContactIds,
                            notes,
                            reminderEnabled,
                            reminderMinutesBefore,
                            editingAppointment?.completed ?: false
                        )
                        onDismiss()
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_appointment_button")
                ) {
                    Text(if (editingAppointment == null) "Schedule" else "Save Changes")
                }
            }
        }
    }

    if (showContactPicker) {
        ContactMultiSelectDialog(
            availableContacts = availableContacts,
            selectedIds = linkedContactIds,
            onToggleContact = { contact ->
                val isCurrentlyLinked = contact.id in linkedContactIds
                if (isCurrentlyLinked) {
                    linkedContactIds = linkedContactIds.filterNot { it == contact.id }
                    attendees = attendees
                        .split(",")
                        .map { it.trim() }
                        .filter { it.isNotBlank() && !it.equals(contact.name, ignoreCase = true) }
                        .joinToString(", ")
                        .take(300)
                } else {
                    linkedContactIds = (linkedContactIds + contact.id).distinct().take(25)
                    val currentNames = attendees.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    if (currentNames.none { it.equals(contact.name, ignoreCase = true) }) {
                        attendees = (currentNames + contact.name).joinToString(", ").take(300)
                    }
                }
            },
            onQuickCreate = { name, role, company, group ->
                onQuickCreateContact(name, role, company, group) { newId ->
                    linkedContactIds = (linkedContactIds + newId).distinct().take(25)
                    val currentNames = attendees.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    if (currentNames.none { it.equals(name.trim(), ignoreCase = true) }) {
                        attendees = (currentNames + name.trim()).joinToString(", ").take(300)
                    }
                }
            },
            onDismiss = { showContactPicker = false }
        )
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = DateUtils.dateKeyToUtcMidnightMillis(dateKey)
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            dateKey = DateUtils.utcMidnightMillisToDateKey(millis)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("Select")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (showStartTimePicker) {
        val timeState = rememberTimePickerState(
            initialHour = (startMinute / 60).coerceIn(0, 23),
            initialMinute = startMinute % 60
        )
        AlertDialog(
            onDismissRequest = { showStartTimePicker = false },
            title = { Text("Start Time") },
            text = { TimePicker(state = timeState) },
            confirmButton = {
                TextButton(
                    onClick = {
                        val nextStart = (timeState.hour * 60 + timeState.minute).coerceIn(0, 1425)
                        startMinute = nextStart
                        if (endMinute <= nextStart) {
                            endMinute = (nextStart + 60).coerceAtMost(1440)
                        }
                        validationError = null
                        showStartTimePicker = false
                    }
                ) {
                    Text("Set")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStartTimePicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showEndTimePicker) {
        val timeState = rememberTimePickerState(
            initialHour = ((endMinute % 1440) / 60).coerceIn(0, 23),
            initialMinute = endMinute % 60
        )
        AlertDialog(
            onDismissRequest = { showEndTimePicker = false },
            title = { Text("End Time") },
            text = { TimePicker(state = timeState) },
            confirmButton = {
                TextButton(
                    onClick = {
                        val nextEnd = (timeState.hour * 60 + timeState.minute).let {
                            if (it == 0) 1440 else it
                        }
                        if (nextEnd <= startMinute) {
                            validationError = "End time must be after start time."
                        } else {
                            endMinute = nextEnd
                            validationError = null
                        }
                        showEndTimePicker = false
                    }
                ) {
                    Text("Set")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEndTimePicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ContactMultiSelectDialog(
    availableContacts: List<SecretaryContact>,
    selectedIds: List<String>,
    onToggleContact: (SecretaryContact) -> Unit,
    onQuickCreate: (name: String, role: String, company: String, group: ContactGroup) -> Unit,
    onDismiss: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    var showQuickAddForm by remember { mutableStateOf(availableContacts.isEmpty()) }
    var quickName by remember { mutableStateOf("") }
    var quickRole by remember { mutableStateOf("") }
    var quickCompany by remember { mutableStateOf("") }
    var quickGroup by remember { mutableStateOf(ContactGroup.COLLEAGUE) }

    val filtered = remember(availableContacts, search) {
        val q = search.trim().lowercase()
        if (q.isBlank()) availableContacts
        else availableContacts.filter {
            it.name.lowercase().contains(q) ||
                it.company.lowercase().contains(q) ||
                it.role.lowercase().contains(q)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Link Contacts to Event") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (availableContacts.isNotEmpty()) {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        placeholder = { Text("Filter contacts…") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 220.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filtered, key = { it.id }) { contact ->
                            val isSelected = contact.id in selectedIds
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleContact(contact) }
                                    .padding(vertical = 4.dp)
                                    .testTag("picker_contact_${contact.id}"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { onToggleContact(contact) }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = contact.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val sub = listOf(contact.role, contact.company)
                                        .filter { it.isNotBlank() }
                                        .joinToString(" • ")
                                    if (sub.isNotBlank()) {
                                        Text(
                                            text = sub,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                TextButton(
                    onClick = { showQuickAddForm = !showQuickAddForm },
                    modifier = Modifier.testTag("toggle_quick_add_contact_button")
                ) {
                    Text(if (showQuickAddForm) "Hide Quick Contact Form" else "+ Create & Link New Contact")
                }

                if (showQuickAddForm) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = quickName,
                                onValueChange = { quickName = it.take(120) },
                                label = { Text("Contact name") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("quick_contact_name_input")
                            )
                            OutlinedTextField(
                                value = quickRole,
                                onValueChange = { quickRole = it.take(120) },
                                label = { Text("Role (optional)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = quickCompany,
                                onValueChange = { quickCompany = it.take(120) },
                                label = { Text("Company (optional)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    if (quickName.isNotBlank()) {
                                        onQuickCreate(quickName, quickRole, quickCompany, quickGroup)
                                        quickName = ""
                                        quickRole = ""
                                        quickCompany = ""
                                        showQuickAddForm = false
                                    }
                                },
                                enabled = quickName.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("quick_create_link_contact_button")
                            ) {
                                Text("Save & Link")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

