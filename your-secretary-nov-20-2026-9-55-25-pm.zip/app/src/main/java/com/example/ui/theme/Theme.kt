package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = OnEmeraldPrimary,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = OnEmeraldContainer,
    secondary = BrassSecondary,
    onSecondary = OnBrassSecondary,
    secondaryContainer = BrassContainer,
    onSecondaryContainer = OnBrassContainer,
    tertiary = SlateTertiary,
    onTertiary = OnSlateTertiary,
    tertiaryContainer = SlateContainer,
    onTertiaryContainer = OnSlateContainer,
    background = AlabasterBackground,
    onBackground = MidnightInk,
    surface = WarmPaperSurface,
    onSurface = MidnightInk,
    surfaceVariant = LinenSurfaceVariant,
    onSurfaceVariant = MutedInk,
    outline = HairlineOutline,
    outlineVariant = SoftOutlineVariant,
    error = CrimsonError,
    onError = OnCrimsonError,
    errorContainer = CrimsonErrorContainer,
    onErrorContainer = OnCrimsonErrorContainer
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkEmeraldPrimary,
    onPrimary = DarkOnEmeraldPrimary,
    primaryContainer = DarkEmeraldContainer,
    onPrimaryContainer = DarkOnEmeraldContainer,
    secondary = DarkBrassSecondary,
    onSecondary = DarkOnBrassSecondary,
    secondaryContainer = DarkBrassContainer,
    onSecondaryContainer = DarkOnBrassContainer,
    tertiary = DarkSlateTertiary,
    onTertiary = DarkOnSlateTertiary,
    tertiaryContainer = DarkSlateContainer,
    onTertiaryContainer = DarkOnSlateContainer,
    background = ObsidianBackground,
    onBackground = IvoryInk,
    surface = ObsidianSurface,
    onSurface = IvoryInk,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = SilverMutedInk,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    error = CrimsonError,
    onError = OnCrimsonError,
    errorContainer = CrimsonErrorContainer,
    onErrorContainer = OnCrimsonErrorContainer
)

val SecretaryShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun YourSecretaryTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = SecretaryShapes,
        content = content
    )
}
