package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Appointment
import com.example.model.SecretaryTask
import com.example.model.TaskPriority
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskEditorSheet(
    editingTask: SecretaryTask?,
    initialDueDateKey: String,
    initialLinkedAppointment: Appointment?,
    availableAppointments: List<Appointment>,
    onDismiss: () -> Unit,
    onSave: (
        existingId: String?,
        title: String,
        details: String,
        dueDateKey: String,
        linkedAppointmentId: String,
        linkedAppointmentTitle: String,
        priority: TaskPriority,
        completed: Boolean
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val todayKey = remember { DateUtils.todayDateKey() }
    val tomorrowKey = remember { DateUtils.shiftDateKey(todayKey, 1) }

    var title by remember { mutableStateOf(editingTask?.title.orEmpty()) }
    var details by remember { mutableStateOf(editingTask?.details.orEmpty()) }
    var dueDateKey by remember {
        mutableStateOf(
            editingTask?.dueDateKey ?: initialLinkedAppointment?.dateKey ?: initialDueDateKey
        )
    }
    var linkedAppointmentId by remember {
        mutableStateOf(
            editingTask?.linkedAppointmentId ?: initialLinkedAppointment?.id.orEmpty()
        )
    }
    var linkedAppointmentTitle by remember {
        mutableStateOf(
            editingTask?.linkedAppointmentTitle ?: initialLinkedAppointment?.title.orEmpty()
        )
    }
    var priority by remember {
        mutableStateOf(editingTask?.resolvedPriority() ?: TaskPriority.NORMAL)
    }
    var completed by remember { mutableStateOf(editingTask?.completed ?: false) }

    var showDatePicker by remember { mutableStateOf(false) }
    var showAppointmentMenu by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (editingTask == null) "New Action Item" else "Edit Action Item",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it.take(160)
                    validationError = null
                },
                label = { Text("Task title") },
                placeholder = { Text("e.g., Prepare Q4 slides before board sync") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_title_input")
            )

            OutlinedTextField(
                value = details,
                onValueChange = { details = it.take(1000) },
                label = { Text("Details or checklist notes (optional)") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_details_input")
            )

            // Priority Selection
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Priority",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TaskPriority.entries.forEach { level ->
                        FilterChip(
                            selected = priority == level,
                            onClick = { priority = level },
                            label = { Text(level.label) },
                            modifier = Modifier.testTag("task_priority_${level.name.lowercase()}")
                        )
                    }
                }
            }

            // Agenda Date Linking
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Link to Agenda Date",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = dueDateKey == todayKey,
                            onClick = { dueDateKey = todayKey },
                            label = { Text("Today") },
                            modifier = Modifier.testTag("task_due_today_chip")
                        )
                        FilterChip(
                            selected = dueDateKey == tomorrowKey,
                            onClick = { dueDateKey = tomorrowKey },
                            label = { Text("Tomorrow") },
                            modifier = Modifier.testTag("task_due_tomorrow_chip")
                        )
                        FilterChip(
                            selected = dueDateKey.isNotBlank() && dueDateKey != todayKey && dueDateKey != tomorrowKey,
                            onClick = { showDatePicker = true },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.CalendarToday,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = {
                                Text(
                                    if (dueDateKey.isNotBlank() && dueDateKey != todayKey && dueDateKey != tomorrowKey) {
                                        DateUtils.formatShortDate(dueDateKey)
                                    } else {
                                        "Pick Date"
                                    }
                                )
                            },
                            modifier = Modifier.testTag("task_due_pick_date_chip")
                        )
                        FilterChip(
                            selected = dueDateKey.isBlank(),
                            onClick = { dueDateKey = "" },
                            label = { Text("No Date") },
                            modifier = Modifier.testTag("task_due_none_chip")
                        )
                    }

                    // Link to specific Appointment
                    Text(
                        text = "Link to Appointment (optional)",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showAppointmentMenu = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("task_link_appointment_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Event,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (linkedAppointmentId.isNotBlank()) {
                                    linkedAppointmentTitle.ifBlank { "Linked Event" }
                                } else {
                                    "Attach to a scheduled appointment"
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (linkedAppointmentId.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        linkedAppointmentId = ""
                                        linkedAppointmentTitle = ""
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Clear linked appointment",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = showAppointmentMenu,
                            onDismissRequest = { showAppointmentMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (Standalone task)") },
                                onClick = {
                                    linkedAppointmentId = ""
                                    linkedAppointmentTitle = ""
                                    showAppointmentMenu = false
                                }
                            )
                            if (availableAppointments.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No appointments scheduled yet") },
                                    onClick = { showAppointmentMenu = false },
                                    enabled = false
                                )
                            } else {
                                availableAppointments.take(20).forEach { appt ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(
                                                    text = appt.title,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${DateUtils.formatShortDate(appt.dateKey)} • ${
                                                        DateUtils.formatTimeRange(
                                                            appt.startMinute,
                                                            appt.endMinute,
                                                            appt.allDay
                                                        )
                                                    }",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        },
                                        onClick = {
                                            linkedAppointmentId = appt.id
                                            linkedAppointmentTitle = appt.title
                                            if (dueDateKey.isBlank()) {
                                                dueDateKey = appt.dateKey
                                            }
                                            showAppointmentMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (editingTask != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { completed = !completed }
                        .padding(vertical = 4.dp)
                        .testTag("task_editor_completed_row")
                ) {
                    Checkbox(
                        checked = completed,
                        onCheckedChange = { completed = it }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Mark task as completed",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            if (validationError != null) {
                Text(
                    text = validationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text("Cancel")
                }
                Button(
                    onClick = {
                        if (title.trim().isEmpty()) {
                            validationError = "Please enter a task title."
                            return@Button
                        }
                        onSave(
                            editingTask?.id,
                            title,
                            details,
                            dueDateKey,
                            linkedAppointmentId,
                            linkedAppointmentTitle,
                            priority,
                            completed
                        )
                        onDismiss()
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_task_button")
                ) {
                    Text(if (editingTask == null) "Save Task" else "Save Changes")
                }
            }
        }
    }

    if (showDatePicker) {
        val initialMillis = if (DateUtils.isValidDateKey(dueDateKey)) {
            DateUtils.dateKeyToUtcMidnightMillis(dueDateKey)
        } else {
            DateUtils.dateKeyToUtcMidnightMillis(todayKey)
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            dueDateKey = DateUtils.utcMidnightMillisToDateKey(millis)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("Select")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
