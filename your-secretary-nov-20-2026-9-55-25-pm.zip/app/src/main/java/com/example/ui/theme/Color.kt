package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Executive Atelier Light Palette
val EmeraldPrimary = Color(0xFF0F4C3A)
val OnEmeraldPrimary = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFFD2EBE1)
val OnEmeraldContainer = Color(0xFF07291F)

val BrassSecondary = Color(0xFF9C5420)
val OnBrassSecondary = Color(0xFFFFFFFF)
val BrassContainer = Color(0xFFFBE5D3)
val OnBrassContainer = Color(0xFF341804)

val SlateTertiary = Color(0xFF334E68)
val OnSlateTertiary = Color(0xFFFFFFFF)
val SlateContainer = Color(0xFFD9E6F2)
val OnSlateContainer = Color(0xFF102A43)

val AlabasterBackground = Color(0xFFFBF9F5)
val MidnightInk = Color(0xFF161A18)
val WarmPaperSurface = Color(0xFFFBF9F5)
val LinenSurfaceVariant = Color(0xFFF1ECE1)
val MutedInk = Color(0xFF565E59)
val HairlineOutline = Color(0xFFD8D1C2)
val SoftOutlineVariant = Color(0xFFE9E3D7)

val CrimsonError = Color(0xFFB3261E)
val OnCrimsonError = Color(0xFFFFFFFF)
val CrimsonErrorContainer = Color(0xFFF9DEDC)
val OnCrimsonErrorContainer = Color(0xFF410E0B)

// Executive Atelier Dark Palette
val DarkEmeraldPrimary = Color(0xFF7FD6B6)
val DarkOnEmeraldPrimary = Color(0xFF003828)
val DarkEmeraldContainer = Color(0xFF0B513D)
val DarkOnEmeraldContainer = Color(0xFFA8F2D6)

val DarkBrassSecondary = Color(0xFFF2B688)
val DarkOnBrassSecondary = Color(0xFF4B2304)
val DarkBrassContainer = Color(0xFF6B3710)
val DarkOnBrassContainer = Color(0xFFFFDCC2)

val DarkSlateTertiary = Color(0xFFADC9E6)
val DarkOnSlateTertiary = Color(0xFF133049)
val DarkSlateContainer = Color(0xFF284763)
val DarkOnSlateContainer = Color(0xFFD4E6FA)

val ObsidianBackground = Color(0xFF0F1412)
val IvoryInk = Color(0xFFECEEEB)
val ObsidianSurface = Color(0xFF151B19)
val ObsidianSurfaceVariant = Color(0xFF212A26)
val SilverMutedInk = Color(0xFFAEB8B3)
val DarkOutline = Color(0xFF3A4540)
val DarkOutlineVariant = Color(0xFF27302C)

// Category Accent Tokens
val CategoryMeetingColor = Color(0xFF0F4C3A)
val CategoryFocusColor = Color(0xFF334E68)
val CategoryCallColor = Color(0xFF9C5420)
val CategoryPersonalColor = Color(0xFF7B3E65)
val CategoryTravelColor = Color(0xFF2E6B7B)
