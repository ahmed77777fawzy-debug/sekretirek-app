package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Today
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.auth.signOut
import com.example.model.Appointment
import com.example.model.SecretaryContact
import com.example.model.SecretaryTask
import com.example.model.UiState
import com.example.ui.components.AppointmentDetailSheet
import com.example.ui.components.AppointmentEditorSheet
import com.example.ui.components.ContactDetailSheet
import com.example.ui.components.ContactEditorSheet
import com.example.ui.components.TaskEditorSheet
import com.example.ui.screens.BriefingScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.SecretaryChatScreen
import com.example.ui.screens.TasksMemosScreen
import com.example.viewmodel.SecretaryViewModel

enum class MainTab(
    val titleRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    BRIEFING(R.string.nav_briefing, Icons.Filled.Today, Icons.Outlined.Today, "nav_briefing"),
    CALENDAR(R.string.nav_calendar, Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_calendar"),
    DESK(R.string.nav_tasks, Icons.Filled.TaskAlt, Icons.Outlined.TaskAlt, "nav_desk"),
    CONTACTS(R.string.nav_contacts, Icons.Filled.Contacts, Icons.Outlined.Contacts, "nav_contacts"),
    SECRETARY(R.string.nav_ai, Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_secretary")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(
    viewModel: SecretaryViewModel,
    userEmail: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }

    val appointmentsState by viewModel.appointmentsState.collectAsStateWithLifecycle()
    val tasksState by viewModel.tasksState.collectAsStateWithLifecycle()
    val memosState by viewModel.memosState.collectAsStateWithLifecycle()
    val contactsState by viewModel.contactsState.collectAsStateWithLifecycle()
    val selectedDateKey by viewModel.selectedDateKey.collectAsStateWithLifecycle()
    val viewMode by viewModel.scheduleViewMode.collectAsStateWithLifecycle()
    val smartBriefingState by viewModel.smartBriefingState.collectAsStateWithLifecycle()
    val isParsingCommand by viewModel.isParsingCommand.collectAsStateWithLifecycle()
    val pendingProposal by viewModel.pendingProposal.collectAsStateWithLifecycle()
    val commandError by viewModel.commandError.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val draftingMemoId by viewModel.draftingMemoId.collectAsStateWithLifecycle()

    val allAppointments = (appointmentsState as? UiState.Success)?.data.orEmpty()
    val allTasks = (tasksState as? UiState.Success)?.data.orEmpty()
    val allContacts = (contactsState as? UiState.Success)?.data.orEmpty()

    var currentTab by remember { mutableStateOf(MainTab.BRIEFING) }
    var showAccountMenu by remember { mutableStateOf(false) }

    var showAppointmentEditor by remember { mutableStateOf(false) }
    var editorInitialDateKey by remember { mutableStateOf(selectedDateKey) }
    var appointmentInitialLinkedContactIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var editingAppointment by remember { mutableStateOf<Appointment?>(null) }
    var inspectingAppointment by remember { mutableStateOf<Appointment?>(null) }

    var showTaskEditor by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<SecretaryTask?>(null) }
    var taskInitialDateKey by remember { mutableStateOf(selectedDateKey) }
    var taskInitialAppointment by remember { mutableStateOf<Appointment?>(null) }

    var showContactEditor by remember { mutableStateOf(false) }
    var editingContact by remember { mutableStateOf<SecretaryContact?>(null) }
    var inspectingContact by remember { mutableStateOf<SecretaryContact?>(null) }

    LaunchedEffect(viewModel) {
        viewModel.snackbarMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    BackHandler(enabled = currentTab != MainTab.BRIEFING) {
        currentTab = MainTab.BRIEFING
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useRail) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    MainTab.entries.forEach { tab ->
                        NavigationRailItem(
                            selected = currentTab == tab,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == tab) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = stringResource(tab.titleRes)
                                )
                            },
                            label = { Text(stringResource(tab.titleRes)) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = when (currentTab) {
                                    MainTab.BRIEFING -> stringResource(R.string.title_smart_briefing)
                                    MainTab.CALENDAR -> "Schedule"
                                    MainTab.DESK -> "Tasks & Memos"
                                    MainTab.CONTACTS -> stringResource(R.string.title_contacts)
                                    MainTab.SECRETARY -> "Executive Secretary"
                                },
                                style = MaterialTheme.typography.headlineMedium
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        ),
                        actions = {
                            Box {
                                IconButton(
                                    onClick = { showAccountMenu = true },
                                    modifier = Modifier.testTag("account_menu_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AccountCircle,
                                        contentDescription = "Account menu"
                                    )
                                }
                                DropdownMenu(
                                    expanded = showAccountMenu,
                                    onDismissRequest = { showAccountMenu = false }
                                ) {
                                    if (userEmail.isNotBlank()) {
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = userEmail,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            },
                                            onClick = { showAccountMenu = false }
                                        )
                                    }
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.sign_out)) },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                                contentDescription = null
                                            )
                                        },
                                        onClick = {
                                            showAccountMenu = false
                                            signOut(credentialManager, scope)
                                        },
                                        modifier = Modifier.testTag("sign_out_menu_item")
                                    )
                                }
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            MainTab.entries.forEach { tab ->
                                NavigationBarItem(
                                    selected = currentTab == tab,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentTab == tab) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = stringResource(tab.titleRes)
                                        )
                                    },
                                    label = { Text(stringResource(tab.titleRes)) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                },
                floatingActionButton = {
                    when (currentTab) {
                        MainTab.CALENDAR, MainTab.BRIEFING -> {
                            ExtendedFloatingActionButton(
                                onClick = {
                                    editorInitialDateKey = selectedDateKey
                                    appointmentInitialLinkedContactIds = emptyList()
                                    editingAppointment = null
                                    showAppointmentEditor = true
                                },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                                text = { Text(stringResource(R.string.add_appointment)) },
                                modifier = Modifier.testTag("fab_new_appointment")
                            )
                        }
                        MainTab.CONTACTS -> {
                            ExtendedFloatingActionButton(
                                onClick = {
                                    editingContact = null
                                    showContactEditor = true
                                },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                                text = { Text("New Contact") },
                                modifier = Modifier.testTag("fab_new_contact")
                            )
                        }
                        else -> Unit
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentTab) {
                        MainTab.BRIEFING -> {
                            BriefingScreen(
                                userDisplayName = viewModel.userDisplayName,
                                appointmentsState = appointmentsState,
                                tasksState = tasksState,
                                smartBriefingState = smartBriefingState,
                                isParsingCommand = isParsingCommand,
                                pendingProposal = pendingProposal,
                                commandError = commandError,
                                onGenerateBriefing = viewModel::generateSmartDailyBriefing,
                                onParseQuickCommand = viewModel::parseQuickCommand,
                                onConfirmProposal = viewModel::confirmProposal,
                                onDismissProposal = viewModel::dismissProposal,
                                onOpenCalendar = { currentTab = MainTab.CALENDAR },
                                onNewAppointment = {
                                    editorInitialDateKey = selectedDateKey
                                    appointmentInitialLinkedContactIds = emptyList()
                                    editingAppointment = null
                                    showAppointmentEditor = true
                                },
                                onNewTask = {
                                    editingTask = null
                                    taskInitialDateKey = selectedDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onAppointmentClick = { inspectingAppointment = it },
                                onToggleAppointment = viewModel::toggleAppointmentCompleted,
                                onToggleTask = viewModel::toggleTaskCompleted,
                                onEditTask = { task ->
                                    editingTask = task
                                    taskInitialDateKey = task.dueDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                }
                            )
                        }
                        MainTab.CALENDAR -> {
                            CalendarScreen(
                                selectedDateKey = selectedDateKey,
                                viewMode = viewMode,
                                appointmentsState = appointmentsState,
                                tasksState = tasksState,
                                onSelectDate = viewModel::selectDate,
                                onViewModeChange = viewModel::setScheduleViewMode,
                                onNavigatePeriod = viewModel::navigatePeriod,
                                onJumpToToday = viewModel::jumpToToday,
                                onAddAppointment = { dateKey ->
                                    editorInitialDateKey = dateKey
                                    appointmentInitialLinkedContactIds = emptyList()
                                    editingAppointment = null
                                    showAppointmentEditor = true
                                },
                                onAppointmentClick = { inspectingAppointment = it },
                                onAddTaskForDate = { dateKey ->
                                    editingTask = null
                                    taskInitialDateKey = dateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onToggleTask = viewModel::toggleTaskCompleted,
                                onEditTask = { task ->
                                    editingTask = task
                                    taskInitialDateKey = task.dueDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                }
                            )
                        }
                        MainTab.DESK -> {
                            TasksMemosScreen(
                                tasksState = tasksState,
                                memosState = memosState,
                                appointments = allAppointments,
                                draftingMemoId = draftingMemoId,
                                onOpenNewTask = {
                                    editingTask = null
                                    taskInitialDateKey = selectedDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onEditTask = { task ->
                                    editingTask = task
                                    taskInitialDateKey = task.dueDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onToggleTask = viewModel::toggleTaskCompleted,
                                onDeleteTask = viewModel::deleteTask,
                                onOpenDateInCalendar = { dateKey ->
                                    viewModel.selectDate(dateKey)
                                    currentTab = MainTab.CALENDAR
                                },
                                onOpenLinkedAppointment = { apptId ->
                                    val found = allAppointments.firstOrNull { it.id == apptId }
                                    if (found != null) {
                                        viewModel.selectDate(found.dateKey)
                                        currentTab = MainTab.CALENDAR
                                        inspectingAppointment = found
                                    }
                                },
                                onSaveMemo = viewModel::saveMemo,
                                onToggleMemoPin = viewModel::toggleMemoPinned,
                                onDraftMemoFollowUp = viewModel::generateMemoFollowUpDraft,
                                onDeleteMemo = viewModel::deleteMemo
                            )
                        }
                        MainTab.CONTACTS -> {
                            ContactsScreen(
                                contactsState = contactsState,
                                appointments = allAppointments,
                                onAddContact = {
                                    editingContact = null
                                    showContactEditor = true
                                },
                                onContactClick = { inspectingContact = it },
                                onToggleFavorite = viewModel::toggleContactFavorite
                            )
                        }
                        MainTab.SECRETARY -> {
                            SecretaryChatScreen(
                                messages = chatMessages,
                                onSendMessage = viewModel::sendChatMessage
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAppointmentEditor) {
        AppointmentEditorSheet(
            initialDateKey = editorInitialDateKey,
            editingAppointment = editingAppointment,
            initialLinkedContactIds = appointmentInitialLinkedContactIds,
            availableContacts = allContacts,
            onQuickCreateContact = { name, role, company, group, onCreated ->
                viewModel.saveContact(
                    existingId = null,
                    name = name,
                    role = role,
                    company = company,
                    email = "",
                    phone = "",
                    location = "",
                    group = group,
                    notes = "",
                    favorite = false,
                    onSavedId = onCreated
                )
            },
            onDismiss = { showAppointmentEditor = false },
            onSave = viewModel::saveAppointment
        )
    }

    if (showTaskEditor) {
        TaskEditorSheet(
            editingTask = editingTask,
            initialDueDateKey = taskInitialDateKey,
            initialLinkedAppointment = taskInitialAppointment,
            availableAppointments = allAppointments,
            onDismiss = { showTaskEditor = false },
            onSave = viewModel::saveTask
        )
    }

    if (showContactEditor) {
        ContactEditorSheet(
            editingContact = editingContact,
            onDismiss = { showContactEditor = false },
            onSave = { id, name, role, company, email, phone, location, group, notes, favorite ->
                viewModel.saveContact(
                    existingId = id,
                    name = name,
                    role = role,
                    company = company,
                    email = email,
                    phone = phone,
                    location = location,
                    group = group,
                    notes = notes,
                    favorite = favorite
                )
            }
        )
    }

    inspectingAppointment?.let { appt ->
        val linkedTasks = allTasks.filter { it.linkedAppointmentId == appt.id }
        AppointmentDetailSheet(
            appointment = appt,
            linkedTasks = linkedTasks,
            availableContacts = allContacts,
            onDismiss = { inspectingAppointment = null },
            onEdit = {
                inspectingAppointment = null
                editingAppointment = appt
                editorInitialDateKey = appt.dateKey
                appointmentInitialLinkedContactIds = appt.linkedContactIds
                showAppointmentEditor = true
            },
            onToggleComplete = {
                viewModel.toggleAppointmentCompleted(appt)
                inspectingAppointment = null
            },
            onDelete = {
                viewModel.deleteAppointment(appt.id)
                inspectingAppointment = null
            },
            onAddLinkedTask = {
                inspectingAppointment = null
                editingTask = null
                taskInitialDateKey = appt.dateKey
                taskInitialAppointment = appt
                showTaskEditor = true
            },
            onToggleTask = viewModel::toggleTaskCompleted,
            onEditTask = { task ->
                inspectingAppointment = null
                editingTask = task
                taskInitialDateKey = task.dueDateKey
                taskInitialAppointment = appt
                showTaskEditor = true
            },
            onContactClick = { contact ->
                inspectingAppointment = null
                inspectingContact = contact
            }
        )
    }

    inspectingContact?.let { contact ->
        val liveContact = allContacts.firstOrNull { it.id == contact.id } ?: contact
        ContactDetailSheet(
            contact = liveContact,
            allAppointments = allAppointments,
            onDismiss = { inspectingContact = null },
            onEdit = {
                inspectingContact = null
                editingContact = liveContact
                showContactEditor = true
            },
            onToggleFavorite = { viewModel.toggleContactFavorite(liveContact) },
            onDelete = {
                viewModel.deleteContact(liveContact.id)
                inspectingContact = null
            },
            onScheduleWithContact = {
                inspectingContact = null
                editingAppointment = null
                editorInitialDateKey = selectedDateKey
                appointmentInitialLinkedContactIds = listOf(liveContact.id)
                showAppointmentEditor = true
            },
            onLinkToAppointment = { appt ->
                viewModel.linkContactToAppointment(liveContact, appt)
            },
            onUnlinkFromAppointment = { appt ->
                viewModel.unlinkContactFromAppointment(liveContact, appt)
            },
            onOpenAppointment = { appt ->
                inspectingContact = null
                viewModel.selectDate(appt.dateKey)
                currentTab = MainTab.CALENDAR
                inspectingAppointment = appt
            }
        )
    }
}
