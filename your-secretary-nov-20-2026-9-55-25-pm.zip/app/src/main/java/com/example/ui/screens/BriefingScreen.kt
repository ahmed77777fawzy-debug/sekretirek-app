package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AiActionProposal
import com.example.model.Appointment
import com.example.model.PrioritizedBriefingItem
import com.example.model.ProposalKind
import com.example.model.SecretaryTask
import com.example.model.SmartBriefingState
import com.example.model.TaskPriority
import com.example.model.UiState
import com.example.model.UrgencyLevel
import com.example.util.DateUtils

private enum class BriefingFeedFilter(val label: String) {
    ALL("All"),
    APPOINTMENTS("Appointments"),
    TASKS("Pending Tasks")
}

@Composable
fun BriefingScreen(
    userDisplayName: String,
    appointmentsState: UiState<List<Appointment>>,
    tasksState: UiState<List<SecretaryTask>>,
    smartBriefingState: SmartBriefingState,
    isParsingCommand: Boolean,
    pendingProposal: AiActionProposal?,
    commandError: String?,
    onGenerateBriefing: () -> Unit,
    onParseQuickCommand: (String) -> Unit,
    onConfirmProposal: () -> Unit,
    onDismissProposal: () -> Unit,
    onOpenCalendar: () -> Unit,
    onNewAppointment: () -> Unit,
    onNewTask: () -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onToggleAppointment: (Appointment) -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayKey = remember { DateUtils.todayDateKey() }
    val firstName = userDisplayName.substringBefore(" ").ifBlank { "Executive" }
    var commandText by remember { mutableStateOf("") }
    var feedFilter by remember { mutableStateOf(BriefingFeedFilter.ALL) }

    val allAppointments = (appointmentsState as? UiState.Success)?.data.orEmpty()
    val allTasks = (tasksState as? UiState.Success)?.data.orEmpty()

    val todayAppointments = remember(allAppointments, todayKey) {
        allAppointments
            .filter { it.dateKey == todayKey }
            .sortedWith(compareBy<Appointment> { !it.allDay }.thenBy { it.startMinute })
    }
    val pendingTasks = remember(allTasks, todayKey) {
        allTasks
            .filter { !it.completed }
            .sortedWith(
                compareBy<SecretaryTask>(
                    { task ->
                        when {
                            task.dueDateKey.isNotBlank() && task.dueDateKey < todayKey -> 0 // Overdue
                            task.dueDateKey == todayKey -> 1 // Due today
                            task.dueDateKey.isNotBlank() -> 2 // Upcoming
                            else -> 3 // Unscheduled
                        }
                    },
                    { task ->
                        when (task.resolvedPriority()) {
                            TaskPriority.HIGH -> 0
                            TaskPriority.NORMAL -> 1
                            TaskPriority.LOW -> 2
                        }
                    },
                    { it.dueDateKey }
                )
            )
    }

    val activeRemindersCount = remember(todayAppointments) {
        todayAppointments.count { it.reminderEnabled && !it.completed }
    }
    val overdueOrTodayTasksCount = remember(pendingTasks, todayKey) {
        pendingTasks.count { it.dueDateKey.isNotBlank() && it.dueDateKey <= todayKey }
    }
    val linkedTaskCountsByAppointment = remember(pendingTasks) {
        pendingTasks
            .filter { it.linkedAppointmentId.isNotBlank() }
            .groupingBy { it.linkedAppointmentId }
            .eachCount()
    }

    val showAppointmentsSection = feedFilter == BriefingFeedFilter.ALL || feedFilter == BriefingFeedFilter.APPOINTMENTS
    val showTasksSection = feedFilter == BriefingFeedFilter.ALL || feedFilter == BriefingFeedFilter.TASKS

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 820.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Editorial Hero Header
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                        .clip(RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_secretary_banner),
                        contentDescription = "Executive desk header",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xE60A291E),
                                        Color(0x990A291E)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = DateUtils.formatFullDate(todayKey).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFF2CFA7)
                        )
                        Text(
                            text = "${DateUtils.greetingPrefix()}, $firstName",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White
                        )
                        Text(
                            text = "${todayAppointments.size} scheduled today • ${pendingTasks.size} pending tasks",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFE6EFEA)
                        )
                    }
                }
            }

            // Daily Pulse Summary Metrics
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BriefingMetricTile(
                        label = "Appointments",
                        value = "${todayAppointments.size}",
                        supporting = "${todayAppointments.count { !it.completed }} remaining",
                        modifier = Modifier
                            .weight(1f)
                            .testTag("briefing_metric_appointments")
                    )
                    BriefingMetricTile(
                        label = "Pending Tasks",
                        value = "${pendingTasks.size}",
                        supporting = if (overdueOrTodayTasksCount > 0) {
                            "$overdueOrTodayTasksCount due/overdue"
                        } else {
                            "On track"
                        },
                        highlightWarning = overdueOrTodayTasksCount > 0,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("briefing_metric_tasks")
                    )
                    BriefingMetricTile(
                        label = "Reminders",
                        value = "$activeRemindersCount",
                        supporting = "Active today",
                        modifier = Modifier
                            .weight(1f)
                            .testTag("briefing_metric_reminders")
                    )
                }
            }

            // AI Urgent Prioritization Card
            item {
                SmartAiBriefingCard(
                    smartBriefingState = smartBriefingState,
                    hasContentToAnalyze = todayAppointments.isNotEmpty() || pendingTasks.isNotEmpty(),
                    onGenerateBriefing = onGenerateBriefing,
                    onClickPrioritizedItem = { item ->
                        if (item.itemType.equals("APPOINTMENT", ignoreCase = true)) {
                            val matchedAppt = allAppointments.firstOrNull { it.id == item.referenceId }
                                ?: todayAppointments.firstOrNull {
                                    it.title.equals(item.title, ignoreCase = true)
                                }
                            if (matchedAppt != null) {
                                onAppointmentClick(matchedAppt)
                            }
                        } else {
                            val matchedTask = allTasks.firstOrNull { it.id == item.referenceId }
                                ?: pendingTasks.firstOrNull {
                                    it.title.equals(item.title, ignoreCase = true)
                                }
                            if (matchedTask != null) {
                                onEditTask(matchedTask)
                            }
                        }
                    }
                )
            }

            // Natural-Language Quick Delegate
            item {
                QuickDelegateCard(
                    commandText = commandText,
                    onCommandTextChange = { commandText = it },
                    isParsingCommand = isParsingCommand,
                    pendingProposal = pendingProposal,
                    commandError = commandError,
                    onParseQuickCommand = onParseQuickCommand,
                    onConfirmProposal = {
                        commandText = ""
                        onConfirmProposal()
                    },
                    onDismissProposal = onDismissProposal
                )
            }

            // Unified Daily Briefing Header & Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Today's Combined View",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        TextButton(
                            onClick = onOpenCalendar,
                            modifier = Modifier.testTag("open_full_calendar_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CalendarMonth,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Calendar")
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BriefingFeedFilter.entries.forEach { filter ->
                            val count = when (filter) {
                                BriefingFeedFilter.ALL -> todayAppointments.size + pendingTasks.size
                                BriefingFeedFilter.APPOINTMENTS -> todayAppointments.size
                                BriefingFeedFilter.TASKS -> pendingTasks.size
                            }
                            FilterChip(
                                selected = feedFilter == filter,
                                onClick = { feedFilter = filter },
                                label = { Text("${filter.label} ($count)") },
                                modifier = Modifier.testTag("briefing_filter_${filter.name.lowercase()}")
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f, fill = false))
                        FilledTonalButton(
                            onClick = onNewTask,
                            modifier = Modifier.testTag("briefing_new_task_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Task")
                        }
                    }
                }
            }

            // Loading / Error States
            if (appointmentsState is UiState.Loading || tasksState is UiState.Loading) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            } else if (appointmentsState is UiState.Error || tasksState is UiState.Error) {
                val errorText = (appointmentsState as? UiState.Error)?.message
                    ?: (tasksState as? UiState.Error)?.message
                    ?: "Could not load today's briefing items."
                item {
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                val visibleAppts = if (showAppointmentsSection) todayAppointments else emptyList()
                val visibleTasks = if (showTasksSection) pendingTasks else emptyList()

                if (visibleAppts.isEmpty() && visibleTasks.isEmpty()) {
                    item {
                        BriefingEmptyStateCard(
                            filter = feedFilter,
                            onNewAppointment = onNewAppointment,
                            onNewTask = onNewTask
                        )
                    }
                } else {
                    if (visibleAppts.isNotEmpty()) {
                        item {
                            BriefingSectionLabel(
                                icon = Icons.Filled.Event,
                                title = "Scheduled Today (${visibleAppts.size})"
                            )
                        }
                        items(visibleAppts, key = { "appt_${it.id}" }) { appt ->
                            BriefingAppointmentRow(
                                appointment = appt,
                                linkedTasksCount = linkedTaskCountsByAppointment[appt.id] ?: 0,
                                onClick = { onAppointmentClick(appt) },
                                onToggleComplete = { onToggleAppointment(appt) }
                            )
                        }
                    }

                    if (visibleTasks.isNotEmpty()) {
                        item {
                            BriefingSectionLabel(
                                icon = Icons.Filled.TaskAlt,
                                title = "Pending Tasks (${visibleTasks.size})"
                            )
                        }
                        items(visibleTasks, key = { "task_${it.id}" }) { task ->
                            BriefingPendingTaskRow(
                                task = task,
                                todayKey = todayKey,
                                onToggleComplete = { onToggleTask(task) },
                                onClick = { onEditTask(task) }
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(76.dp)) }
        }
    }
}

@Composable
private fun BriefingMetricTile(
    label: String,
    value: String,
    supporting: String,
    modifier: Modifier = Modifier,
    highlightWarning: Boolean = false
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = if (highlightWarning) {
                    MaterialTheme.colorScheme.secondary
                } else {
                    MaterialTheme.colorScheme.primary
                }
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = supporting,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SmartAiBriefingCard(
    smartBriefingState: SmartBriefingState,
    hasContentToAnalyze: Boolean,
    onGenerateBriefing: () -> Unit,
    onClickPrioritizedItem: (PrioritizedBriefingItem) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smart_ai_briefing_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "AI Urgent Prioritization",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                if (smartBriefingState is SmartBriefingState.Success ||
                    smartBriefingState is SmartBriefingState.Error
                ) {
                    IconButton(
                        onClick = onGenerateBriefing,
                        modifier = Modifier.testTag("refresh_briefing_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.refresh_briefing)
                        )
                    }
                }
            }

            when (smartBriefingState) {
                SmartBriefingState.Idle -> {
                    Text(
                        text = if (hasContentToAnalyze) {
                            "Aggregate today's appointments and pending tasks into a ranked action briefing."
                        } else {
                            "Add an appointment or task to let your AI secretary summarize and prioritize your day."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onGenerateBriefing,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("generate_briefing_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.generate_briefing))
                    }
                }
                SmartBriefingState.Loading -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.padding(vertical = 6.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = "Analyzing today's schedule and pending tasks…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                is SmartBriefingState.Success -> {
                    val content = smartBriefingState.content
                    Text(
                        text = content.executiveSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("smart_briefing_summary")
                    )

                    if (content.urgentItems.isNotEmpty()) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Text(
                            text = "TOP PRIORITIES",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            content.urgentItems.forEach { item ->
                                PrioritizedBriefingItemCard(
                                    item = item,
                                    onClick = { onClickPrioritizedItem(item) }
                                )
                            }
                        }
                    }

                    if (content.secretaryTip.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lightbulb,
                                    contentDescription = "Secretary tip",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = content.secretaryTip,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                is SmartBriefingState.Error -> {
                    Text(
                        text = smartBriefingState.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                    OutlinedButton(
                        onClick = onGenerateBriefing,
                        modifier = Modifier.testTag("retry_briefing_button")
                    ) {
                        Text("Retry Prioritization")
                    }
                }
            }
        }
    }
}

@Composable
private fun PrioritizedBriefingItemCard(
    item: PrioritizedBriefingItem,
    onClick: () -> Unit
) {
    val (badgeContainer, badgeContent) = when (item.urgencyLevel) {
        UrgencyLevel.CRITICAL -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        UrgencyLevel.HIGH -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
        UrgencyLevel.FOCUS -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
    }
    val typeLabel = if (item.itemType.equals("APPOINTMENT", ignoreCase = true)) "APPOINTMENT" else "TASK"

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("prioritized_item_${item.rank}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(badgeContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${item.rank}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = badgeContent
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = badgeContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = item.urgencyLevel.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeContent,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = typeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (item.timeHint.isNotBlank()) {
                        Text(
                            text = item.timeHint,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (item.rationale.isNotBlank()) {
                    Text(
                        text = item.rationale,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open priority item",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .padding(top = 4.dp)
                    .size(18.dp)
            )
        }
    }
}

@Composable
private fun QuickDelegateCard(
    commandText: String,
    onCommandTextChange: (String) -> Unit,
    isParsingCommand: Boolean,
    pendingProposal: AiActionProposal?,
    commandError: String?,
    onParseQuickCommand: (String) -> Unit,
    onConfirmProposal: () -> Unit,
    onDismissProposal: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Quick Delegate",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            OutlinedTextField(
                value = commandText,
                onValueChange = onCommandTextChange,
                placeholder = {
                    Text(
                        text = stringResource(R.string.smart_schedule_hint),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (commandText.isNotBlank() && !isParsingCommand) {
                            onParseQuickCommand(commandText)
                        }
                    }
                ),
                trailingIcon = {
                    if (isParsingCommand) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        IconButton(
                            onClick = {
                                if (commandText.isNotBlank()) {
                                    onParseQuickCommand(commandText)
                                }
                            },
                            enabled = commandText.isNotBlank(),
                            modifier = Modifier.testTag("quick_delegate_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Parse schedule request"
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quick_delegate_input")
            )

            if (commandError != null) {
                Text(
                    text = commandError,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            AnimatedVisibility(visible = pendingProposal != null) {
                pendingProposal?.let { proposal ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = when (proposal.kind) {
                                    ProposalKind.APPOINTMENT -> "PROPOSED APPOINTMENT"
                                    ProposalKind.TASK -> "PROPOSED ACTION ITEM"
                                    ProposalKind.MEMO -> "PROPOSED MEMO"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = proposal.title,
                                style = MaterialTheme.typography.titleMedium
                            )
                            if (proposal.kind == ProposalKind.APPOINTMENT) {
                                Text(
                                    text = "${DateUtils.formatFullDate(proposal.dateKey)} • ${
                                        DateUtils.formatTimeRange(
                                            proposal.startMinute.toLong(),
                                            proposal.endMinute.toLong(),
                                            proposal.allDay
                                        )
                                    }",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (proposal.reminderEnabled) {
                                    Text(
                                        text = "Reminder: ${
                                            DateUtils.formatReminderLabel(
                                                proposal.reminderMinutesBefore.toLong()
                                            )
                                        }",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onDismissProposal,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Discard")
                                }
                                Button(
                                    onClick = onConfirmProposal,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("confirm_proposal_button")
                                ) {
                                    Text("Confirm & Save")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BriefingSectionLabel(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@Composable
private fun BriefingAppointmentRow(
    appointment: Appointment,
    linkedTasksCount: Int,
    onClick: () -> Unit,
    onToggleComplete: () -> Unit
) {
    val category = appointment.resolvedCategory()
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("briefing_appointment_${appointment.id}")
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(44.dp)
                    .clip(CircleShape)
                    .background(category.accentColor)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = DateUtils.formatTimeRange(
                            appointment.startMinute,
                            appointment.endMinute,
                            appointment.allDay
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (appointment.reminderEnabled && !appointment.completed) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsActive,
                            contentDescription = "Reminder active",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    if (linkedTasksCount > 0) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "$linkedTasksCount task${if (linkedTasksCount > 1) "s" else ""}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = appointment.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (appointment.completed) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (appointment.location.isNotBlank() || appointment.attendees.isNotBlank()) {
                    val subtitle = listOf(appointment.location, appointment.attendees)
                        .filter { it.isNotBlank() }
                        .joinToString(" • ")
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier.testTag("briefing_toggle_appt_${appointment.id}")
            ) {
                Icon(
                    imageVector = if (appointment.completed) {
                        Icons.Filled.CheckCircle
                    } else {
                        Icons.Outlined.RadioButtonUnchecked
                    },
                    contentDescription = if (appointment.completed) {
                        "Mark appointment incomplete"
                    } else {
                        "Mark appointment complete"
                    },
                    tint = if (appointment.completed) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
        }
    }
}

@Composable
private fun BriefingPendingTaskRow(
    task: SecretaryTask,
    todayKey: String,
    onToggleComplete: () -> Unit,
    onClick: () -> Unit
) {
    val isOverdue = task.dueDateKey.isNotBlank() && task.dueDateKey < todayKey
    val isDueToday = task.dueDateKey == todayKey
    val priority = task.resolvedPriority()

    val (priorityBg, priorityFg) = when (priority) {
        TaskPriority.HIGH -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        TaskPriority.NORMAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
        TaskPriority.LOW -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f) to MaterialTheme.colorScheme.onTertiaryContainer
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("briefing_task_${task.id}")
    ) {
        Row(
            modifier = Modifier.padding(start = 6.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier.testTag("briefing_toggle_task_${task.id}")
            ) {
                Icon(
                    imageVector = if (task.completed) {
                        Icons.Filled.CheckCircle
                    } else {
                        Icons.Outlined.RadioButtonUnchecked
                    },
                    contentDescription = if (task.completed) "Mark task incomplete" else "Mark task complete",
                    tint = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val dueText = when {
                        isOverdue -> "Overdue • ${DateUtils.formatShortDate(task.dueDateKey)}"
                        isDueToday -> "Due Today"
                        task.dueDateKey.isNotBlank() -> "Due ${DateUtils.formatShortDate(task.dueDateKey)}"
                        else -> "No due date"
                    }
                    Text(
                        text = dueText,
                        style = MaterialTheme.typography.bodySmall,
                        color = when {
                            isOverdue -> MaterialTheme.colorScheme.error
                            isDueToday -> MaterialTheme.colorScheme.secondary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    if (task.linkedAppointmentTitle.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Link,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = task.linkedAppointmentTitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Surface(
                color = priorityBg,
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = priority.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = priorityFg,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun BriefingEmptyStateCard(
    filter: BriefingFeedFilter,
    onNewAppointment: () -> Unit,
    onNewTask: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_empty_schedule),
                    contentDescription = "Clear daily briefing",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(68.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = when (filter) {
                            BriefingFeedFilter.ALL -> "Your desk is clear today"
                            BriefingFeedFilter.APPOINTMENTS -> "No appointments scheduled today"
                            BriefingFeedFilter.TASKS -> "No pending tasks"
                        },
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Add an appointment, set a reminder, or capture a task above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onNewAppointment,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Add Event")
                }
                OutlinedButton(
                    onClick = onNewTask,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Add Task")
                }
            }
        }
    }
}
