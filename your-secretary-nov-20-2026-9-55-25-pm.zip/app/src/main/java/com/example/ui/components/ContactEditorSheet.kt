package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.location.LocationHelper
import com.example.model.ContactGroup
import com.example.model.SecretaryContact
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactEditorSheet(
    editingContact: SecretaryContact?,
    onDismiss: () -> Unit,
    onSave: (
        existingId: String?,
        name: String,
        role: String,
        company: String,
        email: String,
        phone: String,
        location: String,
        group: ContactGroup,
        notes: String,
        favorite: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember { mutableStateOf(editingContact?.name.orEmpty()) }
    var role by remember { mutableStateOf(editingContact?.role.orEmpty()) }
    var company by remember { mutableStateOf(editingContact?.company.orEmpty()) }
    var email by remember { mutableStateOf(editingContact?.email.orEmpty()) }
    var phone by remember { mutableStateOf(editingContact?.phone.orEmpty()) }
    var location by remember { mutableStateOf(editingContact?.location.orEmpty()) }
    var group by remember {
        mutableStateOf(editingContact?.resolvedGroup() ?: ContactGroup.COLLEAGUE)
    }
    var notes by remember { mutableStateOf(editingContact?.notes.orEmpty()) }
    var favorite by remember { mutableStateOf(editingContact?.favorite ?: false) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var isFetchingLocation by remember { mutableStateOf(false) }
    var locationError by remember { mutableStateOf<String?>(null) }

    fun requestCurrentLocation() {
        if (isFetchingLocation) return
        scope.launch {
            isFetchingLocation = true
            locationError = null
            LocationHelper.fetchCurrentLocationLabel(context)
                .onSuccess { resolved ->
                    location = resolved
                }
                .onFailure { err ->
                    locationError = err.localizedMessage ?: "Unable to fetch current location."
                }
            isFetchingLocation = false
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true) ||
            (grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
        if (granted) {
            requestCurrentLocation()
        } else {
            locationError = "Location permission denied. You can still enter an address manually."
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (editingContact == null) "New Contact" else "Edit Contact",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it.take(120)
                    validationError = null
                },
                label = { Text("Full name") },
                placeholder = { Text("e.g., Elena Rostova") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_name_input")
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Relationship / Group",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ContactGroup.entries.forEach { entry ->
                        FilterChip(
                            selected = group == entry,
                            onClick = { group = entry },
                            label = { Text(entry.label) },
                            modifier = Modifier.testTag("contact_group_${entry.name.lowercase()}")
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = role,
                    onValueChange = { role = it.take(120) },
                    label = { Text("Role / Title") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("contact_role_input")
                )
                OutlinedTextField(
                    value = company,
                    onValueChange = { company = it.take(120) },
                    label = { Text("Company") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("contact_company_input")
                )
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it.take(160) },
                label = { Text("Email (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_email_input")
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it.take(40) },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_phone_input")
            )

            OutlinedTextField(
                value = location,
                onValueChange = {
                    location = it.take(200)
                    locationError = null
                },
                label = { Text("Location / Address (optional)") },
                placeholder = { Text("Office address, city, or meeting place") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = {
                            val hasFine = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            val hasCoarse = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasFine || hasCoarse) {
                                requestCurrentLocation()
                            } else {
                                locationPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        },
                        enabled = !isFetchingLocation,
                        modifier = Modifier.testTag("contact_use_current_location_button")
                    ) {
                        if (isFetchingLocation) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.MyLocation,
                                contentDescription = "Use current location",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_location_input")
            )

            if (locationError != null) {
                Text(
                    text = locationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it.take(1000) },
                label = { Text("Secretary notes / preferences (optional)") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_notes_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Star as favorite contact",
                    style = MaterialTheme.typography.bodyMedium
                )
                Switch(
                    checked = favorite,
                    onCheckedChange = { favorite = it },
                    modifier = Modifier.testTag("contact_favorite_switch")
                )
            }

            if (validationError != null) {
                Text(
                    text = validationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text("Cancel")
                }
                Button(
                    onClick = {
                        if (name.trim().isEmpty()) {
                            validationError = "Please enter the contact's name."
                            return@Button
                        }
                        onSave(
                            editingContact?.id,
                            name,
                            role,
                            company,
                            email,
                            phone,
                            location,
                            group,
                            notes,
                            favorite
                        )
                        onDismiss()
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_contact_button")
                ) {
                    Text(if (editingContact == null) "Save Contact" else "Update Contact")
                }
            }
        }
    }
}
