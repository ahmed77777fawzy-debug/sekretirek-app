package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Appointment
import com.example.model.ScheduleViewMode
import com.example.model.SecretaryTask
import com.example.model.UiState
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(
    selectedDateKey: String,
    viewMode: ScheduleViewMode,
    appointmentsState: UiState<List<Appointment>>,
    tasksState: UiState<List<SecretaryTask>>,
    onSelectDate: (String) -> Unit,
    onViewModeChange: (ScheduleViewMode) -> Unit,
    onNavigatePeriod: (Boolean) -> Unit,
    onJumpToToday: () -> Unit,
    onAddAppointment: (String) -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onAddTaskForDate: (String) -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayKey = remember { DateUtils.todayDateKey() }
    val allAppointments = (appointmentsState as? UiState.Success)?.data.orEmpty()
    val allTasks = (tasksState as? UiState.Success)?.data.orEmpty()

    val appointmentsByDate = remember(allAppointments) {
        allAppointments.groupBy { it.dateKey }
    }
    val apptDateById = remember(allAppointments) {
        allAppointments.associate { it.id to it.dateKey }
    }
    val tasksByAppointmentId = remember(allTasks) {
        allTasks.filter { it.linkedAppointmentId.isNotBlank() }.groupBy { it.linkedAppointmentId }
    }
    val tasksByDate = remember(allTasks, apptDateById) {
        val grouped = mutableMapOf<String, MutableList<SecretaryTask>>()
        allTasks.forEach { task ->
            val effectiveDate = task.dueDateKey.ifBlank { apptDateById[task.linkedAppointmentId].orEmpty() }
            if (effectiveDate.isNotBlank()) {
                grouped.getOrPut(effectiveDate) { mutableListOf() }.add(task)
            }
        }
        grouped
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Day / Week / Month Switcher
            SingleChoiceSegmentedButtonRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("schedule_view_mode_switcher")
            ) {
                ScheduleViewMode.entries.forEachIndexed { index, mode ->
                    SegmentedButton(
                        selected = viewMode == mode,
                        onClick = { onViewModeChange(mode) },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = ScheduleViewMode.entries.size
                        ),
                        modifier = Modifier.testTag("view_mode_${mode.name.lowercase()}")
                    ) {
                        Text(mode.label)
                    }
                }
            }

            // Period Navigation Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onNavigatePeriod(false) },
                        modifier = Modifier.testTag("calendar_prev_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous"
                        )
                    }

                    Text(
                        text = when (viewMode) {
                            ScheduleViewMode.DAY -> DateUtils.formatFullDate(selectedDateKey)
                            ScheduleViewMode.WEEK -> {
                                val week = DateUtils.weekDateKeys(selectedDateKey)
                                "${DateUtils.formatShortDate(week.first())} – ${DateUtils.formatShortDate(week.last())}"
                            }
                            ScheduleViewMode.MONTH -> DateUtils.formatMonthYear(selectedDateKey)
                        },
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    IconButton(
                        onClick = { onNavigatePeriod(true) },
                        modifier = Modifier.testTag("calendar_next_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next"
                        )
                    }
                }

                if (selectedDateKey != todayKey) {
                    AssistChip(
                        onClick = onJumpToToday,
                        label = { Text("Today") },
                        modifier = Modifier.testTag("calendar_today_chip")
                    )
                }
            }

            when (appointmentsState) {
                UiState.Loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = appointmentsState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                is UiState.Success -> {
                    when (viewMode) {
                        ScheduleViewMode.DAY -> {
                            DayScheduleContent(
                                dateKey = selectedDateKey,
                                dayAppointments = appointmentsByDate[selectedDateKey].orEmpty(),
                                dayTasks = tasksByDate[selectedDateKey].orEmpty(),
                                tasksByAppointmentId = tasksByAppointmentId,
                                onAddAppointment = { onAddAppointment(selectedDateKey) },
                                onAppointmentClick = onAppointmentClick,
                                onAddTask = { onAddTaskForDate(selectedDateKey) },
                                onToggleTask = onToggleTask,
                                onEditTask = onEditTask,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        ScheduleViewMode.WEEK -> {
                            WeekScheduleContent(
                                selectedDateKey = selectedDateKey,
                                todayKey = todayKey,
                                appointmentsByDate = appointmentsByDate,
                                tasksByDate = tasksByDate,
                                tasksByAppointmentId = tasksByAppointmentId,
                                onSelectDate = onSelectDate,
                                onAddAppointment = { onAddAppointment(selectedDateKey) },
                                onAppointmentClick = onAppointmentClick,
                                onAddTask = { onAddTaskForDate(selectedDateKey) },
                                onToggleTask = onToggleTask,
                                onEditTask = onEditTask,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        ScheduleViewMode.MONTH -> {
                            MonthScheduleContent(
                                selectedDateKey = selectedDateKey,
                                todayKey = todayKey,
                                appointmentsByDate = appointmentsByDate,
                                tasksByDate = tasksByDate,
                                tasksByAppointmentId = tasksByAppointmentId,
                                onSelectDate = onSelectDate,
                                onAddAppointment = { onAddAppointment(selectedDateKey) },
                                onAppointmentClick = onAppointmentClick,
                                onAddTask = { onAddTaskForDate(selectedDateKey) },
                                onToggleTask = onToggleTask,
                                onEditTask = onEditTask,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayScheduleContent(
    dateKey: String,
    dayAppointments: List<Appointment>,
    dayTasks: List<SecretaryTask>,
    tasksByAppointmentId: Map<String, List<SecretaryTask>>,
    onAddAppointment: () -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onAddTask: () -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    modifier: Modifier = Modifier
) {
    val allDayEvents = dayAppointments.filter { it.allDay }
    val timedEvents = dayAppointments.filter { !it.allDay }
    val hours = (6..21).toList()

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 84.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Agenda Tasks for this day
        item {
            AgendaTasksSection(
                dateKey = dateKey,
                tasks = dayTasks,
                onAddTask = onAddTask,
                onToggleTask = onToggleTask,
                onEditTask = onEditTask
            )
        }

        if (allDayEvents.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "ALL DAY",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    allDayEvents.forEach { appt ->
                        ScheduleEventCard(
                            appointment = appt,
                            linkedTasks = tasksByAppointmentId[appt.id].orEmpty(),
                            onClick = { onAppointmentClick(appt) }
                        )
                    }
                }
            }
        }

        if (dayAppointments.isEmpty()) {
            item {
                EmptyDayCard(dateKey = dateKey, onAddAppointment = onAddAppointment)
            }
        } else {
            items(hours, key = { it }) { hour ->
                val hourStartMin = hour * 60L
                val hourEndMin = (hour + 1) * 60L
                val startingHere = timedEvents.filter {
                    it.startMinute in hourStartMin until hourEndMin
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = DateUtils.formatMinuteOfDay(hour * 60)
                                .replace(":00 ", "\n"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(44.dp)
                        )
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            if (startingHere.isEmpty()) {
                                Spacer(modifier = Modifier.height(22.dp))
                            } else {
                                startingHere.forEach { appt ->
                                    ScheduleEventCard(
                                        appointment = appt,
                                        linkedTasks = tasksByAppointmentId[appt.id].orEmpty(),
                                        onClick = { onAppointmentClick(appt) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            val offHours = timedEvents.filter { it.startMinute < 360L || it.startMinute >= 1320L }
            if (offHours.isNotEmpty()) {
                item {
                    Text(
                        text = "EARLY / LATE HOURS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(offHours, key = { "off_${it.id}" }) { appt ->
                    ScheduleEventCard(
                        appointment = appt,
                        linkedTasks = tasksByAppointmentId[appt.id].orEmpty(),
                        onClick = { onAppointmentClick(appt) }
                    )
                }
            }
        }
    }
}

@Composable
private fun WeekScheduleContent(
    selectedDateKey: String,
    todayKey: String,
    appointmentsByDate: Map<String, List<Appointment>>,
    tasksByDate: Map<String, List<SecretaryTask>>,
    tasksByAppointmentId: Map<String, List<SecretaryTask>>,
    onSelectDate: (String) -> Unit,
    onAddAppointment: () -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onAddTask: () -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    modifier: Modifier = Modifier
) {
    val weekKeys = remember(selectedDateKey) { DateUtils.weekDateKeys(selectedDateKey) }
    val selectedDayEvents = appointmentsByDate[selectedDateKey].orEmpty()
    val selectedDayTasks = tasksByDate[selectedDateKey].orEmpty()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                weekKeys.forEach { dayKey ->
                    val isSelected = dayKey == selectedDateKey
                    val isToday = dayKey == todayKey
                    val dayEvents = appointmentsByDate[dayKey].orEmpty()
                    val hasOpenTasks = tasksByDate[dayKey].orEmpty().any { !it.completed }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surface.copy(alpha = 0f)
                            )
                            .clickable { onSelectDate(dayKey) }
                            .padding(vertical = 8.dp)
                            .testTag("week_day_$dayKey")
                    ) {
                        Text(
                            text = DateUtils.dayOfWeekShort(dayKey).take(3),
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                isSelected -> MaterialTheme.colorScheme.onPrimary
                                isToday -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Text(
                            text = DateUtils.dayNumber(dayKey).toString(),
                            style = MaterialTheme.typography.titleMedium,
                            color = when {
                                isSelected -> MaterialTheme.colorScheme.onPrimary
                                isToday -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                            modifier = Modifier.height(6.dp)
                        ) {
                            dayEvents.take(2).forEach { appt ->
                                Box(
                                    modifier = Modifier
                                        .size(5.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.onPrimary
                                            else appt.resolvedCategory().accentColor
                                        )
                                )
                            }
                            if (hasOpenTasks) {
                                Box(
                                    modifier = Modifier
                                        .size(5.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.onPrimary
                                            else MaterialTheme.colorScheme.secondary
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = DateUtils.formatFullDate(selectedDateKey),
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "${selectedDayEvents.size} events • ${selectedDayTasks.size} tasks",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 84.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                AgendaTasksSection(
                    dateKey = selectedDateKey,
                    tasks = selectedDayTasks,
                    onAddTask = onAddTask,
                    onToggleTask = onToggleTask,
                    onEditTask = onEditTask
                )
            }
            if (selectedDayEvents.isEmpty()) {
                item {
                    EmptyDayCard(dateKey = selectedDateKey, onAddAppointment = onAddAppointment)
                }
            } else {
                items(selectedDayEvents, key = { it.id }) { appt ->
                    ScheduleEventCard(
                        appointment = appt,
                        linkedTasks = tasksByAppointmentId[appt.id].orEmpty(),
                        onClick = { onAppointmentClick(appt) }
                    )
                }
            }
        }
    }
}

@Composable
private fun MonthScheduleContent(
    selectedDateKey: String,
    todayKey: String,
    appointmentsByDate: Map<String, List<Appointment>>,
    tasksByDate: Map<String, List<SecretaryTask>>,
    tasksByAppointmentId: Map<String, List<SecretaryTask>>,
    onSelectDate: (String) -> Unit,
    onAddAppointment: () -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onAddTask: () -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    modifier: Modifier = Modifier
) {
    val cells = remember(selectedDateKey) { DateUtils.monthGridCells(selectedDateKey) }
    val selectedDayEvents = appointmentsByDate[selectedDateKey].orEmpty()
    val selectedDayTasks = tasksByDate[selectedDateKey].orEmpty()
    val weekdayHeaders = listOf("M", "T", "W", "T", "F", "S", "S")

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 84.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        weekdayHeaders.forEach { label ->
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 6.dp)
                            )
                        }
                    }

                    cells.chunked(7).forEach { weekRow ->
                        Row(modifier = Modifier.fillMaxWidth()) {
                            weekRow.forEach { cell ->
                                val isSelected = cell.dateKey == selectedDateKey
                                val isToday = cell.dateKey == todayKey
                                val events = appointmentsByDate[cell.dateKey].orEmpty()
                                val hasOpenTasks = tasksByDate[cell.dateKey].orEmpty().any { !it.completed }

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            when {
                                                isSelected -> MaterialTheme.colorScheme.primary
                                                else -> MaterialTheme.colorScheme.surface.copy(alpha = 0f)
                                            }
                                        )
                                        .then(
                                            if (isToday && !isSelected) {
                                                Modifier.border(
                                                    width = 1.5.dp,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    shape = RoundedCornerShape(10.dp)
                                                )
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .clickable { onSelectDate(cell.dateKey) }
                                        .testTag("month_cell_${cell.dateKey}")
                                ) {
                                    Text(
                                        text = cell.dayOfMonth.toString(),
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = when {
                                            isSelected -> MaterialTheme.colorScheme.onPrimary
                                            !cell.inCurrentMonth -> MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                                alpha = 0.45f
                                            )
                                            isToday -> MaterialTheme.colorScheme.primary
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                        modifier = Modifier.height(5.dp)
                                    ) {
                                        events.take(2).forEach { appt ->
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.onPrimary
                                                        else appt.resolvedCategory().accentColor
                                                    )
                                            )
                                        }
                                        if (hasOpenTasks) {
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.onPrimary
                                                        else MaterialTheme.colorScheme.secondary
                                                    )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = DateUtils.formatFullDate(selectedDateKey),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "${selectedDayEvents.size} events • ${selectedDayTasks.size} tasks",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            AgendaTasksSection(
                dateKey = selectedDateKey,
                tasks = selectedDayTasks,
                onAddTask = onAddTask,
                onToggleTask = onToggleTask,
                onEditTask = onEditTask
            )
        }

        if (selectedDayEvents.isEmpty()) {
            item {
                EmptyDayCard(dateKey = selectedDateKey, onAddAppointment = onAddAppointment)
            }
        } else {
            items(selectedDayEvents, key = { it.id }) { appt ->
                ScheduleEventCard(
                    appointment = appt,
                    linkedTasks = tasksByAppointmentId[appt.id].orEmpty(),
                    onClick = { onAppointmentClick(appt) }
                )
            }
        }
    }
}

@Composable
private fun AgendaTasksSection(
    dateKey: String,
    tasks: List<SecretaryTask>,
    onAddTask: () -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.TaskAlt,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Tasks Due ${DateUtils.formatShortDate(dateKey)} (${tasks.count { !it.completed }} open)",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                TextButton(
                    onClick = onAddTask,
                    modifier = Modifier.testTag("agenda_add_task_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Task")
                }
            }

            if (tasks.isEmpty()) {
                Text(
                    text = "No tasks scheduled for this date.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                tasks.forEach { task ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .clickable { onEditTask(task) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("agenda_task_${task.id}"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { onToggleTask(task) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (task.completed) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                contentDescription = "Toggle task",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.bodyMedium,
                                textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (task.linkedAppointmentTitle.isNotBlank()) {
                                Text(
                                    text = "Linked: ${task.linkedAppointmentTitle}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = task.resolvedPriority().label,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScheduleEventCard(
    appointment: Appointment,
    linkedTasks: List<SecretaryTask>,
    onClick: () -> Unit
) {
    val category = appointment.resolvedCategory()
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("appointment_card_${appointment.id}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(48.dp)
                    .clip(CircleShape)
                    .background(category.accentColor)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = DateUtils.formatTimeRange(
                            appointment.startMinute,
                            appointment.endMinute,
                            appointment.allDay
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = category.accentColor
                    )
                    Surface(
                        color = category.accentColor.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = category.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = category.accentColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (linkedTasks.isNotEmpty()) {
                        val doneCount = linkedTasks.count { it.completed }
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "$doneCount/${linkedTasks.size} tasks",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (appointment.linkedContactIds.isNotEmpty()) {
                        val cCount = appointment.linkedContactIds.size
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "$cCount contact${if (cCount > 1) "s" else ""}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = appointment.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (appointment.completed) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (appointment.location.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = appointment.location,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            if (appointment.reminderEnabled && !appointment.completed) {
                Icon(
                    imageVector = Icons.Filled.NotificationsActive,
                    contentDescription = "Reminder enabled",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyDayCard(
    dateKey: String,
    onAddAppointment: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_schedule),
                contentDescription = "No appointments scheduled",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(132.dp)
                    .clip(RoundedCornerShape(14.dp))
            )
            Text(
                text = "Nothing scheduled for ${DateUtils.formatShortDate(dateKey)}",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "Reserve time for meetings, focused work, or personal reminders.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onAddAppointment,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("empty_day_add_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Appointment")
            }
        }
    }
}
