package com.example.data

import android.content.Context
import com.example.R
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.Appointment
import com.example.model.AppointmentCategory
import com.example.model.ContactGroup
import com.example.model.ExecutiveMemo
import com.example.model.SecretaryContact
import com.example.model.SecretaryTask
import com.example.model.TaskPriority
import com.example.util.DateUtils
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class SecretaryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeAppointments(userId: String): Flow<List<Appointment>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/appointments"
        emitAll(
            db.collection("users").document(uid).collection("appointments")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Appointment::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareBy<Appointment> { it.dateKey }
                            .thenByDescending { it.allDay }
                            .thenBy { it.startMinute }
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeTasks(userId: String): Flow<List<SecretaryTask>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/tasks"
        emitAll(
            db.collection("users").document(uid).collection("tasks")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        SecretaryTask::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareBy<SecretaryTask> { it.completed }
                            .thenBy { priorityRank(it.resolvedPriority()) }
                            .thenBy { it.dueDateKey.ifBlank { "9999-99-99" } }
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMemos(userId: String): Flow<List<ExecutiveMemo>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/memos"
        emitAll(
            db.collection("users").document(uid).collection("memos")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ExecutiveMemo::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareByDescending<ExecutiveMemo> { it.pinned }
                            .thenByDescending { it.updatedAt?.seconds ?: 0L }
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeContacts(userId: String): Flow<List<SecretaryContact>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/contacts"
        emitAll(
            db.collection("users").document(uid).collection("contacts")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        SecretaryContact::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareByDescending<SecretaryContact> { it.favorite }
                            .thenBy { it.name.lowercase() }
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveAppointment(
        existingId: String?,
        title: String,
        dateKey: String,
        startMinute: Int,
        endMinute: Int,
        allDay: Boolean,
        category: AppointmentCategory,
        location: String,
        attendees: String,
        linkedContactIds: List<String> = emptyList(),
        notes: String,
        reminderEnabled: Boolean,
        reminderMinutesBefore: Int,
        completed: Boolean = false
    ): Result<String> {
        val trimmedTitle = title.trim().take(120)
        if (trimmedTitle.isBlank()) {
            return Result.failure(IllegalArgumentException("Appointment title cannot be empty."))
        }
        if (!DateUtils.isValidDateKey(dateKey)) {
            return Result.failure(IllegalArgumentException("Invalid appointment date."))
        }
        val safeStart = if (allDay) 0 else startMinute.coerceIn(0, 1439)
        val safeEnd = if (allDay) 1440 else endMinute.coerceIn(safeStart + 1, 1440)
        val safeReminderMin = reminderMinutesBefore.coerceIn(0, 10080)
        val cleanContactIds = linkedContactIds
            .map { it.trim() }
            .filter { it.isNotBlank() && it.length <= 128 }
            .distinct()
            .take(25)

        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/appointments"
        val op = if (existingId.isNullOrBlank()) OperationType.CREATE else OperationType.UPDATE
        return try {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("appointments")
            val docRef = if (existingId.isNullOrBlank()) col.document() else col.document(existingId)
            path = docRef.path

            if (existingId.isNullOrBlank()) {
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("title", trimmedTitle)
                    put("dateKey", dateKey)
                    put("startMinute", safeStart.toLong())
                    put("endMinute", safeEnd.toLong())
                    put("allDay", allDay)
                    put("category", category.name)
                    put("location", location.trim().take(200))
                    put("attendees", attendees.trim().take(300))
                    put("linkedContactIds", cleanContactIds)
                    put("notes", notes.trim().take(1000))
                    put("reminderEnabled", reminderEnabled)
                    put("reminderMinutesBefore", safeReminderMin.toLong())
                    put("completed", completed)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            } else {
                val payload = mapOf(
                    "title" to trimmedTitle,
                    "dateKey" to dateKey,
                    "startMinute" to safeStart.toLong(),
                    "endMinute" to safeEnd.toLong(),
                    "allDay" to allDay,
                    "category" to category.name,
                    "location" to location.trim().take(200),
                    "attendees" to attendees.trim().take(300),
                    "linkedContactIds" to cleanContactIds,
                    "notes" to notes.trim().take(1000),
                    "reminderEnabled" to reminderEnabled,
                    "reminderMinutesBefore" to safeReminderMin.toLong(),
                    "completed" to completed,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(payload).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    suspend fun updateAppointmentLinkedContacts(
        appointmentId: String,
        linkedContactIds: List<String>,
        attendees: String
    ): Result<Unit> {
        val cleanContactIds = linkedContactIds
            .map { it.trim() }
            .filter { it.isNotBlank() && it.length <= 128 }
            .distinct()
            .take(25)
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/appointments/$appointmentId"
        return try {
            val uid = requireUserId()
            require(appointmentId.isNotBlank()) { "Appointment ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("appointments").document(appointmentId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "linkedContactIds" to cleanContactIds,
                    "attendees" to attendees.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleAppointmentCompleted(appointmentId: String, completed: Boolean): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/appointments/$appointmentId"
        return try {
            val uid = requireUserId()
            require(appointmentId.isNotBlank()) { "Appointment ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("appointments").document(appointmentId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "completed" to completed,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteAppointment(appointmentId: String): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/appointments/$appointmentId"
        return try {
            val uid = requireUserId()
            require(appointmentId.isNotBlank()) { "Appointment ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("appointments").document(appointmentId)
            path = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveTask(
        existingId: String?,
        title: String,
        details: String,
        dueDateKey: String,
        linkedAppointmentId: String,
        linkedAppointmentTitle: String,
        priority: TaskPriority,
        completed: Boolean = false
    ): Result<Unit> {
        val trimmedTitle = title.trim().take(160)
        if (trimmedTitle.isBlank()) {
            return Result.failure(IllegalArgumentException("Task title cannot be empty."))
        }
        val cleanDueDate = if (dueDateKey.isNotBlank() && DateUtils.isValidDateKey(dueDateKey)) dueDateKey else ""
        val cleanApptId = linkedAppointmentId.trim().take(128)
        val cleanApptTitle = if (cleanApptId.isNotBlank()) linkedAppointmentTitle.trim().take(120) else ""
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/tasks"
        val op = if (existingId.isNullOrBlank()) OperationType.CREATE else OperationType.UPDATE
        return try {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("tasks")
            val docRef = if (existingId.isNullOrBlank()) col.document() else col.document(existingId)
            path = docRef.path

            if (existingId.isNullOrBlank()) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "title" to trimmedTitle,
                        "details" to details.trim().take(1000),
                        "dueDateKey" to cleanDueDate,
                        "linkedAppointmentId" to cleanApptId,
                        "linkedAppointmentTitle" to cleanApptTitle,
                        "priority" to priority.name,
                        "completed" to completed,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "title" to trimmedTitle,
                        "details" to details.trim().take(1000),
                        "dueDateKey" to cleanDueDate,
                        "linkedAppointmentId" to cleanApptId,
                        "linkedAppointmentTitle" to cleanApptTitle,
                        "priority" to priority.name,
                        "completed" to completed,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    suspend fun toggleTaskCompleted(taskId: String, completed: Boolean): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/tasks/$taskId"
        return try {
            val uid = requireUserId()
            require(taskId.isNotBlank()) { "Task ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "completed" to completed,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTask(taskId: String): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/tasks/$taskId"
        return try {
            val uid = requireUserId()
            require(taskId.isNotBlank()) { "Task ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
            path = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveMemo(
        existingId: String?,
        title: String,
        body: String,
        pinned: Boolean,
        aiDraft: String = ""
    ): Result<Unit> {
        val trimmedTitle = title.trim().take(120)
        val trimmedBody = body.trim().take(4000)
        if (trimmedTitle.isBlank() || trimmedBody.isBlank()) {
            return Result.failure(IllegalArgumentException("Memo title and content are required."))
        }
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/memos"
        val op = if (existingId.isNullOrBlank()) OperationType.CREATE else OperationType.UPDATE
        return try {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("memos")
            val docRef = if (existingId.isNullOrBlank()) col.document() else col.document(existingId)
            path = docRef.path

            if (existingId.isNullOrBlank()) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "title" to trimmedTitle,
                        "body" to trimmedBody,
                        "pinned" to pinned,
                        "aiDraft" to aiDraft.trim().take(4000),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "title" to trimmedTitle,
                        "body" to trimmedBody,
                        "pinned" to pinned,
                        "aiDraft" to aiDraft.trim().take(4000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    suspend fun updateMemoAiDraft(memoId: String, aiDraft: String): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/memos/$memoId"
        return try {
            val uid = requireUserId()
            require(memoId.isNotBlank()) { "Memo ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("memos").document(memoId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "aiDraft" to aiDraft.trim().take(4000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleMemoPinned(memoId: String, pinned: Boolean): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/memos/$memoId"
        return try {
            val uid = requireUserId()
            require(memoId.isNotBlank()) { "Memo ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("memos").document(memoId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "pinned" to pinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteMemo(memoId: String): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/memos/$memoId"
        return try {
            val uid = requireUserId()
            require(memoId.isNotBlank()) { "Memo ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("memos").document(memoId)
            path = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveContact(
        existingId: String?,
        name: String,
        role: String,
        company: String,
        email: String,
        phone: String,
        location: String = "",
        group: ContactGroup,
        notes: String,
        favorite: Boolean = false
    ): Result<String> {
        val trimmedName = name.trim().take(120)
        if (trimmedName.isBlank()) {
            return Result.failure(IllegalArgumentException("Contact name cannot be empty."))
        }
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/contacts"
        val op = if (existingId.isNullOrBlank()) OperationType.CREATE else OperationType.UPDATE
        return try {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("contacts")
            val docRef = if (existingId.isNullOrBlank()) col.document() else col.document(existingId)
            path = docRef.path

            if (existingId.isNullOrBlank()) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "name" to trimmedName,
                        "role" to role.trim().take(120),
                        "company" to company.trim().take(120),
                        "email" to email.trim().take(160),
                        "phone" to phone.trim().take(40),
                        "location" to location.trim().take(200),
                        "category" to group.name,
                        "notes" to notes.trim().take(1000),
                        "favorite" to favorite,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "name" to trimmedName,
                        "role" to role.trim().take(120),
                        "company" to company.trim().take(120),
                        "email" to email.trim().take(160),
                        "phone" to phone.trim().take(40),
                        "location" to location.trim().take(200),
                        "category" to group.name,
                        "notes" to notes.trim().take(1000),
                        "favorite" to favorite,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    suspend fun toggleContactFavorite(contactId: String, favorite: Boolean): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/contacts/$contactId"
        return try {
            val uid = requireUserId()
            require(contactId.isNotBlank()) { "Contact ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("contacts").document(contactId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "favorite" to favorite,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteContact(contactId: String): Result<Unit> {
        var path = "users/${auth.currentUser?.uid ?: "unauthenticated"}/contacts/$contactId"
        return try {
            val uid = requireUserId()
            require(contactId.isNotBlank()) { "Contact ID cannot be blank" }
            val docRef = db.collection("users").document(uid).collection("contacts").document(contactId)
            path = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun priorityRank(priority: TaskPriority): Int = when (priority) {
        TaskPriority.HIGH -> 0
        TaskPriority.NORMAL -> 1
        TaskPriority.LOW -> 2
    }
}
