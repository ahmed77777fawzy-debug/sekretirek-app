package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Workspaces
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.Workspaces
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.auth.signOut
import com.example.i18n.AppStrings
import com.example.i18n.CurrencyManager
import com.example.i18n.LanguageManager
import com.example.i18n.LocalAppCurrency
import com.example.i18n.LocalAppStrings
import com.example.model.Appointment
import com.example.model.BusinessSubscription
import com.example.model.Organization
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.SecretaryContact
import com.example.model.SecretaryTask
import com.example.model.UiState
import com.example.ui.components.AppointmentDetailSheet
import com.example.ui.components.AppointmentEditorSheet
import com.example.ui.components.BusinessSubscriptionSheet
import com.example.ui.components.ContactDetailSheet
import com.example.ui.components.ContactEditorSheet
import com.example.ui.components.CounterEditorSheet
import com.example.ui.components.CurrencyPickerDialog
import com.example.ui.components.LanguagePickerDialog
import com.example.ui.components.OrganizationBookingSheet
import com.example.ui.components.OrganizationEditorSheet
import com.example.ui.components.TaskEditorSheet
import com.example.ui.components.VisualQueueDisplayDialog
import com.example.ui.screens.BusinessPortalScreen
import com.example.ui.screens.ExecutiveDeskScreen
import com.example.ui.screens.MyQueueAndAgendaScreen
import com.example.ui.screens.QueueHubScreen
import com.example.ui.screens.SecretaryChatScreen
import com.example.viewmodel.QueueViewModel
import com.example.viewmodel.SecretaryViewModel
import kotlinx.coroutines.launch

enum class MainTab(
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    QUEUE_HUB(Icons.Filled.Explore, Icons.Outlined.Explore, "nav_queue_hub"),
    MY_QUEUE(Icons.Filled.ConfirmationNumber, Icons.Outlined.ConfirmationNumber, "nav_my_queue"),
    BUSINESS(Icons.Filled.Storefront, Icons.Outlined.Storefront, "nav_business"),
    DESK(Icons.Filled.Workspaces, Icons.Outlined.Workspaces, "nav_desk"),
    SECRETARY(Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_secretary");

    fun label(strings: AppStrings): String = when (this) {
        QUEUE_HUB -> strings.navQueueHub
        MY_QUEUE -> strings.navMyQueue
        BUSINESS -> strings.navBusiness
        DESK -> strings.navDesk
        SECRETARY -> strings.navSecretary
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(
    viewModel: SecretaryViewModel,
    queueViewModel: QueueViewModel,
    languageManager: LanguageManager,
    currencyManager: CurrencyManager,
    userEmail: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }
    val strings = LocalAppStrings.current
    val currentCurrency = LocalAppCurrency.current

    val appLanguage by languageManager.appLanguage.collectAsStateWithLifecycle()
    val chatTargetLanguage by languageManager.chatTargetLanguage.collectAsStateWithLifecycle()
    val autoTranslateChat by languageManager.autoTranslateChat.collectAsStateWithLifecycle()
    val isTranslatingUi by languageManager.isTranslatingUi.collectAsStateWithLifecycle()

    // Personal Executive Secretary states
    val appointmentsState by viewModel.appointmentsState.collectAsStateWithLifecycle()
    val tasksState by viewModel.tasksState.collectAsStateWithLifecycle()
    val memosState by viewModel.memosState.collectAsStateWithLifecycle()
    val contactsState by viewModel.contactsState.collectAsStateWithLifecycle()
    val selectedDateKey by viewModel.selectedDateKey.collectAsStateWithLifecycle()
    val viewMode by viewModel.scheduleViewMode.collectAsStateWithLifecycle()
    val smartBriefingState by viewModel.smartBriefingState.collectAsStateWithLifecycle()
    val isParsingCommand by viewModel.isParsingCommand.collectAsStateWithLifecycle()
    val pendingProposal by viewModel.pendingProposal.collectAsStateWithLifecycle()
    val commandError by viewModel.commandError.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val draftingMemoId by viewModel.draftingMemoId.collectAsStateWithLifecycle()
    val isTranslatingDraft by viewModel.isTranslatingDraft.collectAsStateWithLifecycle()
    val isTranslatingAllChat by viewModel.isTranslatingAllChat.collectAsStateWithLifecycle()
    val conversationTurns by viewModel.conversationTurns.collectAsStateWithLifecycle()
    val isTranslatingConversation by viewModel.isTranslatingConversation.collectAsStateWithLifecycle()
    val pastedConversationResult by viewModel.pastedConversationResult.collectAsStateWithLifecycle()

    // Cloud Queue & Business Portal states
    val publicOrgsState by queueViewModel.publicOrganizationsState.collectAsStateWithLifecycle()
    val ownedOrgsState by queueViewModel.ownedOrganizationsState.collectAsStateWithLifecycle()
    val selectedOwnedOrgId by queueViewModel.selectedOwnedOrgId.collectAsStateWithLifecycle()
    val publicCountersState by queueViewModel.publicCountersState.collectAsStateWithLifecycle()
    val ownedCountersState by queueViewModel.ownedCountersState.collectAsStateWithLifecycle()
    val visitorTicketsState by queueViewModel.visitorTicketsState.collectAsStateWithLifecycle()
    val ownerTicketsState by queueViewModel.ownerTicketsState.collectAsStateWithLifecycle()
    val activeOrgCustomers by queueViewModel.activeOrgCustomers.collectAsStateWithLifecycle()
    val subscriptionsState by queueViewModel.subscriptionsState.collectAsStateWithLifecycle()
    val aiMatchedOrgIds by queueViewModel.aiMatchedOrgIds.collectAsStateWithLifecycle()
    val isRunningAiSearch by queueViewModel.isRunningAiSearch.collectAsStateWithLifecycle()
    val isSubmittingBooking by queueViewModel.isSubmittingBooking.collectAsStateWithLifecycle()
    val liveDashboardCounters by queueViewModel.liveDashboardCounters.collectAsStateWithLifecycle()

    val allAppointments = (appointmentsState as? UiState.Success)?.data.orEmpty()
    val allTasks = (tasksState as? UiState.Success)?.data.orEmpty()
    val allContacts = (contactsState as? UiState.Success)?.data.orEmpty()
    val allPublicOrgs = (publicOrgsState as? UiState.Success)?.data.orEmpty()
    val allVisitorTickets = (visitorTicketsState as? UiState.Success)?.data.orEmpty()

    var currentTab by remember { mutableStateOf(MainTab.QUEUE_HUB) }
    var deskSectionIndex by remember { mutableStateOf(0) }
    var showAccountMenu by remember { mutableStateOf(false) }
    var showLanguagePicker by remember { mutableStateOf(false) }
    var showCurrencyPicker by remember { mutableStateOf(false) }

    // Secretary editors & inspectors
    var showAppointmentEditor by remember { mutableStateOf(false) }
    var editorInitialDateKey by remember { mutableStateOf(selectedDateKey) }
    var appointmentInitialLinkedContactIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var editingAppointment by remember { mutableStateOf<Appointment?>(null) }
    var inspectingAppointment by remember { mutableStateOf<Appointment?>(null) }

    var showTaskEditor by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<SecretaryTask?>(null) }
    var taskInitialDateKey by remember { mutableStateOf(selectedDateKey) }
    var taskInitialAppointment by remember { mutableStateOf<Appointment?>(null) }

    var showContactEditor by remember { mutableStateOf(false) }
    var editingContact by remember { mutableStateOf<SecretaryContact?>(null) }
    var inspectingContact by remember { mutableStateOf<SecretaryContact?>(null) }

    // Cloud Queue sheets & dialogs
    var bookingOrg by remember { mutableStateOf<Organization?>(null) }
    var showOrgEditor by remember { mutableStateOf(false) }
    var editingOrg by remember { mutableStateOf<Organization?>(null) }
    var counterEditorTargetOrg by remember { mutableStateOf<Organization?>(null) }
    var editingCounter by remember { mutableStateOf<QueueCounter?>(null) }
    var subscriptionTarget by remember { mutableStateOf<Pair<Organization, BusinessSubscription?>?>(null) }
    var visualDisplayPayload by remember { mutableStateOf<Triple<Organization, List<QueueCounter>, List<QueueTicket>>?>(null) }

    LaunchedEffect(viewModel) {
        viewModel.snackbarMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }
    LaunchedEffect(queueViewModel) {
        queueViewModel.snackbarMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    BackHandler(enabled = currentTab != MainTab.QUEUE_HUB) {
        currentTab = MainTab.QUEUE_HUB
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useRail) {
                NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                    MainTab.entries.forEach { tab ->
                        val tabLabel = tab.label(strings)
                        NavigationRailItem(
                            selected = currentTab == tab,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == tab) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tabLabel
                                )
                            },
                            label = { Text(tabLabel, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    Column {
                        TopAppBar(
                            title = {
                                Text(
                                    text = when (currentTab) {
                                        MainTab.QUEUE_HUB -> strings.titleQueueHub
                                        MainTab.MY_QUEUE -> strings.titleMyQueue
                                        MainTab.BUSINESS -> strings.titleBusinessPortal
                                        MainTab.DESK -> strings.titleDesk
                                        MainTab.SECRETARY -> strings.titleSecretary
                                    },
                                    style = MaterialTheme.typography.titleLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background
                            ),
                            actions = {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { showCurrencyPicker = true }
                                        .testTag("currency_picker_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CurrencyExchange,
                                            contentDescription = strings.currencySettingsTitle,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = currentCurrency.code,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .padding(end = 2.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { showLanguagePicker = true }
                                        .testTag("language_picker_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Language,
                                            contentDescription = strings.languageSettingsTitle,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = appLanguage.shortBadge,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                Box {
                                    IconButton(
                                        onClick = { showAccountMenu = true },
                                        modifier = Modifier.testTag("account_menu_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.AccountCircle,
                                            contentDescription = "Account menu"
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showAccountMenu,
                                        onDismissRequest = { showAccountMenu = false }
                                    ) {
                                        if (userEmail.isNotBlank()) {
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = userEmail,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                },
                                                onClick = { showAccountMenu = false }
                                            )
                                        }
                                        DropdownMenuItem(
                                            text = { Text("${strings.currencySettingsTitle} (${currentCurrency.code})") },
                                            leadingIcon = {
                                                Icon(Icons.Filled.CurrencyExchange, contentDescription = null)
                                            },
                                            onClick = {
                                                showAccountMenu = false
                                                showCurrencyPicker = true
                                            },
                                            modifier = Modifier.testTag("menu_currency_item")
                                        )
                                        DropdownMenuItem(
                                            text = { Text("${strings.languageSettingsTitle} (${appLanguage.nativeName})") },
                                            leadingIcon = {
                                                Icon(Icons.Filled.Language, contentDescription = null)
                                            },
                                            onClick = {
                                                showAccountMenu = false
                                                showLanguagePicker = true
                                            },
                                            modifier = Modifier.testTag("menu_language_item")
                                        )
                                        DropdownMenuItem(
                                            text = { Text(strings.signOut) },
                                            leadingIcon = {
                                                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                                            },
                                            onClick = {
                                                showAccountMenu = false
                                                signOut(credentialManager, scope)
                                            },
                                            modifier = Modifier.testTag("sign_out_menu_item")
                                        )
                                    }
                                }
                            }
                        )
                        if (isTranslatingUi) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                    }
                },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            MainTab.entries.forEach { tab ->
                                val tabLabel = tab.label(strings)
                                NavigationBarItem(
                                    selected = currentTab == tab,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentTab == tab) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tabLabel
                                        )
                                    },
                                    label = { Text(tabLabel, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                },
                floatingActionButton = {
                    when (currentTab) {
                        MainTab.BUSINESS -> {
                            ExtendedFloatingActionButton(
                                onClick = {
                                    editingOrg = null
                                    showOrgEditor = true
                                },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                icon = { Icon(Icons.Filled.AddBusiness, contentDescription = null) },
                                text = { Text(strings.createActivity) },
                                modifier = Modifier.testTag("fab_new_activity")
                            )
                        }
                        MainTab.MY_QUEUE -> {
                            ExtendedFloatingActionButton(
                                onClick = {
                                    editorInitialDateKey = selectedDateKey
                                    appointmentInitialLinkedContactIds = emptyList()
                                    editingAppointment = null
                                    showAppointmentEditor = true
                                },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                                text = { Text(strings.newAppointment) },
                                modifier = Modifier.testTag("fab_new_appointment")
                            )
                        }
                        MainTab.DESK -> {
                            if (deskSectionIndex == 2) {
                                ExtendedFloatingActionButton(
                                    onClick = {
                                        editingContact = null
                                        showContactEditor = true
                                    },
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary,
                                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                                    text = { Text(strings.newContact) },
                                    modifier = Modifier.testTag("fab_new_contact")
                                )
                            } else {
                                ExtendedFloatingActionButton(
                                    onClick = {
                                        editorInitialDateKey = selectedDateKey
                                        appointmentInitialLinkedContactIds = emptyList()
                                        editingAppointment = null
                                        showAppointmentEditor = true
                                    },
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary,
                                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                                    text = { Text(strings.newAppointment) },
                                    modifier = Modifier.testTag("fab_new_appointment")
                                )
                            }
                        }
                        else -> Unit
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentTab) {
                        MainTab.QUEUE_HUB -> {
                            QueueHubScreen(
                                organizationsState = publicOrgsState,
                                liveCountersByOrg = liveDashboardCounters,
                                activeVisitorTickets = allVisitorTickets,
                                aiMatchedOrgIds = aiMatchedOrgIds,
                                isRunningAiSearch = isRunningAiSearch,
                                onRunAiSearch = queueViewModel::runAiSmartSearch,
                                onClearAiSearch = queueViewModel::clearAiSmartSearch,
                                onOpenOrganization = { org ->
                                    queueViewModel.selectPublicOrg(org.id)
                                    bookingOrg = org
                                },
                                onOpenVisualDisplay = { org, counters ->
                                    visualDisplayPayload = Triple(org, counters, emptyList())
                                },
                                onCreateNewBusiness = {
                                    currentTab = MainTab.BUSINESS
                                    editingOrg = null
                                    showOrgEditor = true
                                }
                            )
                        }

                        MainTab.MY_QUEUE -> {
                            MyQueueAndAgendaScreen(
                                ticketsState = visitorTicketsState,
                                organizations = allPublicOrgs,
                                liveCountersByOrg = liveDashboardCounters,
                                selectedDateKey = selectedDateKey,
                                viewMode = viewMode,
                                appointmentsState = appointmentsState,
                                tasksState = tasksState,
                                onCancelTicket = queueViewModel::cancelVisitorTicket,
                                onOpenOrganization = { org ->
                                    queueViewModel.selectPublicOrg(org.id)
                                    bookingOrg = org
                                },
                                onOpenVisualDisplay = { org, counters ->
                                    visualDisplayPayload = Triple(org, counters, emptyList())
                                },
                                onExploreDirectory = { currentTab = MainTab.QUEUE_HUB },
                                onSelectDate = viewModel::selectDate,
                                onViewModeChange = viewModel::setScheduleViewMode,
                                onNavigatePeriod = viewModel::navigatePeriod,
                                onJumpToToday = viewModel::jumpToToday,
                                onAddAppointment = { dateKey ->
                                    editorInitialDateKey = dateKey
                                    appointmentInitialLinkedContactIds = emptyList()
                                    editingAppointment = null
                                    showAppointmentEditor = true
                                },
                                onAppointmentClick = { inspectingAppointment = it },
                                onAddTaskForDate = { dateKey ->
                                    editingTask = null
                                    taskInitialDateKey = dateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onToggleTask = viewModel::toggleTaskCompleted,
                                onEditTask = { task ->
                                    editingTask = task
                                    taskInitialDateKey = task.dueDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                }
                            )
                        }

                        MainTab.BUSINESS -> {
                            BusinessPortalScreen(
                                ownedOrganizationsState = ownedOrgsState,
                                selectedOrgId = selectedOwnedOrgId,
                                ownedCountersState = ownedCountersState,
                                ownerTicketsState = ownerTicketsState,
                                customers = activeOrgCustomers,
                                subscriptionsState = subscriptionsState,
                                onSelectOrg = queueViewModel::selectOwnedOrg,
                                onCreateOrg = {
                                    editingOrg = null
                                    showOrgEditor = true
                                },
                                onEditOrg = { org ->
                                    editingOrg = org
                                    showOrgEditor = true
                                },
                                onAddCounter = { org ->
                                    counterEditorTargetOrg = org
                                    editingCounter = null
                                },
                                onEditCounter = { org, counter ->
                                    counterEditorTargetOrg = org
                                    editingCounter = counter
                                },
                                onToggleCounterOpen = queueViewModel::toggleCounterOpen,
                                onResetCounterQueue = queueViewModel::resetCounterQueue,
                                onCallNext = queueViewModel::callNextForCounter,
                                onUpdateTicketStatus = queueViewModel::updateTicketStatus,
                                onOpenVisualDisplay = { org, counters, tickets ->
                                    visualDisplayPayload = Triple(org, counters, tickets)
                                },
                                onOpenSubscriptionSheet = { org, sub ->
                                    subscriptionTarget = org to sub
                                }
                            )
                        }

                        MainTab.DESK -> {
                            ExecutiveDeskScreen(
                                deskSectionIndex = deskSectionIndex,
                                onSelectDeskSection = { deskSectionIndex = it },
                                userDisplayName = viewModel.userDisplayName,
                                appointmentsState = appointmentsState,
                                tasksState = tasksState,
                                memosState = memosState,
                                contactsState = contactsState,
                                smartBriefingState = smartBriefingState,
                                isParsingCommand = isParsingCommand,
                                pendingProposal = pendingProposal,
                                commandError = commandError,
                                draftingMemoId = draftingMemoId,
                                onGenerateBriefing = viewModel::generateSmartDailyBriefing,
                                onParseQuickCommand = viewModel::parseQuickCommand,
                                onConfirmProposal = viewModel::confirmProposal,
                                onDismissProposal = viewModel::dismissProposal,
                                onOpenCalendar = { currentTab = MainTab.MY_QUEUE },
                                onNewAppointment = {
                                    editorInitialDateKey = selectedDateKey
                                    appointmentInitialLinkedContactIds = emptyList()
                                    editingAppointment = null
                                    showAppointmentEditor = true
                                },
                                onNewTask = {
                                    editingTask = null
                                    taskInitialDateKey = selectedDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onEditTask = { task ->
                                    editingTask = task
                                    taskInitialDateKey = task.dueDateKey
                                    taskInitialAppointment = null
                                    showTaskEditor = true
                                },
                                onAppointmentClick = { inspectingAppointment = it },
                                onToggleAppointment = viewModel::toggleAppointmentCompleted,
                                onToggleTask = viewModel::toggleTaskCompleted,
                                onDeleteTask = viewModel::deleteTask,
                                onOpenDateInCalendar = { dateKey ->
                                    viewModel.selectDate(dateKey)
                                    currentTab = MainTab.MY_QUEUE
                                },
                                onOpenLinkedAppointment = { apptId ->
                                    val found = allAppointments.firstOrNull { it.id == apptId }
                                    if (found != null) {
                                        viewModel.selectDate(found.dateKey)
                                        currentTab = MainTab.MY_QUEUE
                                        inspectingAppointment = found
                                    }
                                },
                                onSaveMemo = viewModel::saveMemo,
                                onToggleMemoPin = viewModel::toggleMemoPinned,
                                onDraftMemoFollowUp = viewModel::generateMemoFollowUpDraft,
                                onDeleteMemo = viewModel::deleteMemo,
                                onAddContact = {
                                    editingContact = null
                                    showContactEditor = true
                                },
                                onContactClick = { inspectingContact = it },
                                onToggleContactFavorite = viewModel::toggleContactFavorite
                            )
                        }

                        MainTab.SECRETARY -> {
                            SecretaryChatScreen(
                                messages = chatMessages,
                                chatTargetLanguage = chatTargetLanguage,
                                autoTranslate = autoTranslateChat,
                                isTranslatingDraft = isTranslatingDraft,
                                isTranslatingAll = isTranslatingAllChat,
                                conversationTurns = conversationTurns,
                                isTranslatingConversation = isTranslatingConversation,
                                pastedConversationResult = pastedConversationResult,
                                onSendMessage = { messageText ->
                                    viewModel.sendChatMessage(
                                        input = messageText,
                                        autoTranslateTarget = if (autoTranslateChat) chatTargetLanguage else null
                                    )
                                },
                                onSelectChatTargetLanguage = languageManager::selectChatTargetLanguage,
                                onToggleAutoTranslate = languageManager::setAutoTranslateChat,
                                onTranslateMessage = { msgId ->
                                    viewModel.translateChatMessage(msgId, chatTargetLanguage)
                                },
                                onToggleMessageTranslation = viewModel::toggleMessageTranslationVisibility,
                                onTranslateAllMessages = {
                                    viewModel.translateAllChatMessages(chatTargetLanguage)
                                },
                                onTranslateDraft = { draft, onTranslated ->
                                    viewModel.translateDraftText(draft, chatTargetLanguage, onTranslated)
                                },
                                onTranslateLiveTurn = viewModel::translateLiveDialogueTurn,
                                onTranslatePastedConversation = viewModel::translatePastedConversation,
                                onClearConversationTranslator = viewModel::clearConversationTranslator
                            )
                        }
                    }
                }
            }
        }
    }

    // Cloud Queue Booking Sheet
    bookingOrg?.let { org ->
        OrganizationBookingSheet(
            organization = org,
            countersState = publicCountersState,
            defaultVisitorName = viewModel.userDisplayName,
            isSubmitting = isSubmittingBooking,
            onOpenVisualDisplay = { counters ->
                visualDisplayPayload = Triple(org, counters, emptyList())
            },
            onBookTicket = { counter, visitorName, visitorPhone, visitorNotes, bookingType, dateKey, slotLabel, onBooked ->
                queueViewModel.bookQueueTicket(
                    org = org,
                    counter = counter,
                    visitorName = visitorName,
                    visitorPhone = visitorPhone,
                    visitorNotes = visitorNotes,
                    bookingType = bookingType,
                    dateKey = dateKey,
                    slotLabel = slotLabel,
                    onBooked = onBooked
                )
            },
            onDismiss = {
                bookingOrg = null
                queueViewModel.selectPublicOrg(null)
            }
        )
    }

    if (showOrgEditor) {
        OrganizationEditorSheet(
            editingOrg = editingOrg,
            onSave = queueViewModel::saveOrganization,
            onDismiss = { showOrgEditor = false }
        )
    }

    counterEditorTargetOrg?.let { targetOrg ->
        CounterEditorSheet(
            editingCounter = editingCounter,
            onSave = { existingId, name, track, prefix, avg, limit, open, acceptsQueue, acceptsAppt ->
                queueViewModel.saveCounter(
                    org = targetOrg,
                    existingCounterId = existingId,
                    name = name,
                    serviceTrack = track,
                    prefix = prefix,
                    avgServiceMinutes = avg,
                    maxWaitingLimit = limit,
                    open = open,
                    acceptingQueue = acceptsQueue,
                    acceptingAppointments = acceptsAppt
                )
            },
            onDismiss = { counterEditorTargetOrg = null }
        )
    }

    subscriptionTarget?.let { (org, sub) ->
        BusinessSubscriptionSheet(
            organization = org,
            currentSubscription = sub,
            onActivatePlan = queueViewModel::activateSubscription,
            onGatewayMissingNotice = { msg ->
                scope.launch { snackbarHostState.showSnackbar(msg) }
            },
            onDismiss = { subscriptionTarget = null }
        )
    }

    visualDisplayPayload?.let { (org, counters, tickets) ->
        val isOwner = (ownedOrgsState as? UiState.Success)?.data?.any { it.id == org.id } == true
        val liveCounters = if (isOwner) {
            (ownedCountersState as? UiState.Success)?.data ?: counters
        } else {
            liveDashboardCounters[org.id]?.takeIf { it.isNotEmpty() }
                ?: (publicCountersState as? UiState.Success)?.data?.takeIf { it.isNotEmpty() }
                ?: counters
        }
        val liveTickets = if (isOwner) {
            (ownerTicketsState as? UiState.Success)?.data?.filter { it.orgId == org.id } ?: tickets
        } else {
            tickets
        }
        VisualQueueDisplayDialog(
            organization = org,
            counters = liveCounters,
            tickets = liveTickets,
            onCallNext = if (isOwner) {
                { counter -> queueViewModel.callNextForCounter(counter, liveTickets) }
            } else {
                null
            },
            onDismiss = { visualDisplayPayload = null }
        )
    }

    if (showAppointmentEditor) {
        AppointmentEditorSheet(
            initialDateKey = editorInitialDateKey,
            editingAppointment = editingAppointment,
            initialLinkedContactIds = appointmentInitialLinkedContactIds,
            availableContacts = allContacts,
            onQuickCreateContact = { name, role, company, group, onCreated ->
                viewModel.saveContact(
                    existingId = null,
                    name = name,
                    role = role,
                    company = company,
                    email = "",
                    phone = "",
                    location = "",
                    group = group,
                    notes = "",
                    favorite = false,
                    onSavedId = onCreated
                )
            },
            onDismiss = { showAppointmentEditor = false },
            onSave = viewModel::saveAppointment
        )
    }

    if (showTaskEditor) {
        TaskEditorSheet(
            editingTask = editingTask,
            initialDueDateKey = taskInitialDateKey,
            initialLinkedAppointment = taskInitialAppointment,
            availableAppointments = allAppointments,
            onDismiss = { showTaskEditor = false },
            onSave = viewModel::saveTask
        )
    }

    if (showContactEditor) {
        ContactEditorSheet(
            editingContact = editingContact,
            onDismiss = { showContactEditor = false },
            onSave = { id, name, role, company, email, phone, location, group, notes, favorite ->
                viewModel.saveContact(
                    existingId = id,
                    name = name,
                    role = role,
                    company = company,
                    email = email,
                    phone = phone,
                    location = location,
                    group = group,
                    notes = notes,
                    favorite = favorite
                )
            }
        )
    }

    inspectingAppointment?.let { appt ->
        val linkedTasks = allTasks.filter { it.linkedAppointmentId == appt.id }
        AppointmentDetailSheet(
            appointment = appt,
            linkedTasks = linkedTasks,
            availableContacts = allContacts,
            onDismiss = { inspectingAppointment = null },
            onEdit = {
                inspectingAppointment = null
                editingAppointment = appt
                editorInitialDateKey = appt.dateKey
                appointmentInitialLinkedContactIds = appt.linkedContactIds
                showAppointmentEditor = true
            },
            onToggleComplete = {
                viewModel.toggleAppointmentCompleted(appt)
                inspectingAppointment = null
            },
            onDelete = {
                viewModel.deleteAppointment(appt.id)
                inspectingAppointment = null
            },
            onAddLinkedTask = {
                inspectingAppointment = null
                editingTask = null
                taskInitialDateKey = appt.dateKey
                taskInitialAppointment = appt
                showTaskEditor = true
            },
            onToggleTask = viewModel::toggleTaskCompleted,
            onEditTask = { task ->
                inspectingAppointment = null
                editingTask = task
                taskInitialDateKey = task.dueDateKey
                taskInitialAppointment = appt
                showTaskEditor = true
            },
            onContactClick = { contact ->
                inspectingAppointment = null
                inspectingContact = contact
            }
        )
    }

    inspectingContact?.let { contact ->
        val liveContact = allContacts.firstOrNull { it.id == contact.id } ?: contact
        ContactDetailSheet(
            contact = liveContact,
            allAppointments = allAppointments,
            onDismiss = { inspectingContact = null },
            onEdit = {
                inspectingContact = null
                editingContact = liveContact
                showContactEditor = true
            },
            onToggleFavorite = { viewModel.toggleContactFavorite(liveContact) },
            onDelete = {
                viewModel.deleteContact(liveContact.id)
                inspectingContact = null
            },
            onScheduleWithContact = {
                inspectingContact = null
                editingAppointment = null
                editorInitialDateKey = selectedDateKey
                appointmentInitialLinkedContactIds = listOf(liveContact.id)
                showAppointmentEditor = true
            },
            onLinkToAppointment = { appt ->
                viewModel.linkContactToAppointment(liveContact, appt)
            },
            onUnlinkFromAppointment = { appt ->
                viewModel.unlinkContactFromAppointment(liveContact, appt)
            },
            onOpenAppointment = { appt ->
                inspectingContact = null
                viewModel.selectDate(appt.dateKey)
                currentTab = MainTab.MY_QUEUE
                inspectingAppointment = appt
            }
        )
    }

    if (showLanguagePicker) {
        LanguagePickerDialog(
            title = strings.languageSettingsTitle,
            selectedLanguage = appLanguage,
            onSelectLanguage = languageManager::selectAppLanguage,
            onDismiss = { showLanguagePicker = false }
        )
    }

    if (showCurrencyPicker) {
        CurrencyPickerDialog(
            selectedCurrency = currentCurrency,
            onSelectCurrency = currencyManager::selectCurrency,
            onDismiss = { showCurrencyPicker = false }
        )
    }
}
