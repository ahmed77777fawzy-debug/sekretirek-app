package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.i18n.LocalAppStrings
import com.example.model.BusinessSector
import com.example.model.Organization
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.UiState
import com.example.ui.components.LiveServingDashboard
import com.example.ui.components.icon

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QueueHubScreen(
    organizationsState: UiState<List<Organization>>,
    liveCountersByOrg: Map<String, List<QueueCounter>>,
    activeVisitorTickets: List<QueueTicket>,
    aiMatchedOrgIds: List<String>?,
    isRunningAiSearch: Boolean,
    onRunAiSearch: (String, List<Organization>) -> Unit,
    onClearAiSearch: () -> Unit,
    onOpenOrganization: (Organization) -> Unit,
    onOpenVisualDisplay: (Organization, List<QueueCounter>) -> Unit,
    onCreateNewBusiness: () -> Unit
) {
    val strings = LocalAppStrings.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedSector by remember { mutableStateOf<BusinessSector?>(null) }

    val allOrganizations = (organizationsState as? UiState.Success)?.data.orEmpty()

    val sectorCounts = remember(allOrganizations) {
        allOrganizations.groupingBy { it.resolvedSector() }.eachCount()
    }

    val filteredOrganizations = remember(allOrganizations, searchQuery, selectedSector, aiMatchedOrgIds) {
        val bySector = if (selectedSector == null) {
            allOrganizations
        } else {
            allOrganizations.filter { it.resolvedSector() == selectedSector }
        }
        if (aiMatchedOrgIds != null) {
            val rank = aiMatchedOrgIds.withIndex().associate { it.value to it.index }
            bySector.filter { it.id in rank }
                .sortedBy { rank[it.id] ?: Int.MAX_VALUE }
        } else {
            val q = searchQuery.trim().lowercase()
            if (q.isBlank()) {
                bySector
            } else {
                bySector.filter { org ->
                    org.name.lowercase().contains(q) ||
                        org.profession.lowercase().contains(q) ||
                        org.city.lowercase().contains(q) ||
                        org.description.lowercase().contains(q) ||
                        org.resolvedSector().label(strings).lowercase().contains(q)
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(164.dp)
                ) {
                    Image(
                        painter = painterResource(R.drawable.img_queue_hub_banner),
                        contentDescription = strings.titleQueueHub,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                                        MaterialTheme.colorScheme.scrim.copy(alpha = 0.78f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = strings.zeroBookingFeeBadge,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = strings.titleQueueHub,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Text(
                            text = "${allOrganizations.size} ${strings.allFilter} • ${BusinessSector.entries.size} ${strings.sectorOther}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.88f)
                        )
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        if (aiMatchedOrgIds != null) onClearAiSearch()
                    },
                    placeholder = { Text(strings.smartSearchOrgHint) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (searchQuery.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        searchQuery = ""
                                        onClearAiSearch()
                                    },
                                    modifier = Modifier.testTag("clear_org_search_button")
                                ) {
                                    Icon(Icons.Filled.Clear, contentDescription = strings.cancel)
                                }
                            }
                            FilledTonalButton(
                                onClick = { onRunAiSearch(searchQuery, allOrganizations) },
                                enabled = searchQuery.isNotBlank() && allOrganizations.isNotEmpty() && !isRunningAiSearch,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .testTag("ai_smart_search_button")
                            ) {
                                if (isRunningAiSearch) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        Icons.Filled.AutoAwesome,
                                        contentDescription = strings.aiMatchAction,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(strings.aiMatchAction, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("smart_org_search_input")
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedSector == null,
                            onClick = { selectedSector = null },
                            label = { Text("${strings.allFilter} (${allOrganizations.size})") },
                            modifier = Modifier.testTag("sector_filter_all")
                        )
                    }
                    items(BusinessSector.entries, key = { it.name }) { sector ->
                        val count = sectorCounts[sector] ?: 0
                        val label = if (count > 0) "${sector.label(strings)} ($count)" else sector.label(strings)
                        FilterChip(
                            selected = selectedSector == sector,
                            onClick = {
                                selectedSector = if (selectedSector == sector) null else sector
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = sector.icon(),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text(label) },
                            modifier = Modifier.testTag("sector_filter_${sector.name}")
                        )
                    }
                }
            }
        }

        if (allOrganizations.isNotEmpty()) {
            item {
                LiveServingDashboard(
                    organizations = allOrganizations,
                    countersByOrg = liveCountersByOrg,
                    activeVisitorTickets = activeVisitorTickets,
                    compactMode = true,
                    onOpenOrganization = onOpenOrganization,
                    onOpenFullscreenBoard = onOpenVisualDisplay
                )
            }
        }

        when (organizationsState) {
            is UiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = organizationsState.message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
            is UiState.Success -> {
                if (filteredOrganizations.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Storefront,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                                Text(
                                    text = strings.titleQueueHub,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "No cloud organizations match right now. Register your clinic, company, factory, or office from your phone in seconds.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(
                                    onClick = onCreateNewBusiness,
                                    modifier = Modifier.testTag("empty_create_business_button")
                                ) {
                                    Icon(Icons.Filled.AddBusiness, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.createActivity)
                                }
                            }
                        }
                    }
                } else {
                    items(filteredOrganizations, key = { it.id }) { org ->
                        OrganizationDirectoryCard(
                            org = org,
                            onClick = { onOpenOrganization(org) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OrganizationDirectoryCard(
    org: Organization,
    onClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    val sector = org.resolvedSector()
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("org_card_${org.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = sector.icon(),
                                contentDescription = sector.label(strings),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Column {
                        Text(
                            text = org.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${sector.label(strings)} • ${org.profession}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = strings.zeroBookingFeeBadge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (org.description.isNotBlank()) {
                Text(
                    text = org.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (org.city.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = org.city,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (org.workingHours.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Schedule,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = org.workingHours,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Button(
                    onClick = onClick,
                    enabled = org.acceptingBookings && org.subscriptionActive,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("book_org_button_${org.id}")
                ) {
                    Icon(
                        Icons.Filled.ConfirmationNumber,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.bookNow)
                }
            }
        }
    }
}
