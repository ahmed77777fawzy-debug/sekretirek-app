package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppStrings
import com.example.model.Organization
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.TicketStatus
import com.example.model.formatTicketCode

@Composable
fun LiveServingDashboard(
    organizations: List<Organization>,
    countersByOrg: Map<String, List<QueueCounter>>,
    activeVisitorTickets: List<QueueTicket> = emptyList(),
    compactMode: Boolean = false,
    onOpenOrganization: (Organization) -> Unit,
    onOpenFullscreenBoard: (Organization, List<QueueCounter>) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val activeTickets = remember(activeVisitorTickets) {
        activeVisitorTickets.filter { it.resolvedStatus().isActiveQueue() }
    }
    var selectedTicketId by remember(activeTickets) {
        mutableStateOf(activeTickets.firstOrNull()?.id)
    }
    val focusedTicket = activeTickets.firstOrNull { it.id == selectedTicketId } ?: activeTickets.firstOrNull()

    val openBusinesses = remember(organizations, countersByOrg) {
        organizations.filter { org ->
            countersByOrg[org.id].orEmpty().any { it.open } || (org.acceptingBookings && org.subscriptionActive)
        }
    }

    val totalOpenCounters = remember(countersByOrg) {
        countersByOrg.values.flatten().count { it.open }
    }

    val pulseTransition = rememberInfiniteTransition(label = "live_board_pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_serving_dashboard")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Live Pulse Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .alpha(pulseAlpha)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.tertiaryContainer)
                            )
                            Text(
                                text = strings.liveBadgeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                    Column {
                        Text(
                            text = strings.liveServingBoardTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$totalOpenCounters ${strings.activeCountersCountLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                val featuredOrg = focusedTicket?.let { t -> organizations.firstOrNull { it.id == t.orgId } }
                    ?: openBusinesses.firstOrNull()
                if (featuredOrg != null) {
                    val featuredCounters = countersByOrg[featuredOrg.id].orEmpty()
                    if (featuredCounters.isNotEmpty()) {
                        FilledTonalButton(
                            onClick = { onOpenFullscreenBoard(featuredOrg, featuredCounters) },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("live_dashboard_fullscreen_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tv,
                                contentDescription = strings.openKioskBoard,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.openKioskBoard,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // Personal Waiting Customer Turn Comparison Card
            if (focusedTicket != null) {
                if (activeTickets.size > 1) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(activeTickets, key = { it.id }) { ticket ->
                            FilterChip(
                                selected = ticket.id == focusedTicket.id,
                                onClick = { selectedTicketId = ticket.id },
                                label = { Text("${ticket.ticketCode} • ${ticket.orgName}", maxLines = 1) },
                                modifier = Modifier.testTag("live_ticket_chip_${ticket.id}")
                            )
                        }
                    }
                }

                val orgCounters = countersByOrg[focusedTicket.orgId].orEmpty()
                val matchedCounter = orgCounters.firstOrNull { it.id == focusedTicket.counterId }
                val currentServingNum = matchedCounter?.currentServingNumber ?: 0
                val currentServingCode = matchedCounter?.currentServingCode()
                    ?: formatTicketCode(focusedTicket.ticketCode.substringBefore("-"), currentServingNum)
                val turnsAhead = (focusedTicket.ticketNumber - currentServingNum).coerceAtLeast(0)
                val isCalledNow = focusedTicket.resolvedStatus() == TicketStatus.CALLED ||
                    focusedTicket.resolvedStatus() == TicketStatus.SERVING ||
                    (currentServingNum >= focusedTicket.ticketNumber && currentServingNum > 0)
                val avgMins = matchedCounter?.avgServiceMinutes ?: 8
                val liveWaitMins = if (isCalledNow) 0 else turnsAhead * avgMins
                val targetProgress = if (focusedTicket.ticketNumber <= 0) 0f
                else (currentServingNum.toFloat() / focusedTicket.ticketNumber.toFloat()).coerceIn(0.05f, 1f)
                val animatedProgress by animateFloatAsState(
                    targetValue = if (isCalledNow) 1f else targetProgress,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy),
                    label = "turn_progress"
                )

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCalledNow) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.primaryContainer
                        }
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("live_customer_turn_card")
                ) {
                    val primaryTextColor = if (isCalledNow) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = focusedTicket.orgName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryTextColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${focusedTicket.counterName} • ${focusedTicket.slotLabel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = primaryTextColor.copy(alpha = 0.85f)
                                )
                            }
                            if (isCalledNow) {
                                Surface(
                                    color = MaterialTheme.colorScheme.tertiaryContainer,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            Icons.Filled.NotificationsActive,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = strings.yourTurnNowNotice,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onTertiaryContainer
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // NOW SERVING Live Animated Counter Tile
                            Surface(
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = strings.nowServing.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    AnimatedContent(
                                        targetState = currentServingCode,
                                        transitionSpec = {
                                            (slideInVertically { -it } + fadeIn())
                                                .togetherWith(slideOutVertically { it } + fadeOut())
                                        },
                                        label = "serving_number_roll"
                                    ) { code ->
                                        Text(
                                            text = code,
                                            style = MaterialTheme.typography.headlineLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.testTag("live_now_serving_code")
                                        )
                                    }
                                }
                            }

                            // CUSTOMER TICKET & TURNS AHEAD Tile
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.92f),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = strings.yourTurnNumber.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    Text(
                                        text = focusedTicket.ticketCode,
                                        style = MaterialTheme.typography.headlineLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.testTag("live_customer_ticket_code")
                                    )
                                }
                            }
                        }

                        LinearProgressIndicator(
                            progress = { animatedProgress },
                            color = if (isCalledNow) {
                                MaterialTheme.colorScheme.tertiaryContainer
                            } else {
                                MaterialTheme.colorScheme.primary
                            },
                            trackColor = primaryTextColor.copy(alpha = 0.2f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(999.dp))
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "$turnsAhead ${strings.waitingAheadLabel}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = primaryTextColor
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Filled.Schedule,
                                    contentDescription = null,
                                    tint = primaryTextColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "${strings.liveWaitMinutes}: ~${liveWaitMins}m",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = primaryTextColor
                                )
                            }
                        }
                    }
                }
            }

            // Multi-Business Live Serving Boards for Waiting Customers
            if (openBusinesses.isEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Tv,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "Live serving numbers update here automatically as businesses open counters and call customer tickets.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                val boardsToShow = if (compactMode) openBusinesses.take(6) else openBusinesses
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val cardWidth = if (maxWidth >= 600.dp) 290.dp else 258.dp
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(boardsToShow, key = { it.id }) { org ->
                            val counters = countersByOrg[org.id].orEmpty()
                            LiveBusinessBoardCard(
                                org = org,
                                counters = counters,
                                onOpenOrg = { onOpenOrganization(org) },
                                onOpenDisplay = { onOpenFullscreenBoard(org, counters) },
                                modifier = Modifier.width(cardWidth)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveBusinessBoardCard(
    org: Organization,
    counters: List<QueueCounter>,
    onOpenOrg: () -> Unit,
    onOpenDisplay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val primaryCounter = counters.firstOrNull { it.open } ?: counters.firstOrNull()
    val totalWaiting = counters.sumOf { it.waitingCount.coerceAtLeast(0) }
    val servingCode = primaryCounter?.currentServingCode() ?: "---"

    Card(
        onClick = onOpenOrg,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.testTag("live_business_board_${org.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = org.resolvedSector().icon(),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = org.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = org.profession,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = strings.nowServing,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        AnimatedContent(
                            targetState = servingCode,
                            transitionSpec = {
                                (slideInVertically { -it } + fadeIn())
                                    .togetherWith(slideOutVertically { it } + fadeOut())
                            },
                            label = "org_serving_roll_${org.id}"
                        ) { code ->
                            Text(
                                text = code,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = primaryCounter?.name ?: strings.liveCountersTab,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$totalWaiting ${strings.peopleAhead}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenDisplay,
                    enabled = counters.isNotEmpty(),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("board_display_btn_${org.id}")
                ) {
                    Icon(Icons.Filled.Tv, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.openKioskBoard, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                }
                FilledTonalButton(
                    onClick = onOpenOrg,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("board_book_btn_${org.id}")
                ) {
                    Icon(Icons.Filled.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.bookNow, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                }
            }
        }
    }
}
