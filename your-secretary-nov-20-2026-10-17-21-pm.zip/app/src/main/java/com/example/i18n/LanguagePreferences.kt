package com.example.i18n

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.languageDataStore by preferencesDataStore(name = "secretary_language_prefs")

class LanguagePreferences(private val context: Context) {

    val appLanguageCodeFlow: Flow<String> = context.languageDataStore.data.map { prefs ->
        prefs[KEY_APP_LANGUAGE] ?: AppLanguages.defaultDeviceLanguage().code
    }

    val chatTargetLanguageCodeFlow: Flow<String> = context.languageDataStore.data.map { prefs ->
        prefs[KEY_CHAT_TARGET_LANGUAGE]
            ?: prefs[KEY_APP_LANGUAGE]
            ?: AppLanguages.defaultDeviceLanguage().code
    }

    val autoTranslateChatFlow: Flow<Boolean> = context.languageDataStore.data.map { prefs ->
        prefs[KEY_AUTO_TRANSLATE_CHAT] ?: false
    }

    suspend fun setAppLanguageCode(code: String) {
        context.languageDataStore.edit { prefs ->
            prefs[KEY_APP_LANGUAGE] = code
        }
    }

    suspend fun setChatTargetLanguageCode(code: String) {
        context.languageDataStore.edit { prefs ->
            prefs[KEY_CHAT_TARGET_LANGUAGE] = code
        }
    }

    suspend fun setAutoTranslateChat(enabled: Boolean) {
        context.languageDataStore.edit { prefs ->
            prefs[KEY_AUTO_TRANSLATE_CHAT] = enabled
        }
    }

    suspend fun getCachedUiStrings(languageCode: String): Map<String, String>? {
        val prefs = context.languageDataStore.data.first()
        val raw = prefs[stringPreferencesKey("ui_cache_${languageCode.lowercase()}")] ?: return null
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    put(key, json.optString(key, ""))
                }
            }
        }.getOrNull()
    }

    suspend fun saveCachedUiStrings(languageCode: String, map: Map<String, String>) {
        val json = JSONObject()
        map.forEach { (k, v) -> json.put(k, v) }
        context.languageDataStore.edit { prefs ->
            prefs[stringPreferencesKey("ui_cache_${languageCode.lowercase()}")] = json.toString()
        }
    }

    private companion object {
        val KEY_APP_LANGUAGE = stringPreferencesKey("app_language_code")
        val KEY_CHAT_TARGET_LANGUAGE = stringPreferencesKey("chat_target_language_code")
        val KEY_AUTO_TRANSLATE_CHAT = booleanPreferencesKey("auto_translate_chat")
    }
}
