package com.example.i18n

import android.content.Context
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private val Context.currencyDataStore by preferencesDataStore(name = "secretary_currency_prefs")

class CurrencyManager(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _selectedCurrency = MutableStateFlow(AppCurrencies.USD)
    val selectedCurrency: StateFlow<SupportedCurrency> = _selectedCurrency.asStateFlow()

    init {
        scope.launch {
            context.currencyDataStore.data
                .map { prefs -> prefs[KEY_CURRENCY_CODE] }
                .collect { code ->
                    _selectedCurrency.value = if (code != null) {
                        AppCurrencies.byCode(code)
                    } else {
                        AppCurrencies.USD
                    }
                }
        }
    }

    fun selectCurrency(currency: SupportedCurrency) {
        _selectedCurrency.value = currency
        scope.launch {
            context.currencyDataStore.edit { prefs ->
                prefs[KEY_CURRENCY_CODE] = currency.code
            }
        }
    }

    private companion object {
        val KEY_CURRENCY_CODE = stringPreferencesKey("selected_currency_code")
    }
}

val LocalAppCurrency = staticCompositionLocalOf { AppCurrencies.USD }
