package com.example.i18n

import android.content.Context
import android.util.Log
import com.example.data.SecretaryAiRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

class LanguageManager(
    context: Context,
    private val aiRepository: SecretaryAiRepository
) {
    private val prefs = LanguagePreferences(context.applicationContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _appLanguage = MutableStateFlow(AppLanguages.defaultDeviceLanguage())
    val appLanguage: StateFlow<SupportedLanguage> = _appLanguage.asStateFlow()

    private val _appStrings = MutableStateFlow(
        AppStringDictionaries.builtInFor(_appLanguage.value.code) ?: EnglishStrings
    )
    val appStrings: StateFlow<AppStrings> = _appStrings.asStateFlow()

    private val _chatTargetLanguage = MutableStateFlow(_appLanguage.value)
    val chatTargetLanguage: StateFlow<SupportedLanguage> = _chatTargetLanguage.asStateFlow()

    private val _autoTranslateChat = MutableStateFlow(false)
    val autoTranslateChat: StateFlow<Boolean> = _autoTranslateChat.asStateFlow()

    private val _isTranslatingUi = MutableStateFlow(false)
    val isTranslatingUi: StateFlow<Boolean> = _isTranslatingUi.asStateFlow()

    private var uiTranslationJob: Job? = null

    init {
        scope.launch {
            prefs.appLanguageCodeFlow.collectLatest { code ->
                val lang = AppLanguages.findByCode(code)
                applyAppLanguage(lang)
            }
        }
        scope.launch {
            prefs.chatTargetLanguageCodeFlow.collectLatest { code ->
                _chatTargetLanguage.value = AppLanguages.findByCode(code)
            }
        }
        scope.launch {
            prefs.autoTranslateChatFlow.collectLatest { enabled ->
                _autoTranslateChat.value = enabled
            }
        }
    }

    fun selectAppLanguage(language: SupportedLanguage) {
        applyAppLanguage(language)
        scope.launch {
            prefs.setAppLanguageCode(language.code)
        }
    }

    fun selectChatTargetLanguage(language: SupportedLanguage) {
        _chatTargetLanguage.value = language
        scope.launch {
            prefs.setChatTargetLanguageCode(language.code)
        }
    }

    fun setAutoTranslateChat(enabled: Boolean) {
        _autoTranslateChat.value = enabled
        scope.launch {
            prefs.setAutoTranslateChat(enabled)
        }
    }

    private fun applyAppLanguage(language: SupportedLanguage) {
        _appLanguage.value = language
        Locale.setDefault(language.toLocale())

        val builtIn = AppStringDictionaries.builtInFor(language.code)
        if (builtIn != null) {
            uiTranslationJob?.cancel()
            _isTranslatingUi.value = false
            _appStrings.value = builtIn
            return
        }

        uiTranslationJob?.cancel()
        uiTranslationJob = scope.launch {
            val cached = prefs.getCachedUiStrings(language.code)
            if (!cached.isNullOrEmpty()) {
                _appStrings.value = AppStrings.fromKeyMap(cached, EnglishStrings)
                return@launch
            }
            _isTranslatingUi.value = true
            try {
                val translatedMap = aiRepository.translateUiStrings(
                    targetLanguage = language,
                    sourceStrings = EnglishStrings.toKeyMap()
                )
                if (translatedMap.isNotEmpty()) {
                    prefs.saveCachedUiStrings(language.code, translatedMap)
                    _appStrings.value = AppStrings.fromKeyMap(translatedMap, EnglishStrings)
                } else {
                    _appStrings.value = EnglishStrings
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Dynamic UI translation failed for ${language.code}", e)
                _appStrings.value = EnglishStrings
            } finally {
                _isTranslatingUi.value = false
            }
        }
    }

    private companion object {
        const val TAG = "LanguageManager"
    }
}
