package com.example.i18n

import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

data class SupportedCurrency(
    val code: String,
    val symbol: String,
    val englishName: String,
    val nativeName: String,
    val rateFromUsd: Double
) {
    fun formatUsdPrice(usdAmount: Double): String {
        val converted = usdAmount * rateFromUsd
        return runCatching {
            val nf = NumberFormat.getCurrencyInstance(Locale.getDefault())
            nf.currency = Currency.getInstance(code)
            nf.maximumFractionDigits = if (rateFromUsd >= 50.0) 0 else 2
            nf.format(converted)
        }.getOrElse {
            val decimals = if (rateFromUsd >= 50.0) "%.0f" else "%.2f"
            "$symbol${decimals.format(converted)}"
        }
    }
}

object AppCurrencies {
    val USD = SupportedCurrency("USD", "$", "US Dollar", "US Dollar", 1.0)

    val ALL: List<SupportedCurrency> = listOf(
        USD,
        SupportedCurrency("SAR", "ر.س", "Saudi Riyal", "ريال سعودي", 3.75),
        SupportedCurrency("AED", "د.إ", "UAE Dirham", "درهم إماراتي", 3.67),
        SupportedCurrency("EGP", "ج.م", "Egyptian Pound", "جنيه مصري", 49.5),
        SupportedCurrency("KWD", "د.ك", "Kuwaiti Dinar", "دينار كويتي", 0.31),
        SupportedCurrency("QAR", "ر.ق", "Qatari Riyal", "ريال قطري", 3.64),
        SupportedCurrency("BHD", "د.ب", "Bahraini Dinar", "دينار بحريني", 0.38),
        SupportedCurrency("OMR", "ر.ع", "Omani Rial", "ريال عماني", 0.38),
        SupportedCurrency("JOD", "د.أ", "Jordanian Dinar", "دينار أردني", 0.71),
        SupportedCurrency("MAD", "د.م", "Moroccan Dirham", "درهم مغربي", 9.9),
        SupportedCurrency("TND", "د.ت", "Tunisian Dinar", "دينار تونسي", 3.1),
        SupportedCurrency("EUR", "€", "Euro", "Euro", 0.92),
        SupportedCurrency("GBP", "£", "British Pound", "British Pound", 0.79),
        SupportedCurrency("TRY", "₺", "Turkish Lira", "Türk Lirası", 34.5),
        SupportedCurrency("CHF", "CHF", "Swiss Franc", "Schweizer Franken", 0.88),
        SupportedCurrency("CAD", "CA$", "Canadian Dollar", "Canadian Dollar", 1.39),
        SupportedCurrency("AUD", "A$", "Australian Dollar", "Australian Dollar", 1.53),
        SupportedCurrency("JPY", "¥", "Japanese Yen", "日本円", 154.0),
        SupportedCurrency("CNY", "¥", "Chinese Yuan", "人民币", 7.24),
        SupportedCurrency("INR", "₹", "Indian Rupee", "भारतीय रुपया", 84.4),
        SupportedCurrency("PKR", "₨", "Pakistani Rupee", "پاکستانی روپیہ", 278.0),
        SupportedCurrency("KRW", "₩", "South Korean Won", "대한민국 원", 1395.0),
        SupportedCurrency("BRL", "R$", "Brazilian Real", "Real Brasileiro", 5.8),
        SupportedCurrency("NGN", "₦", "Nigerian Naira", "Nigerian Naira", 1660.0),
        SupportedCurrency("ZAR", "R", "South African Rand", "South African Rand", 18.1)
    )

    fun byCode(code: String?): SupportedCurrency =
        ALL.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: USD

    fun defaultForLanguage(langCode: String): SupportedCurrency = when (langCode.lowercase().substringBefore("-")) {
        "ar" -> byCode("SAR")
        "tr" -> byCode("TRY")
        "ja" -> byCode("JPY")
        "zh" -> byCode("CNY")
        "hi" -> byCode("INR")
        "ur" -> byCode("PKR")
        "ko" -> byCode("KRW")
        "fr", "de", "es", "it" -> byCode("EUR")
        else -> USD
    }
}
