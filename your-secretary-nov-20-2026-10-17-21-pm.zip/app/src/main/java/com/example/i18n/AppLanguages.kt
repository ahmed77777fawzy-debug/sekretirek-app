package com.example.i18n

import java.util.Locale

data class SupportedLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val isRtl: Boolean = false
) {
    val shortBadge: String
        get() = code.substringBefore("-").uppercase().take(3)

    fun toLocale(): Locale = Locale.forLanguageTag(code)
}

object AppLanguages {
    val ENGLISH = SupportedLanguage("en", "English", "English", isRtl = false)
    val ARABIC = SupportedLanguage("ar", "العربية", "Arabic", isRtl = true)

    val QUICK_CODES = listOf("ar", "en", "es", "fr", "de", "zh-CN", "ja", "ko", "tr", "hi", "ur", "pt", "ru")

    val ALL_LANGUAGES: List<SupportedLanguage> = listOf(
        ARABIC,
        ENGLISH,
        SupportedLanguage("es", "Español", "Spanish"),
        SupportedLanguage("fr", "Français", "French"),
        SupportedLanguage("de", "Deutsch", "German"),
        SupportedLanguage("zh-CN", "中文 (简体)", "Chinese (Simplified)"),
        SupportedLanguage("zh-TW", "中文 (繁體)", "Chinese (Traditional)"),
        SupportedLanguage("ja", "日本語", "Japanese"),
        SupportedLanguage("ko", "한국어", "Korean"),
        SupportedLanguage("pt", "Português", "Portuguese"),
        SupportedLanguage("ru", "Русский", "Russian"),
        SupportedLanguage("it", "Italiano", "Italian"),
        SupportedLanguage("tr", "Türkçe", "Turkish"),
        SupportedLanguage("hi", "हिन्दी", "Hindi"),
        SupportedLanguage("ur", "اردو", "Urdu", isRtl = true),
        SupportedLanguage("fa", "فارسی", "Persian", isRtl = true),
        SupportedLanguage("he", "עברית", "Hebrew", isRtl = true),
        SupportedLanguage("id", "Bahasa Indonesia", "Indonesian"),
        SupportedLanguage("ms", "Bahasa Melayu", "Malay"),
        SupportedLanguage("nl", "Nederlands", "Dutch"),
        SupportedLanguage("pl", "Polski", "Polish"),
        SupportedLanguage("uk", "Українська", "Ukrainian"),
        SupportedLanguage("sv", "Svenska", "Swedish"),
        SupportedLanguage("no", "Norsk", "Norwegian"),
        SupportedLanguage("da", "Dansk", "Danish"),
        SupportedLanguage("fi", "Suomi", "Finnish"),
        SupportedLanguage("el", "Ελληνικά", "Greek"),
        SupportedLanguage("cs", "Čeština", "Czech"),
        SupportedLanguage("ro", "Română", "Romanian"),
        SupportedLanguage("hu", "Magyar", "Hungarian"),
        SupportedLanguage("th", "ไทย", "Thai"),
        SupportedLanguage("vi", "Tiếng Việt", "Vietnamese"),
        SupportedLanguage("bn", "বাংলা", "Bengali"),
        SupportedLanguage("ta", "தமிழ்", "Tamil"),
        SupportedLanguage("te", "తెలుగు", "Telugu"),
        SupportedLanguage("mr", "मराठी", "Marathi"),
        SupportedLanguage("gu", "ગુજરાતી", "Gujarati"),
        SupportedLanguage("pa", "ਪੰਜਾਬੀ", "Punjabi"),
        SupportedLanguage("sw", "Kiswahili", "Swahili"),
        SupportedLanguage("tl", "Filipino", "Filipino (Tagalog)"),
        SupportedLanguage("ca", "Català", "Catalan"),
        SupportedLanguage("sk", "Slovenčina", "Slovak"),
        SupportedLanguage("bg", "Български", "Bulgarian"),
        SupportedLanguage("hr", "Hrvatski", "Croatian"),
        SupportedLanguage("sr", "Српски", "Serbian"),
        SupportedLanguage("sl", "Slovenščina", "Slovenian"),
        SupportedLanguage("et", "Eesti", "Estonian"),
        SupportedLanguage("lv", "Latviešu", "Latvian"),
        SupportedLanguage("lt", "Lietuvių", "Lithuanian"),
        SupportedLanguage("af", "Afrikaans", "Afrikaans"),
        SupportedLanguage("am", "አማርኛ", "Amharic"),
        SupportedLanguage("az", "Azərbaycan", "Azerbaijani"),
        SupportedLanguage("ka", "ქართული", "Georgian"),
        SupportedLanguage("kk", "Қазақша", "Kazakh"),
        SupportedLanguage("uz", "Oʻzbekcha", "Uzbek"),
        SupportedLanguage("ne", "नेपाली", "Nepali"),
        SupportedLanguage("si", "සිංහල", "Sinhala"),
        SupportedLanguage("my", "မြန်မာ", "Burmese"),
        SupportedLanguage("km", "ខ្មែរ", "Khmer"),
        SupportedLanguage("lo", "ລາວ", "Lao"),
        SupportedLanguage("mn", "Монгол", "Mongolian"),
        SupportedLanguage("sq", "Shqip", "Albanian"),
        SupportedLanguage("hy", "Հայերեն", "Armenian"),
        SupportedLanguage("eu", "Euskara", "Basque"),
        SupportedLanguage("gl", "Galego", "Galician"),
        SupportedLanguage("is", "Íslenska", "Icelandic"),
        SupportedLanguage("ga", "Gaeilge", "Irish"),
        SupportedLanguage("cy", "Cymraeg", "Welsh"),
        SupportedLanguage("mt", "Malti", "Maltese"),
        SupportedLanguage("ps", "پښتو", "Pashto", isRtl = true),
        SupportedLanguage("ku", "کوردی", "Kurdish", isRtl = true),
        SupportedLanguage("ha", "Hausa", "Hausa"),
        SupportedLanguage("yo", "Yorùbá", "Yoruba"),
        SupportedLanguage("ig", "Igbo", "Igbo"),
        SupportedLanguage("so", "Soomaali", "Somali"),
        SupportedLanguage("zu", "isiZulu", "Zulu")
    )

    private val rtlLanguageCodes = setOf("ar", "ur", "fa", "he", "iw", "ps", "ku", "sd", "yi")

    fun findByCode(code: String?): SupportedLanguage {
        val clean = code?.trim().orEmpty()
        if (clean.isBlank()) return defaultDeviceLanguage()
        ALL_LANGUAGES.firstOrNull { it.code.equals(clean, ignoreCase = true) }?.let { return it }
        val base = clean.substringBefore("-")
        ALL_LANGUAGES.firstOrNull {
            it.code.equals(base, ignoreCase = true) ||
                it.code.substringBefore("-").equals(base, ignoreCase = true)
        }?.let { return it }
        return SupportedLanguage(
            code = clean,
            nativeName = clean,
            englishName = clean,
            isRtl = base.lowercase() in rtlLanguageCodes
        )
    }

    fun customLanguage(nameOrCode: String): SupportedLanguage {
        val clean = nameOrCode.trim().take(48)
        ALL_LANGUAGES.firstOrNull {
            it.code.equals(clean, ignoreCase = true) ||
                it.englishName.equals(clean, ignoreCase = true) ||
                it.nativeName.equals(clean, ignoreCase = true)
        }?.let { return it }
        return SupportedLanguage(
            code = clean,
            nativeName = clean,
            englishName = clean,
            isRtl = false
        )
    }

    fun defaultDeviceLanguage(): SupportedLanguage {
        val deviceLang = Locale.getDefault().language
        return ALL_LANGUAGES.firstOrNull {
            it.code.substringBefore("-").equals(deviceLang, ignoreCase = true)
        } ?: ENGLISH
    }
}
