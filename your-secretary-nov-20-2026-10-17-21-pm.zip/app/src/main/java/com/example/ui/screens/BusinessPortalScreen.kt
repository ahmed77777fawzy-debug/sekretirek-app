package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.i18n.LocalAppCurrency
import com.example.i18n.LocalAppStrings
import com.example.model.BusinessSubscription
import com.example.model.CustomerVisitSummary
import com.example.model.Organization
import com.example.model.PlanTier
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.TicketStatus
import com.example.model.UiState
import com.example.ui.components.icon

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BusinessPortalScreen(
    ownedOrganizationsState: UiState<List<Organization>>,
    selectedOrgId: String?,
    ownedCountersState: UiState<List<QueueCounter>>,
    ownerTicketsState: UiState<List<QueueTicket>>,
    customers: List<CustomerVisitSummary>,
    subscriptionsState: UiState<List<BusinessSubscription>>,
    onSelectOrg: (String) -> Unit,
    onCreateOrg: () -> Unit,
    onEditOrg: (Organization) -> Unit,
    onAddCounter: (Organization) -> Unit,
    onEditCounter: (Organization, QueueCounter) -> Unit,
    onToggleCounterOpen: (orgId: String, counterId: String, open: Boolean) -> Unit,
    onResetCounterQueue: (orgId: String, counterId: String) -> Unit,
    onCallNext: (QueueCounter, List<QueueTicket>) -> Unit,
    onUpdateTicketStatus: (QueueTicket, TicketStatus) -> Unit,
    onOpenVisualDisplay: (Organization, List<QueueCounter>, List<QueueTicket>) -> Unit,
    onOpenSubscriptionSheet: (Organization, BusinessSubscription?) -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val currency = LocalAppCurrency.current
    var portalTab by remember { mutableStateOf(0) } // 0=Counters, 1=Queue, 2=Customers, 3=Plans

    val ownedOrgs = (ownedOrganizationsState as? UiState.Success)?.data.orEmpty()
    val activeOrg = ownedOrgs.firstOrNull { it.id == selectedOrgId } ?: ownedOrgs.firstOrNull()
    val counters = (ownedCountersState as? UiState.Success)?.data.orEmpty()
    val allOwnerTickets = (ownerTicketsState as? UiState.Success)?.data.orEmpty()
    val activeOrgTickets = remember(allOwnerTickets, activeOrg) {
        if (activeOrg == null) emptyList() else allOwnerTickets.filter { it.orgId == activeOrg.id }
    }
    val subscriptions = (subscriptionsState as? UiState.Success)?.data.orEmpty()
    val activeSubscription = activeOrg?.let { org -> subscriptions.firstOrNull { it.orgId == org.id } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                ) {
                    Image(
                        painter = painterResource(R.drawable.img_business_portal_banner),
                        contentDescription = strings.titleBusinessPortal,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                                        MaterialTheme.colorScheme.scrim.copy(alpha = 0.8f)
                                    )
                                )
                            )
                    )
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.titleBusinessPortal,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Text(
                                text = "${ownedOrgs.size} ${strings.navBusiness} • ${strings.zeroBookingFeeBadge}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                            )
                        }
                        FilledTonalButton(
                            onClick = onCreateOrg,
                            modifier = Modifier.testTag("create_activity_banner_button")
                        ) {
                            Icon(Icons.Filled.AddBusiness, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.createActivity)
                        }
                    }
                }
            }
        }

        when (ownedOrganizationsState) {
            is UiState.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    Text(ownedOrganizationsState.message, color = MaterialTheme.colorScheme.error)
                }
            }
            is UiState.Success -> {
                if (ownedOrgs.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    Icons.Filled.AddBusiness,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                                Text(
                                    text = "Launch Your Cloud Reception",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Create your company, clinic, hospital, factory, or interview center directly from your phone. Activate Starter Free or a monthly plan, configure live counters, and eliminate indoor crowding.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(
                                    onClick = onCreateOrg,
                                    modifier = Modifier.testTag("empty_owner_create_activity_button")
                                ) {
                                    Icon(Icons.Filled.AddBusiness, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.createActivity)
                                }
                            }
                        }
                    }
                } else if (activeOrg != null) {
                    if (ownedOrgs.size > 1) {
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(ownedOrgs, key = { it.id }) { org ->
                                    FilterChip(
                                        selected = org.id == activeOrg.id,
                                        onClick = { onSelectOrg(org.id) },
                                        leadingIcon = {
                                            Icon(
                                                org.resolvedSector().icon(),
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        },
                                        label = { Text(org.name) }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = activeOrg.name,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${activeOrg.resolvedSector().label(strings)} • ${activeOrg.profession} • ${activeOrg.planTier}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = { onEditOrg(activeOrg) },
                                        modifier = Modifier.testTag("edit_active_org_button")
                                    ) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Edit Activity")
                                    }
                                }
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { onOpenVisualDisplay(activeOrg, counters, activeOrgTickets) },
                                        modifier = Modifier.testTag("launch_visual_display_button")
                                    ) {
                                        Icon(Icons.Filled.Tv, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(strings.visualDisplayBoard)
                                    }
                                    OutlinedButton(
                                        onClick = { onAddCounter(activeOrg) },
                                        modifier = Modifier.testTag("add_counter_button")
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(strings.addCounter)
                                    }
                                    OutlinedButton(
                                        onClick = { onOpenSubscriptionSheet(activeOrg, activeSubscription) },
                                        modifier = Modifier.testTag("manage_subscription_button")
                                    ) {
                                        Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(strings.manageSubscription)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            val labels = listOf(
                                strings.liveCountersTab,
                                strings.bookingsTab,
                                strings.customersCrm,
                                strings.plansTab
                            )
                            labels.forEachIndexed { idx, label ->
                                SegmentedButton(
                                    selected = portalTab == idx,
                                    onClick = { portalTab = idx },
                                    shape = SegmentedButtonDefaults.itemShape(idx, labels.size),
                                    modifier = Modifier.testTag("business_portal_tab_$idx")
                                ) {
                                    Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }

                    when (portalTab) {
                        0 -> {
                            items(counters, key = { it.id }) { counter ->
                                val ratio = (counter.waitingCount.toFloat() / counter.maxWaitingLimit.coerceAtLeast(1))
                                    .coerceIn(0f, 1f)
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("owner_counter_card_${counter.id}")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = counter.name,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${counter.serviceTrack} • ${strings.nowServing}: ${counter.currentServingCode()} • Last: ${counter.prefix}-${counter.lastIssuedNumber}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Switch(
                                                checked = counter.open,
                                                onCheckedChange = { open ->
                                                    onToggleCounterOpen(activeOrg.id, counter.id, open)
                                                },
                                                modifier = Modifier.testTag("counter_open_switch_${counter.id}")
                                            )
                                        }

                                        LinearProgressIndicator(
                                            progress = { ratio },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Text(
                                            text = "${strings.crowdLimitLabel}: ${counter.waitingCount}/${counter.maxWaitingLimit} • ~${counter.estimatedWaitMinutes()}m",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = { onCallNext(counter, activeOrgTickets) },
                                                enabled = counter.open,
                                                modifier = Modifier.testTag("call_next_button_${counter.id}")
                                            ) {
                                                Icon(Icons.Filled.Campaign, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(strings.callNext)
                                            }
                                            OutlinedButton(
                                                onClick = { onEditCounter(activeOrg, counter) }
                                            ) {
                                                Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Edit")
                                            }
                                            OutlinedButton(
                                                onClick = { onResetCounterQueue(activeOrg.id, counter.id) }
                                            ) {
                                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Reset")
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        1 -> {
                            if (activeOrgTickets.isEmpty()) {
                                item {
                                    Text(
                                        text = "No queued visitors or numbered appointments yet for ${activeOrg.name}.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            } else {
                                items(activeOrgTickets, key = { it.id }) { ticket ->
                                    val status = ticket.resolvedStatus()
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "${ticket.ticketCode} • ${ticket.visitorName}",
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "${ticket.counterName} • ${ticket.dateKey} ${ticket.slotLabel}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                    if (ticket.visitorNotes.isNotBlank()) {
                                                        Text(
                                                            text = ticket.visitorNotes,
                                                            style = MaterialTheme.typography.bodySmall
                                                        )
                                                    }
                                                }
                                                Surface(
                                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text(
                                                        text = status.name,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                            if (!status.isTerminal()) {
                                                FlowRow(
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    if (status == TicketStatus.WAITING) {
                                                        FilledTonalButton(
                                                            onClick = { onUpdateTicketStatus(ticket, TicketStatus.CALLED) }
                                                        ) {
                                                            Icon(Icons.Filled.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text(strings.callNext)
                                                        }
                                                    }
                                                    Button(
                                                        onClick = { onUpdateTicketStatus(ticket, TicketStatus.COMPLETED) },
                                                        modifier = Modifier.testTag("mark_served_${ticket.id}")
                                                    ) {
                                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(strings.markServed)
                                                    }
                                                    OutlinedButton(
                                                        onClick = { onUpdateTicketStatus(ticket, TicketStatus.NO_SHOW) }
                                                    ) {
                                                        Icon(Icons.Filled.PersonOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(strings.noShow)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            if (customers.isEmpty()) {
                                item {
                                    Text(
                                        text = "Customer visit records populate automatically as visitors book queue numbers or appointments.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            } else {
                                items(customers, key = { it.visitorId }) { customer ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    Icons.Filled.People,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                                Column {
                                                    Text(
                                                        text = customer.visitorName,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "Visits: ${customer.totalVisits} • Completed: ${customer.completedVisits} • Last: ${customer.lastTicketCode}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            if (customer.visitorPhone.isNotBlank()) {
                                                IconButton(
                                                    onClick = {
                                                        runCatching {
                                                            context.startActivity(
                                                                Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.visitorPhone}"))
                                                            )
                                                        }
                                                    }
                                                ) {
                                                    Icon(Icons.Filled.Phone, contentDescription = "Call Customer")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        else -> {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                    ),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            text = "${activeOrg.name} • ${activeOrg.planTier}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        PlanTier.entries.forEach { tier ->
                                            val price = currency.formatUsdPrice(tier.baseUsdMonthly)
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(tier.name, fontWeight = FontWeight.SemiBold)
                                                Text("$price ${strings.monthlyPlanLabel}")
                                            }
                                        }
                                        Button(
                                            onClick = { onOpenSubscriptionSheet(activeOrg, activeSubscription) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("open_plans_checkout_button")
                                        ) {
                                            Icon(Icons.Filled.Verified, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("${strings.manageSubscription} • ${strings.globalPaymentGateways}")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
