package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppStrings
import com.example.model.AiActionProposal
import com.example.model.Appointment
import com.example.model.ExecutiveMemo
import com.example.model.SecretaryContact
import com.example.model.SecretaryTask
import com.example.model.SmartBriefingState
import com.example.model.UiState

@Composable
fun ExecutiveDeskScreen(
    deskSectionIndex: Int,
    onSelectDeskSection: (Int) -> Unit,
    userDisplayName: String,
    appointmentsState: UiState<List<Appointment>>,
    tasksState: UiState<List<SecretaryTask>>,
    memosState: UiState<List<ExecutiveMemo>>,
    contactsState: UiState<List<SecretaryContact>>,
    smartBriefingState: SmartBriefingState,
    isParsingCommand: Boolean,
    pendingProposal: AiActionProposal?,
    commandError: String?,
    draftingMemoId: String?,
    onGenerateBriefing: () -> Unit,
    onParseQuickCommand: (String) -> Unit,
    onConfirmProposal: () -> Unit,
    onDismissProposal: () -> Unit,
    onOpenCalendar: () -> Unit,
    onNewAppointment: () -> Unit,
    onNewTask: () -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onToggleAppointment: (Appointment) -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onDeleteTask: (String) -> Unit,
    onOpenDateInCalendar: (String) -> Unit,
    onOpenLinkedAppointment: (String) -> Unit,
    onSaveMemo: (String?, String, String, Boolean, String) -> Unit,
    onToggleMemoPin: (ExecutiveMemo) -> Unit,
    onDraftMemoFollowUp: (ExecutiveMemo) -> Unit,
    onDeleteMemo: (String) -> Unit,
    onAddContact: () -> Unit,
    onContactClick: (SecretaryContact) -> Unit,
    onToggleContactFavorite: (SecretaryContact) -> Unit
) {
    val strings = LocalAppStrings.current
    val allAppointments = (appointmentsState as? UiState.Success)?.data.orEmpty()

    Column(modifier = Modifier.fillMaxSize()) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            val segments = listOf(strings.navBriefing, strings.navDesk, strings.navContacts)
            segments.forEachIndexed { idx, label ->
                SegmentedButton(
                    selected = deskSectionIndex == idx,
                    onClick = { onSelectDeskSection(idx) },
                    shape = SegmentedButtonDefaults.itemShape(idx, segments.size),
                    modifier = Modifier.testTag("executive_desk_segment_$idx")
                ) {
                    Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        when (deskSectionIndex) {
            0 -> BriefingScreen(
                userDisplayName = userDisplayName,
                appointmentsState = appointmentsState,
                tasksState = tasksState,
                smartBriefingState = smartBriefingState,
                isParsingCommand = isParsingCommand,
                pendingProposal = pendingProposal,
                commandError = commandError,
                onGenerateBriefing = onGenerateBriefing,
                onParseQuickCommand = onParseQuickCommand,
                onConfirmProposal = onConfirmProposal,
                onDismissProposal = onDismissProposal,
                onOpenCalendar = onOpenCalendar,
                onNewAppointment = onNewAppointment,
                onNewTask = onNewTask,
                onAppointmentClick = onAppointmentClick,
                onToggleAppointment = onToggleAppointment,
                onToggleTask = onToggleTask,
                onEditTask = onEditTask
            )

            1 -> TasksMemosScreen(
                tasksState = tasksState,
                memosState = memosState,
                appointments = allAppointments,
                draftingMemoId = draftingMemoId,
                onOpenNewTask = onNewTask,
                onEditTask = onEditTask,
                onToggleTask = onToggleTask,
                onDeleteTask = onDeleteTask,
                onOpenDateInCalendar = onOpenDateInCalendar,
                onOpenLinkedAppointment = onOpenLinkedAppointment,
                onSaveMemo = onSaveMemo,
                onToggleMemoPin = onToggleMemoPin,
                onDraftMemoFollowUp = onDraftMemoFollowUp,
                onDeleteMemo = onDeleteMemo
            )

            else -> ContactsScreen(
                contactsState = contactsState,
                appointments = allAppointments,
                onAddContact = onAddContact,
                onContactClick = onContactClick,
                onToggleFavorite = onToggleContactFavorite
            )
        }
    }
}
