package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppStrings
import com.example.i18n.SupportedLanguage
import com.example.model.ChatMessage
import com.example.model.ConversationTurn
import com.example.ui.components.ConversationTranslatorSheet
import com.example.ui.components.LanguagePickerDialog

@Composable
fun SecretaryChatScreen(
    messages: List<ChatMessage>,
    chatTargetLanguage: SupportedLanguage,
    autoTranslate: Boolean,
    isTranslatingDraft: Boolean,
    isTranslatingAll: Boolean,
    conversationTurns: List<ConversationTurn>,
    isTranslatingConversation: Boolean,
    pastedConversationResult: String?,
    onSendMessage: (String) -> Unit,
    onSelectChatTargetLanguage: (SupportedLanguage) -> Unit,
    onToggleAutoTranslate: (Boolean) -> Unit,
    onTranslateMessage: (String) -> Unit,
    onToggleMessageTranslation: (String) -> Unit,
    onTranslateAllMessages: () -> Unit,
    onTranslateDraft: (String, (String) -> Unit) -> Unit,
    onTranslateLiveTurn: (String, String, SupportedLanguage, SupportedLanguage) -> Unit,
    onTranslatePastedConversation: (String, SupportedLanguage) -> Unit,
    onClearConversationTranslator: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var input by remember { mutableStateOf("") }
    var showTargetPicker by remember { mutableStateOf(false) }
    var showConversationSheet by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val isBusy = messages.any { it.isStreaming }

    val quickPrompts = remember(strings) {
        listOf(
            strings.quickPromptWeek,
            strings.quickPromptReminders,
            strings.quickPromptFocus,
            strings.quickPromptReschedule
        )
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 820.dp)
                .align(Alignment.TopCenter)
        ) {
            // Translation Control Toolbar
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { showConversationSheet = true },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("open_conversation_translator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Forum,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.conversationTranslator)
                    }

                    AssistChip(
                        onClick = { showTargetPicker = true },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Filled.KeyboardArrowDown,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "${strings.targetLanguage}: ${chatTargetLanguage.nativeName}",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        modifier = Modifier.testTag("chat_target_language_chip")
                    )

                    FilterChip(
                        selected = autoTranslate,
                        onClick = { onToggleAutoTranslate(!autoTranslate) },
                        label = { Text(strings.autoTranslate) },
                        modifier = Modifier.testTag("auto_translate_chip")
                    )

                    AssistChip(
                        onClick = { if (!isTranslatingAll) onTranslateAllMessages() },
                        enabled = !isTranslatingAll && messages.any { !it.isStreaming && !it.isError },
                        leadingIcon = {
                            if (isTranslatingAll) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Translate,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        },
                        label = { Text(strings.translateAll) },
                        modifier = Modifier.testTag("translate_all_chat_chip")
                    )
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val displayMessage = if (msg.id == "welcome") {
                        msg.copy(text = strings.welcomeGreeting)
                    } else {
                        msg
                    }
                    ChatBubble(
                        message = displayMessage,
                        secretaryLabel = strings.yourSecretary,
                        translateLabel = strings.translate,
                        translatingLabel = strings.translating,
                        translatedToLabel = strings.translatedTo,
                        hideTranslationLabel = strings.hideTranslation,
                        showTranslationLabel = strings.showTranslation,
                        onTranslate = { onTranslateMessage(msg.id) },
                        onToggleTranslation = { onToggleMessageTranslation(msg.id) }
                    )
                }
            }

            // Suggested Prompts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickPrompts.forEach { prompt ->
                    AssistChip(
                        onClick = { if (!isBusy) onSendMessage(prompt) },
                        label = { Text(prompt) }
                    )
                }
            }

            // Input Row
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = {
                            Text(
                                text = strings.askSecretaryHint,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        maxLines = 3,
                        shape = RoundedCornerShape(16.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (input.isNotBlank() && !isBusy) {
                                    onSendMessage(input)
                                    input = ""
                                }
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("secretary_chat_input")
                    )

                    IconButton(
                        onClick = {
                            if (input.isNotBlank() && !isTranslatingDraft) {
                                onTranslateDraft(input) { translated ->
                                    input = translated
                                }
                            }
                        },
                        enabled = input.isNotBlank() && !isTranslatingDraft && !isBusy,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("translate_draft_button")
                    ) {
                        if (isTranslatingDraft) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = strings.translateDraft,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            if (input.isNotBlank() && !isBusy) {
                                onSendMessage(input)
                                input = ""
                            }
                        },
                        enabled = input.isNotBlank() && !isBusy,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("secretary_chat_send_button")
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send message",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showTargetPicker) {
        LanguagePickerDialog(
            title = strings.targetLanguage,
            selectedLanguage = chatTargetLanguage,
            onSelectLanguage = onSelectChatTargetLanguage,
            onDismiss = { showTargetPicker = false }
        )
    }

    if (showConversationSheet) {
        ConversationTranslatorSheet(
            turns = conversationTurns,
            isTranslating = isTranslatingConversation,
            pastedResult = pastedConversationResult,
            defaultTargetLanguage = chatTargetLanguage,
            onTranslateTurn = onTranslateLiveTurn,
            onTranslatePasted = onTranslatePastedConversation,
            onClear = onClearConversationTranslator,
            onDismiss = { showConversationSheet = false }
        )
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
    secretaryLabel: String,
    translateLabel: String,
    translatingLabel: String,
    translatedToLabel: String,
    hideTranslationLabel: String,
    showTranslationLabel: String,
    onTranslate: () -> Unit,
    onToggleTranslation: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var copied by remember(message.id) { mutableStateOf(false) }

    val contentColor = when {
        message.isUser -> MaterialTheme.colorScheme.onPrimary
        message.isError -> MaterialTheme.colorScheme.onErrorContainer
        else -> MaterialTheme.colorScheme.onSurface
    }
    val secondaryContentColor = when {
        message.isUser -> MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
        message.isError -> MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = when {
                message.isUser -> MaterialTheme.colorScheme.primary
                message.isError -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            },
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (message.isUser) 18.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 18.dp
            ),
            modifier = Modifier
                .widthIn(max = 560.dp)
                .testTag("chat_bubble_${message.id}")
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!message.isUser) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = secretaryLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (message.isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                if (message.isStreaming && message.text.isBlank()) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .padding(vertical = 4.dp)
                            .size(18.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = contentColor
                    )
                }

                if (!message.translatedText.isNullOrBlank() && message.showTranslation) {
                    HorizontalDivider(
                        color = secondaryContentColor.copy(alpha = 0.25f)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = "$translatedToLabel ${message.translatedLanguageName.orEmpty()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = secondaryContentColor
                        )
                        Text(
                            text = message.translatedText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = contentColor
                        )
                    }
                }

                if (!message.isStreaming && !message.isError && message.text.isNotBlank()) {
                    Row(
                        modifier = Modifier.padding(top = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(enabled = !message.isTranslating, onClick = onTranslate)
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("translate_msg_${message.id}")
                        ) {
                            if (message.isTranslating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(13.dp),
                                    strokeWidth = 1.8.dp,
                                    color = secondaryContentColor
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Translate,
                                    contentDescription = translateLabel,
                                    tint = secondaryContentColor,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Text(
                                text = if (message.isTranslating) translatingLabel else translateLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = secondaryContentColor
                            )
                        }

                        if (!message.translatedText.isNullOrBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(onClick = onToggleTranslation)
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                                    .testTag("toggle_translation_${message.id}")
                            ) {
                                Icon(
                                    imageVector = if (message.showTranslation) {
                                        Icons.Filled.VisibilityOff
                                    } else {
                                        Icons.Filled.Visibility
                                    },
                                    contentDescription = if (message.showTranslation) {
                                        hideTranslationLabel
                                    } else {
                                        showTranslationLabel
                                    },
                                    tint = secondaryContentColor,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val copyText = if (!message.translatedText.isNullOrBlank() && message.showTranslation) {
                                        message.translatedText
                                    } else {
                                        message.text
                                    }
                                    clipboard.setText(AnnotatedString(copyText))
                                    copied = true
                                }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("copy_msg_${message.id}")
                        ) {
                            Icon(
                                imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                                contentDescription = "Copy",
                                tint = secondaryContentColor,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
