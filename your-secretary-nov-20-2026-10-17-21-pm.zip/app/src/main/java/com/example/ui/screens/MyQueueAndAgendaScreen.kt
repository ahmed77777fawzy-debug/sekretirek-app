package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppStrings
import com.example.model.Appointment
import com.example.model.QueueTicket
import com.example.model.ScheduleViewMode
import com.example.model.SecretaryTask
import com.example.model.TicketStatus
import com.example.model.UiState
import com.example.ui.components.VisualMatrixBadge

@Composable
fun MyQueueAndAgendaScreen(
    ticketsState: UiState<List<QueueTicket>>,
    selectedDateKey: String,
    viewMode: ScheduleViewMode,
    appointmentsState: UiState<List<Appointment>>,
    tasksState: UiState<List<SecretaryTask>>,
    onCancelTicket: (QueueTicket) -> Unit,
    onExploreDirectory: () -> Unit,
    onSelectDate: (String) -> Unit,
    onViewModeChange: (ScheduleViewMode) -> Unit,
    onNavigatePeriod: (Boolean) -> Unit,
    onJumpToToday: () -> Unit,
    onAddAppointment: (String) -> Unit,
    onAppointmentClick: (Appointment) -> Unit,
    onAddTaskForDate: (String) -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onEditTask: (SecretaryTask) -> Unit
) {
    val strings = LocalAppStrings.current
    var subMode by remember { mutableStateOf(0) } // 0 = My Live Queue, 1 = Calendar

    Column(modifier = Modifier.fillMaxSize()) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            SegmentedButton(
                selected = subMode == 0,
                onClick = { subMode = 0 },
                shape = SegmentedButtonDefaults.itemShape(0, 2),
                modifier = Modifier.testTag("my_queue_tab_tickets")
            ) {
                val activeCount = (ticketsState as? UiState.Success)?.data
                    ?.count { it.resolvedStatus().isActiveQueue() } ?: 0
                Text(if (activeCount > 0) "${strings.navMyQueue} ($activeCount)" else strings.navMyQueue)
            }
            SegmentedButton(
                selected = subMode == 1,
                onClick = { subMode = 1 },
                shape = SegmentedButtonDefaults.itemShape(1, 2),
                modifier = Modifier.testTag("my_queue_tab_calendar")
            ) {
                Text(strings.navCalendar)
            }
        }

        if (subMode == 1) {
            CalendarScreen(
                selectedDateKey = selectedDateKey,
                viewMode = viewMode,
                appointmentsState = appointmentsState,
                tasksState = tasksState,
                onSelectDate = onSelectDate,
                onViewModeChange = onViewModeChange,
                onNavigatePeriod = onNavigatePeriod,
                onJumpToToday = onJumpToToday,
                onAddAppointment = onAddAppointment,
                onAppointmentClick = onAppointmentClick,
                onAddTaskForDate = onAddTaskForDate,
                onToggleTask = onToggleTask,
                onEditTask = onEditTask
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (ticketsState) {
                    is UiState.Loading -> {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator()
                            }
                        }
                    }
                    is UiState.Error -> {
                        item {
                            Text(
                                text = ticketsState.message,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                    is UiState.Success -> {
                        val tickets = ticketsState.data
                        if (tickets.isEmpty()) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            Icons.Filled.ConfirmationNumber,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(44.dp)
                                        )
                                        Text(
                                            text = strings.titleMyQueue,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "You have no active queue numbers yet. Pick any company, clinic, factory, or interview slot with $0 booking fee.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Button(
                                            onClick = onExploreDirectory,
                                            modifier = Modifier.testTag("empty_explore_directory_button")
                                        ) {
                                            Icon(Icons.Filled.Search, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(strings.navQueueHub)
                                        }
                                    }
                                }
                            }
                        } else {
                            items(tickets, key = { it.id }) { ticket ->
                                VisitorTicketCard(
                                    ticket = ticket,
                                    onCancel = { onCancelTicket(ticket) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VisitorTicketCard(
    ticket: QueueTicket,
    onCancel: () -> Unit
) {
    val strings = LocalAppStrings.current
    val status = ticket.resolvedStatus()
    val isCalled = status == TicketStatus.CALLED || status == TicketStatus.SERVING
    val cardColor = when {
        isCalled -> MaterialTheme.colorScheme.primaryContainer
        status.isTerminal() -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        else -> MaterialTheme.colorScheme.surface
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("visitor_ticket_card_${ticket.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (isCalled) {
                            Icon(
                                Icons.Filled.NotificationsActive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = ticket.orgName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${ticket.counterName} • ${ticket.dateKey} ${ticket.slotLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    color = if (isCalled) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.secondaryContainer
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = status.name,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isCalled) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.yourTurnNumber,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = ticket.ticketCode,
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${strings.liveWaitMinutes}: ~${ticket.estimatedWaitMinutes}m • ${strings.zeroBookingFeeBadge}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                VisualMatrixBadge(
                    seed = "${ticket.orgId}:${ticket.ticketCode}:${ticket.id}",
                    modifier = Modifier.size(72.dp)
                )
            }

            if (status.isActiveQueue()) {
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cancel_ticket_button_${ticket.id}")
                ) {
                    Icon(Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.cancelTicket)
                }
            }
        }
    }
}
