package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguages
import com.example.i18n.LocalAppLanguage
import com.example.i18n.LocalAppStrings
import com.example.i18n.SupportedLanguage
import com.example.model.ConversationTurn

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationTranslatorSheet(
    turns: List<ConversationTurn>,
    isTranslating: Boolean,
    pastedResult: String?,
    defaultTargetLanguage: SupportedLanguage,
    onTranslateTurn: (text: String, speakerLabel: String, from: SupportedLanguage, to: SupportedLanguage) -> Unit,
    onTranslatePasted: (transcript: String, targetLanguage: SupportedLanguage) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val appLanguage = LocalAppLanguage.current
    val clipboard = LocalClipboardManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Live Dialogue, 1 = Paste Chat
    var languageA by remember { mutableStateOf(appLanguage) }
    var languageB by remember {
        mutableStateOf(
            if (defaultTargetLanguage.code.equals(appLanguage.code, ignoreCase = true)) {
                if (appLanguage.code.equals("en", ignoreCase = true)) AppLanguages.ARABIC else AppLanguages.ENGLISH
            } else {
                defaultTargetLanguage
            }
        )
    }
    var activeSpeakerIsA by remember { mutableStateOf(true) }
    var liveInput by remember { mutableStateOf("") }

    var pasteTargetLanguage by remember { mutableStateOf(defaultTargetLanguage) }
    var pasteInput by remember { mutableStateOf("") }
    var copiedTurnId by remember { mutableStateOf<String?>(null) }
    var copiedPasted by remember { mutableStateOf(false) }

    var pickerMode by remember { mutableStateOf<String?>(null) } // "A", "B", "PASTE"
    val turnsListState = rememberLazyListState()

    LaunchedEffect(turns.size) {
        if (turns.isNotEmpty()) {
            turnsListState.animateScrollToItem(turns.lastIndex)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = Modifier.testTag("conversation_translator_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    Column {
                        Text(
                            text = strings.conversationTranslator,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = strings.conversationTranslatorSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (turns.isNotEmpty() || !pastedResult.isNullOrBlank()) {
                    IconButton(
                        onClick = {
                            onClear()
                            pasteInput = ""
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("clear_translator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = "Clear",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                listOf(strings.liveDialogueTab, strings.pasteChatTab).forEachIndexed { index, label ->
                    SegmentedButton(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = 2),
                        modifier = Modifier.testTag("translator_tab_$index")
                    ) {
                        Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            if (selectedTab == 0) {
                // Language A <-> Language B pair selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LanguageSelectorChip(
                        language = languageA,
                        onClick = { pickerMode = "A" },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("translator_lang_a_button")
                    )
                    IconButton(
                        onClick = {
                            val temp = languageA
                            languageA = languageB
                            languageB = temp
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("translator_swap_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SwapHoriz,
                            contentDescription = "Swap languages",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    LanguageSelectorChip(
                        language = languageB,
                        onClick = { pickerMode = "B" },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("translator_lang_b_button")
                    )
                }

                // Dialogue turns list
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 300.dp)
                ) {
                    if (turns.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${languageA.nativeName} ↔ ${languageB.nativeName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            state = turnsListState,
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(turns, key = { it.id }) { turn ->
                                ConversationTurnCard(
                                    turn = turn,
                                    isCopied = copiedTurnId == turn.id,
                                    onCopy = {
                                        clipboard.setText(AnnotatedString(turn.translatedText))
                                        copiedTurnId = turn.id
                                    }
                                )
                            }
                        }
                    }
                }

                // Active Speaker toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = activeSpeakerIsA,
                        onClick = { activeSpeakerIsA = true },
                        label = {
                            Text(
                                text = "${languageA.nativeName} → ${languageB.nativeName}",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("speaker_a_chip")
                    )
                    FilterChip(
                        selected = !activeSpeakerIsA,
                        onClick = { activeSpeakerIsA = false },
                        label = {
                            Text(
                                text = "${languageB.nativeName} → ${languageA.nativeName}",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("speaker_b_chip")
                    )
                }

                val fromLang = if (activeSpeakerIsA) languageA else languageB
                val toLang = if (activeSpeakerIsA) languageB else languageA
                val speakerName = if (activeSpeakerIsA) languageA.nativeName else languageB.nativeName

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = liveInput,
                        onValueChange = { liveInput = it },
                        placeholder = { Text(strings.typeMessagePlaceholder) },
                        maxLines = 3,
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (liveInput.isNotBlank() && !isTranslating) {
                                    onTranslateTurn(liveInput, speakerName, fromLang, toLang)
                                    liveInput = ""
                                }
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("live_translator_input")
                    )
                    IconButton(
                        onClick = {
                            if (liveInput.isNotBlank() && !isTranslating) {
                                onTranslateTurn(liveInput, speakerName, fromLang, toLang)
                                liveInput = ""
                            }
                        },
                        enabled = liveInput.isNotBlank() && !isTranslating,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("live_translator_send_button")
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = strings.translate,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            } else {
                // Paste Chat Transcript Tab
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 460.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = strings.targetLanguage,
                            style = MaterialTheme.typography.titleSmall
                        )
                        LanguageSelectorChip(
                            language = pasteTargetLanguage,
                            onClick = { pickerMode = "PASTE" },
                            modifier = Modifier.testTag("paste_target_lang_button")
                        )
                    }

                    OutlinedTextField(
                        value = pasteInput,
                        onValueChange = { pasteInput = it },
                        placeholder = { Text(strings.pasteChatPlaceholder) },
                        minLines = 4,
                        maxLines = 7,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("paste_chat_input")
                    )

                    Button(
                        onClick = { onTranslatePasted(pasteInput, pasteTargetLanguage) },
                        enabled = pasteInput.isNotBlank() && !isTranslating,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("translate_pasted_chat_button")
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.translating)
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.translateConversationAction)
                        }
                    }

                    if (!pastedResult.isNullOrBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pasted_translation_result_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${strings.translatedTo} ${pasteTargetLanguage.nativeName}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    TextButton(
                                        onClick = {
                                            clipboard.setText(AnnotatedString(pastedResult))
                                            copiedPasted = true
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (copiedPasted) Icons.Filled.Check else Icons.Filled.ContentCopy,
                                            contentDescription = "Copy",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = pastedResult,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    when (pickerMode) {
        "A" -> LanguagePickerDialog(
            title = strings.languageSettingsTitle,
            selectedLanguage = languageA,
            onSelectLanguage = { languageA = it },
            onDismiss = { pickerMode = null }
        )
        "B" -> LanguagePickerDialog(
            title = strings.languageSettingsTitle,
            selectedLanguage = languageB,
            onSelectLanguage = { languageB = it },
            onDismiss = { pickerMode = null }
        )
        "PASTE" -> LanguagePickerDialog(
            title = strings.targetLanguage,
            selectedLanguage = pasteTargetLanguage,
            onSelectLanguage = { pasteTargetLanguage = it },
            onDismiss = { pickerMode = null }
        )
    }
}

@Composable
private fun LanguageSelectorChip(
    language: SupportedLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = language.nativeName,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ConversationTurnCard(
    turn: ConversationTurn,
    isCopied: Boolean,
    onCopy: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${turn.sourceLanguageName} → ${turn.targetLanguageName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (isCopied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                        contentDescription = "Copy translation",
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(
                text = turn.originalText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            Text(
                text = turn.translatedText,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
