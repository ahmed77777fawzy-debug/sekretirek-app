package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppLanguage
import com.example.i18n.LocalAppStrings
import com.example.model.Appointment
import com.example.model.ExecutiveMemo
import com.example.model.SecretaryTask
import com.example.model.TaskPriority
import com.example.model.UiState
import com.example.util.DateUtils

private enum class TaskFilter(val label: String) {
    ALL("All"),
    OPEN("Open"),
    COMPLETED("Done"),
    LINKED("Agenda-Linked"),
    HIGH("High Priority")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksMemosScreen(
    tasksState: UiState<List<SecretaryTask>>,
    memosState: UiState<List<ExecutiveMemo>>,
    appointments: List<Appointment>,
    draftingMemoId: String?,
    onOpenNewTask: () -> Unit,
    onEditTask: (SecretaryTask) -> Unit,
    onToggleTask: (SecretaryTask) -> Unit,
    onDeleteTask: (String) -> Unit,
    onOpenDateInCalendar: (String) -> Unit,
    onOpenLinkedAppointment: (String) -> Unit,
    onSaveMemo: (String?, String, String, Boolean, String) -> Unit,
    onToggleMemoPin: (ExecutiveMemo) -> Unit,
    onDraftMemoFollowUp: (ExecutiveMemo) -> Unit,
    onDeleteMemo: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Tasks, 1 = Memos
    var activeFilter by remember { mutableStateOf(TaskFilter.ALL) }
    var showMemoEditor by remember { mutableStateOf(false) }
    var editingMemo by remember { mutableStateOf<ExecutiveMemo?>(null) }

    val apptTitleById = remember(appointments) {
        appointments.associate { it.id to it.title }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 820.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.weight(1f)) {
                    listOf(strings.actionItems, strings.memos).forEachIndexed { idx, label ->
                        SegmentedButton(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            shape = SegmentedButtonDefaults.itemShape(index = idx, count = 2),
                            modifier = Modifier.testTag("desk_tab_$idx")
                        ) {
                            Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Button(
                    onClick = {
                        if (selectedTab == 0) {
                            onOpenNewTask()
                        } else {
                            editingMemo = null
                            showMemoEditor = true
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("desk_add_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (selectedTab == 0) strings.taskLabel else strings.memoLabel)
                }
            }

            if (selectedTab == 0) {
                when (tasksState) {
                    UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    is UiState.Error -> Text(tasksState.message, color = MaterialTheme.colorScheme.error)
                    is UiState.Success -> {
                        val allTasks = tasksState.data
                        val completedCount = allTasks.count { it.completed }
                        val filteredTasks = remember(allTasks, activeFilter) {
                            when (activeFilter) {
                                TaskFilter.ALL -> allTasks
                                TaskFilter.OPEN -> allTasks.filter { !it.completed }
                                TaskFilter.COMPLETED -> allTasks.filter { it.completed }
                                TaskFilter.LINKED -> allTasks.filter { it.isLinkedToAgenda }
                                TaskFilter.HIGH -> allTasks.filter { it.resolvedPriority() == TaskPriority.HIGH }
                            }
                        }

                        if (allTasks.isNotEmpty()) {
                            // Task Completion Progress Card
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = strings.taskCompletion,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "$completedCount / ${allTasks.size}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    LinearProgressIndicator(
                                        progress = { completedCount.toFloat() / allTasks.size.coerceAtLeast(1) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(7.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                    )
                                }
                            }

                            // Filter Chips
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                TaskFilter.entries.forEach { filter ->
                                    val filterLabel = when (filter) {
                                        TaskFilter.ALL -> strings.allFilter
                                        TaskFilter.OPEN -> strings.openFilter
                                        TaskFilter.COMPLETED -> strings.completedFilter
                                        TaskFilter.LINKED -> strings.linkedFilter
                                        TaskFilter.HIGH -> strings.highPriorityFilter
                                    }
                                    FilterChip(
                                        selected = activeFilter == filter,
                                        onClick = { activeFilter = filter },
                                        label = { Text(filterLabel) },
                                        modifier = Modifier.testTag("task_filter_${filter.name.lowercase()}")
                                    )
                                }
                            }
                        }

                        if (allTasks.isEmpty()) {
                            EmptyDeskCard(
                                title = "No action items yet",
                                subtitle = "Create tasks linked to your calendar dates or scheduled appointments.",
                                buttonLabel = "Add First Task",
                                onAdd = onOpenNewTask
                            )
                        } else if (filteredTasks.isEmpty()) {
                            EmptyDeskCard(
                                title = "No matching tasks",
                                subtitle = "Try switching filters or add a new action item.",
                                buttonLabel = "Show All Tasks",
                                onAdd = { activeFilter = TaskFilter.ALL }
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(bottom = 84.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredTasks, key = { it.id }) { task ->
                                    val resolvedApptTitle = apptTitleById[task.linkedAppointmentId]
                                        ?: task.linkedAppointmentTitle
                                    TaskRowCard(
                                        task = task,
                                        linkedAppointmentTitle = resolvedApptTitle,
                                        onToggle = { onToggleTask(task) },
                                        onEdit = { onEditTask(task) },
                                        onDelete = { onDeleteTask(task.id) },
                                        onOpenDateInCalendar = {
                                            if (task.dueDateKey.isNotBlank()) {
                                                onOpenDateInCalendar(task.dueDateKey)
                                            }
                                        },
                                        onOpenLinkedAppointment = {
                                            if (task.linkedAppointmentId.isNotBlank()) {
                                                onOpenLinkedAppointment(task.linkedAppointmentId)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                when (memosState) {
                    UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    is UiState.Error -> Text(memosState.message, color = MaterialTheme.colorScheme.error)
                    is UiState.Success -> {
                        if (memosState.data.isEmpty()) {
                            EmptyDeskCard(
                                title = "No executive memos yet",
                                subtitle = "Jot down meeting takeaways and let your secretary draft follow-up emails.",
                                buttonLabel = "Write Memo",
                                onAdd = { editingMemo = null; showMemoEditor = true }
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(bottom = 84.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(memosState.data, key = { it.id }) { memo ->
                                    MemoCard(
                                        memo = memo,
                                        isDrafting = draftingMemoId == memo.id,
                                        onTogglePin = { onToggleMemoPin(memo) },
                                        onEdit = { editingMemo = memo; showMemoEditor = true },
                                        onDraftFollowUp = { onDraftMemoFollowUp(memo) },
                                        onDelete = { onDeleteMemo(memo.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showMemoEditor) {
        MemoEditorSheet(
            editingMemo = editingMemo,
            onDismiss = { showMemoEditor = false },
            onSave = { title, body, pinned ->
                onSaveMemo(
                    editingMemo?.id,
                    title,
                    body,
                    pinned,
                    editingMemo?.aiDraft.orEmpty()
                )
                showMemoEditor = false
            }
        )
    }
}

@Composable
private fun TaskRowCard(
    task: SecretaryTask,
    linkedAppointmentTitle: String,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onOpenDateInCalendar: () -> Unit,
    onOpenLinkedAppointment: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit)
            .testTag("task_card_${task.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.testTag("task_toggle_${task.id}")
            ) {
                Icon(
                    imageVector = if (task.completed) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = "Toggle task completion",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None
                )
                if (task.details.isNotBlank()) {
                    Text(
                        text = task.details,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = when (task.resolvedPriority()) {
                            TaskPriority.HIGH -> MaterialTheme.colorScheme.errorContainer
                            TaskPriority.NORMAL -> MaterialTheme.colorScheme.surfaceVariant
                            TaskPriority.LOW -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = task.resolvedPriority().label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (task.resolvedPriority() == TaskPriority.HIGH) {
                                MaterialTheme.colorScheme.onErrorContainer
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (task.dueDateKey.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable(onClick = onOpenDateInCalendar)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CalendarToday,
                                    contentDescription = "Jump to date in agenda",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = DateUtils.formatShortDate(task.dueDateKey, LocalAppLanguage.current.toLocale()),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }

                    if (task.linkedAppointmentId.isNotBlank() && linkedAppointmentTitle.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable(onClick = onOpenLinkedAppointment)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Event,
                                    contentDescription = "Open linked appointment",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = linkedAppointmentTitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
            Row {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.testTag("task_edit_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = "Edit task",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("task_delete_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Delete task",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MemoCard(
    memo: ExecutiveMemo,
    isDrafting: Boolean,
    onTogglePin: () -> Unit,
    onEdit: () -> Unit,
    onDraftFollowUp: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = memo.title,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                Row {
                    IconButton(onClick = onTogglePin) {
                        Icon(
                            imageVector = if (memo.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin memo",
                            tint = if (memo.pinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete memo",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Text(
                text = memo.body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (memo.aiDraft.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "SECRETARY FOLLOW-UP DRAFT",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = memo.aiDraft,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            val strings = LocalAppStrings.current
            TextButton(
                onClick = onDraftFollowUp,
                enabled = !isDrafting
            ) {
                if (isDrafting) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("…")
                } else {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (memo.aiDraft.isBlank()) strings.draftFollowUp else strings.refreshAi)
                }
            }
        }
    }
}

@Composable
private fun EmptyDeskCard(
    title: String,
    subtitle: String,
    buttonLabel: String,
    onAdd: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(text = title, style = MaterialTheme.typography.titleLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(onClick = onAdd, shape = RoundedCornerShape(12.dp)) {
                Text(buttonLabel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MemoEditorSheet(
    editingMemo: ExecutiveMemo?,
    onDismiss: () -> Unit,
    onSave: (String, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf(editingMemo?.title.orEmpty()) }
    var body by remember { mutableStateOf(editingMemo?.body.orEmpty()) }
    var pinned by remember { mutableStateOf(editingMemo?.pinned ?: false) }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (editingMemo == null) "New Executive Memo" else "Edit Memo",
                style = MaterialTheme.typography.headlineMedium
            )
            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(120); error = null },
                label = { Text("Memo title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = body,
                onValueChange = { body = it.take(4000); error = null },
                label = { Text("Notes / meeting minutes") },
                minLines = 4,
                maxLines = 8,
                modifier = Modifier.fillMaxWidth()
            )
            FilterChip(
                selected = pinned,
                onClick = { pinned = !pinned },
                label = { Text(if (pinned) "Pinned to Briefing" else "Pin to Briefing") }
            )
            if (error != null) {
                Text(error.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            val strings = LocalAppStrings.current
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text(strings.cancel) }
                Button(
                    onClick = {
                        if (title.trim().isEmpty() || body.trim().isEmpty()) {
                            error = "Title and memo content are required."
                        } else {
                            onSave(title, body, pinned)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(strings.save)
                }
            }
        }
    }
}
