package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppStrings
import com.example.model.QueueCounter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CounterEditorSheet(
    editingCounter: QueueCounter?,
    onSave: (
        existingCounterId: String?,
        name: String,
        serviceTrack: String,
        prefix: String,
        avgServiceMinutes: Int,
        maxWaitingLimit: Int,
        open: Boolean,
        acceptingQueue: Boolean,
        acceptingAppointments: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember(editingCounter) { mutableStateOf(editingCounter?.name.orEmpty()) }
    var serviceTrack by remember(editingCounter) { mutableStateOf(editingCounter?.serviceTrack.orEmpty()) }
    var prefix by remember(editingCounter) { mutableStateOf(editingCounter?.prefix ?: "B") }
    var avgMinutesText by remember(editingCounter) { mutableStateOf((editingCounter?.avgServiceMinutes ?: 10).toString()) }
    var maxWaitingText by remember(editingCounter) { mutableStateOf((editingCounter?.maxWaitingLimit ?: 35).toString()) }
    var open by remember(editingCounter) { mutableStateOf(editingCounter?.open ?: true) }
    var acceptingQueue by remember(editingCounter) { mutableStateOf(editingCounter?.acceptingQueue ?: true) }
    var acceptingAppointments by remember(editingCounter) { mutableStateOf(editingCounter?.acceptingAppointments ?: true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (editingCounter == null) strings.addCounter else editingCounter.name,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Counter / Gate Name * (e.g., Desk A, Room 2)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("counter_name_input")
            )

            OutlinedTextField(
                value = serviceTrack,
                onValueChange = { serviceTrack = it },
                label = { Text("Service Track * (e.g., Consultations, VIP, Deliveries)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("counter_track_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = prefix,
                    onValueChange = { prefix = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(3) },
                    label = { Text("Prefix") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("counter_prefix_input")
                )
                OutlinedTextField(
                    value = avgMinutesText,
                    onValueChange = { avgMinutesText = it.filter { c -> c.isDigit() } },
                    label = { Text("Avg Mins") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = maxWaitingText,
                    onValueChange = { maxWaitingText = it.filter { c -> c.isDigit() } },
                    label = { Text(strings.crowdLimitLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("counter_max_limit_input")
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Counter Open", style = MaterialTheme.typography.bodyLarge)
                Switch(checked = open, onCheckedChange = { open = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.walkInTicket, style = MaterialTheme.typography.bodyLarge)
                Switch(checked = acceptingQueue, onCheckedChange = { acceptingQueue = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.numberedAppointment, style = MaterialTheme.typography.bodyLarge)
                Switch(checked = acceptingAppointments, onCheckedChange = { acceptingAppointments = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text(strings.cancel)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val avg = avgMinutesText.toIntOrNull()?.coerceIn(1, 240) ?: 10
                        val limit = maxWaitingText.toIntOrNull()?.coerceIn(1, 2000) ?: 35
                        onSave(
                            editingCounter?.id,
                            name,
                            serviceTrack,
                            prefix.ifBlank { "A" },
                            avg,
                            limit,
                            open,
                            acceptingQueue,
                            acceptingAppointments
                        )
                        onDismiss()
                    },
                    enabled = name.isNotBlank() && serviceTrack.isNotBlank(),
                    modifier = Modifier.testTag("save_counter_button")
                ) {
                    Text(strings.save)
                }
            }
        }
    }
}
