package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppStrings
import com.example.model.BookingType
import com.example.model.Organization
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.UiState
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun OrganizationBookingSheet(
    organization: Organization,
    countersState: UiState<List<QueueCounter>>,
    defaultVisitorName: String,
    isSubmitting: Boolean,
    onOpenVisualDisplay: (List<QueueCounter>) -> Unit,
    onBookTicket: (
        counter: QueueCounter,
        visitorName: String,
        visitorPhone: String,
        visitorNotes: String,
        bookingType: BookingType,
        dateKey: String,
        slotLabel: String,
        onBooked: (QueueTicket) -> Unit
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val counters = (countersState as? UiState.Success)?.data.orEmpty()
    var selectedCounterId by remember(counters) { mutableStateOf(counters.firstOrNull()?.id.orEmpty()) }
    val selectedCounter = counters.firstOrNull { it.id == selectedCounterId } ?: counters.firstOrNull()

    var bookingType by remember { mutableStateOf(BookingType.WALK_IN) }
    var dateOffsetDays by remember { mutableStateOf(0) }
    val slotOptions = remember { listOf("09:30", "11:00", "13:30", "15:00", "17:30", "19:00") }
    var selectedSlot by remember { mutableStateOf(slotOptions.first()) }

    var visitorName by remember { mutableStateOf(defaultVisitorName) }
    var visitorPhone by remember { mutableStateOf("") }
    var visitorNotes by remember { mutableStateOf("") }
    var bookedTicket by remember { mutableStateOf<QueueTicket?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = organization.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${organization.resolvedSector().label(strings)} • ${organization.profession}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = strings.zeroBookingFeeBadge,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            if (organization.description.isNotBlank()) {
                Text(
                    text = organization.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (organization.city.isNotBlank() || organization.address.isNotBlank()) {
                    OutlinedButton(
                        onClick = {
                            val q = Uri.encode("${organization.name} ${organization.address} ${organization.city}")
                            runCatching {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
                            }
                        },
                        modifier = Modifier.testTag("org_open_maps_button")
                    ) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(organization.city.ifBlank { strings.openInMaps })
                    }
                }
                if (counters.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { onOpenVisualDisplay(counters) },
                        modifier = Modifier.testTag("org_open_visual_display_button")
                    ) {
                        Icon(Icons.Filled.Tv, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.visualDisplayBoard)
                    }
                }
            }

            val ticket = bookedTicket
            if (ticket != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = strings.yourTurnNumber,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = ticket.ticketCode,
                                    style = MaterialTheme.typography.displaySmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "${ticket.counterName} • ${ticket.slotLabel}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "${strings.liveWaitMinutes}: ~${ticket.estimatedWaitMinutes}m • ${strings.zeroBookingFeeBadge}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            VisualMatrixBadge(
                                seed = "${ticket.orgId}:${ticket.ticketCode}:${ticket.id}",
                                modifier = Modifier.size(76.dp)
                            )
                        }
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_done_button")
                        ) {
                            Text(strings.confirmAndSave)
                        }
                    }
                }
            } else {
                when (countersState) {
                    is UiState.Loading -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                    is UiState.Error -> {
                        Text(
                            text = countersState.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    is UiState.Success -> {
                        if (counters.isEmpty()) {
                            Text(
                                text = "No active reception counters yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(
                                text = strings.liveCountersTab,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            counters.forEach { counter ->
                                val isSelected = selectedCounter?.id == counter.id
                                val ratio = (counter.waitingCount.toFloat() / counter.maxWaitingLimit.coerceAtLeast(1))
                                    .coerceIn(0f, 1f)
                                Card(
                                    onClick = { selectedCounterId = counter.id },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) {
                                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                        }
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("select_counter_${counter.id}")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = counter.name,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${counter.serviceTrack} • ${strings.nowServing}: ${counter.currentServingCode()}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Surface(
                                                color = MaterialTheme.colorScheme.secondaryContainer,
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Text(
                                                    text = "~${counter.estimatedWaitMinutes()}m",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                        LinearProgressIndicator(
                                            progress = { ratio },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Text(
                                            text = "${strings.crowdLimitLabel}: ${counter.waitingCount}/${counter.maxWaitingLimit} • Next: ${counter.nextIssuedPreviewCode()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                SegmentedButton(
                                    selected = bookingType == BookingType.WALK_IN,
                                    onClick = { bookingType = BookingType.WALK_IN },
                                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                                    modifier = Modifier.testTag("booking_mode_walkin")
                                ) {
                                    Text(strings.walkInTicket)
                                }
                                SegmentedButton(
                                    selected = bookingType == BookingType.APPOINTMENT,
                                    onClick = { bookingType = BookingType.APPOINTMENT },
                                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                                    modifier = Modifier.testTag("booking_mode_appointment")
                                ) {
                                    Text(strings.numberedAppointment)
                                }
                            }

                            if (bookingType == BookingType.APPOINTMENT) {
                                val todayKey = remember { DateUtils.todayDateKey() }
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    listOf(0, 1, 2).forEach { offset ->
                                        val dKey = DateUtils.shiftDateKey(todayKey, offset)
                                        FilterChip(
                                            selected = dateOffsetDays == offset,
                                            onClick = { dateOffsetDays = offset },
                                            label = { Text(if (offset == 0) strings.today else dKey.substring(5)) }
                                        )
                                    }
                                }
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    slotOptions.forEach { slot ->
                                        FilterChip(
                                            selected = selectedSlot == slot,
                                            onClick = { selectedSlot = slot },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.Schedule,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            },
                                            label = { Text(slot) }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = visitorName,
                                onValueChange = { visitorName = it },
                                label = { Text("Visitor Name") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("booking_visitor_name")
                            )
                            OutlinedTextField(
                                value = visitorPhone,
                                onValueChange = { visitorPhone = it },
                                label = { Text("Phone (optional)") },
                                leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("booking_visitor_phone")
                            )
                            OutlinedTextField(
                                value = visitorNotes,
                                onValueChange = { visitorNotes = it },
                                label = { Text("Visit Note (optional)") },
                                maxLines = 2,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("booking_visitor_notes")
                            )

                            val targetDateKey = DateUtils.shiftDateKey(
                                DateUtils.todayDateKey(),
                                if (bookingType == BookingType.WALK_IN) 0 else dateOffsetDays
                            )
                            Button(
                                onClick = {
                                    val counter = selectedCounter ?: return@Button
                                    onBookTicket(
                                        counter,
                                        visitorName,
                                        visitorPhone,
                                        visitorNotes,
                                        bookingType,
                                        targetDateKey,
                                        if (bookingType == BookingType.WALK_IN) "Walk-In" else selectedSlot
                                    ) { created ->
                                        bookedTicket = created
                                    }
                                },
                                enabled = !isSubmitting &&
                                    selectedCounter != null &&
                                    selectedCounter.open &&
                                    selectedCounter.acceptingQueue &&
                                    !selectedCounter.atCapacity() &&
                                    visitorName.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("confirm_queue_booking_button")
                            ) {
                                if (isSubmitting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Filled.ConfirmationNumber, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("${strings.getQueueNumber} (${strings.zeroBookingFeeBadge})")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
