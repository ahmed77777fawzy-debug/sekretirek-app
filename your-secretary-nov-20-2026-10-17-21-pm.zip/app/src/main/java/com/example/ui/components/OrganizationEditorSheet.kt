package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.LocalAppCurrency
import com.example.i18n.LocalAppStrings
import com.example.model.BusinessSector
import com.example.model.Organization

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun OrganizationEditorSheet(
    editingOrg: Organization?,
    onSave: (
        existingId: String?,
        name: String,
        sector: BusinessSector,
        profession: String,
        description: String,
        city: String,
        address: String,
        deskPhone: String,
        workingHours: String,
        currencyCode: String,
        maxDailyCapacity: Int,
        acceptingBookings: Boolean,
        listedPublicly: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val currency = LocalAppCurrency.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember(editingOrg) { mutableStateOf(editingOrg?.name.orEmpty()) }
    var sector by remember(editingOrg) { mutableStateOf(editingOrg?.resolvedSector() ?: BusinessSector.COMPANY) }
    var profession by remember(editingOrg) { mutableStateOf(editingOrg?.profession.orEmpty()) }
    var description by remember(editingOrg) { mutableStateOf(editingOrg?.description.orEmpty()) }
    var city by remember(editingOrg) { mutableStateOf(editingOrg?.city.orEmpty()) }
    var address by remember(editingOrg) { mutableStateOf(editingOrg?.address.orEmpty()) }
    var deskPhone by remember(editingOrg) { mutableStateOf(editingOrg?.deskPhone.orEmpty()) }
    var workingHours by remember(editingOrg) { mutableStateOf(editingOrg?.workingHours ?: "09:00 - 18:00") }
    var capacityText by remember(editingOrg) { mutableStateOf((editingOrg?.maxDailyCapacity ?: 150).toString()) }
    var acceptingBookings by remember(editingOrg) { mutableStateOf(editingOrg?.acceptingBookings ?: true) }
    var listedPublicly by remember(editingOrg) { mutableStateOf(editingOrg?.listedPublicly ?: true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (editingOrg == null) strings.createActivity else editingOrg.name,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Activity / Organization Name *") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("org_name_input")
            )

            Text(
                text = "Sector Classification",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BusinessSector.entries.forEach { option ->
                    FilterChip(
                        selected = sector == option,
                        onClick = { sector = option },
                        leadingIcon = {
                            Icon(
                                imageVector = option.icon(),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(option.label(strings)) },
                        modifier = Modifier.testTag("sector_chip_${option.name}")
                    )
                }
            }

            OutlinedTextField(
                value = profession,
                onValueChange = { profession = it },
                label = { Text("Profession / Specialty * (e.g., Dentistry, HR Interviews, Logistics)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("org_profession_input")
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Services Overview") },
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("org_description_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("City") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("org_city_input")
                )
                OutlinedTextField(
                    value = capacityText,
                    onValueChange = { capacityText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Daily Cap") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("org_capacity_input")
                )
            }

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Street Address / Building") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("org_address_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = deskPhone,
                    onValueChange = { deskPhone = it },
                    label = { Text("Reception Phone") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = workingHours,
                    onValueChange = { workingHours = it },
                    label = { Text("Working Hours") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Accept Live Bookings", style = MaterialTheme.typography.bodyLarge)
                Switch(
                    checked = acceptingBookings,
                    onCheckedChange = { acceptingBookings = it }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("List in Public Search Directory", style = MaterialTheme.typography.bodyLarge)
                Switch(
                    checked = listedPublicly,
                    onCheckedChange = { listedPublicly = it }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text(strings.cancel)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val cap = capacityText.toIntOrNull()?.coerceIn(1, 10000) ?: 150
                        onSave(
                            editingOrg?.id,
                            name,
                            sector,
                            profession,
                            description,
                            city,
                            address,
                            deskPhone,
                            workingHours,
                            editingOrg?.currencyCode ?: currency.code,
                            cap,
                            acceptingBookings,
                            listedPublicly
                        )
                        onDismiss()
                    },
                    enabled = name.isNotBlank() && profession.isNotBlank(),
                    modifier = Modifier.testTag("save_organization_button")
                ) {
                    Text(strings.save)
                }
            }
        }
    }
}
