package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Workspaces
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.model.BusinessSector

fun BusinessSector.icon(): ImageVector = when (this) {
    BusinessSector.COMPANY -> Icons.Filled.Business
    BusinessSector.CLINIC -> Icons.Filled.MedicalServices
    BusinessSector.HOSPITAL -> Icons.Filled.LocalHospital
    BusinessSector.FACTORY -> Icons.Filled.Factory
    BusinessSector.INTERVIEWS -> Icons.Filled.Badge
    BusinessSector.GOVERNMENT -> Icons.Filled.AccountBalance
    BusinessSector.FINANCE -> Icons.Filled.Payments
    BusinessSector.LEGAL_ENGINEERING -> Icons.Filled.Gavel
    BusinessSector.EDUCATION -> Icons.Filled.School
    BusinessSector.SALON_WELLNESS -> Icons.Filled.Spa
    BusinessSector.AUTO_SERVICE -> Icons.Filled.DirectionsCar
    BusinessSector.OTHER -> Icons.Filled.Workspaces
}
