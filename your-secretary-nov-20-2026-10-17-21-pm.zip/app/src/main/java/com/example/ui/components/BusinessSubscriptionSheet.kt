package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.i18n.LocalAppCurrency
import com.example.i18n.LocalAppStrings
import com.example.model.BusinessSubscription
import com.example.model.Organization
import com.example.model.PaymentGateway
import com.example.model.PlanTier
import com.example.model.SubscriptionStatus

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BusinessSubscriptionSheet(
    organization: Organization,
    currentSubscription: BusinessSubscription?,
    onActivatePlan: (
        org: Organization,
        planTier: PlanTier,
        gateway: PaymentGateway,
        currencyCode: String,
        monthlyPriceDisplay: String,
        status: SubscriptionStatus,
        externalRef: String
    ) -> Unit,
    onGatewayMissingNotice: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val currency = LocalAppCurrency.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var selectedPlan by remember(organization) { mutableStateOf(organization.resolvedPlan()) }
    var selectedGateway by remember { mutableStateOf(PaymentGateway.STRIPE) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Verified,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column {
                    Text(
                        text = "${strings.manageSubscription} • ${organization.name}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${strings.zeroBookingFeeBadge} • Self-service owner activation",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (currentSubscription != null) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null)
                        Column {
                            Text(
                                text = "${currentSubscription.planTier} (${currentSubscription.status})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${currentSubscription.monthlyPriceDisplay} ${strings.monthlyPlanLabel} • ${currentSubscription.resolvedGateway().displayName}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            PlanTier.entries.forEach { tier ->
                val priceLabel = currency.formatUsdPrice(tier.baseUsdMonthly)
                val selected = selectedPlan == tier
                val features = when (tier) {
                    PlanTier.STARTER -> "1 Live Counter • Unlimited $0 visitor tickets • Cloud Queue"
                    PlanTier.PRO -> "10 Live Counters • Visual Kiosk + TTS Voice • Customer CRM"
                    PlanTier.ENTERPRISE -> "Unlimited Counters & Branches • Multi-Staff • Priority Cloud"
                }
                Card(
                    onClick = { selectedPlan = tier },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("plan_card_${tier.name}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tier.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = features,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = priceLabel,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = strings.monthlyPlanLabel,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }

            if (selectedPlan == PlanTier.STARTER) {
                Button(
                    onClick = {
                        val freeLabel = currency.formatUsdPrice(0.0)
                        onActivatePlan(
                            organization,
                            PlanTier.STARTER,
                            PaymentGateway.SELF_FREE,
                            currency.code,
                            freeLabel,
                            SubscriptionStatus.ACTIVE,
                            "self-activated"
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("activate_starter_free_button")
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.selfActivateFree)
                }
            } else {
                Text(
                    text = strings.globalPaymentGateways,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                val paidGateways = listOf(
                    PaymentGateway.STRIPE,
                    PaymentGateway.PAYPAL,
                    PaymentGateway.GOOGLE_PAY,
                    PaymentGateway.APPLE_PAY,
                    PaymentGateway.MOYASAR,
                    PaymentGateway.TAP
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    paidGateways.forEach { gateway ->
                        FilterChip(
                            selected = selectedGateway == gateway,
                            onClick = { selectedGateway = gateway },
                            leadingIcon = {
                                Icon(
                                    Icons.Filled.CreditCard,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text(gateway.displayName) },
                            modifier = Modifier.testTag("gateway_chip_${gateway.name}")
                        )
                    }
                }

                val checkoutUrl = remember(selectedGateway, organization, selectedPlan, currency) {
                    val raw = when (selectedGateway) {
                        PaymentGateway.STRIPE,
                        PaymentGateway.GOOGLE_PAY,
                        PaymentGateway.APPLE_PAY -> BuildConfig.STRIPE_CHECKOUT_URL
                        PaymentGateway.PAYPAL -> BuildConfig.PAYPAL_CHECKOUT_URL
                        PaymentGateway.MOYASAR,
                        PaymentGateway.TAP -> BuildConfig.REGIONAL_PAY_CHECKOUT_URL
                        PaymentGateway.SELF_FREE -> ""
                    }.trim()
                    val base = raw.takeIf { it.startsWith("https://") }.orEmpty()
                    if (base.isBlank()) "" else {
                        val sep = if (base.contains("?")) "&" else "?"
                        "${base}${sep}orgId=${Uri.encode(organization.id)}&plan=${selectedPlan.name}&currency=${currency.code}"
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (checkoutUrl.isNotBlank()) {
                                "Hosted encrypted checkout ready via ${selectedGateway.displayName} (${currency.formatUsdPrice(selectedPlan.baseUsdMonthly)} ${strings.monthlyPlanLabel})."
                            } else {
                                "Configure STRIPE_CHECKOUT_URL / PAYPAL_CHECKOUT_URL / REGIONAL_PAY_CHECKOUT_URL in AI Studio Secrets for live merchant billing, or activate Starter Free instantly."
                            },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                val priceLabel = currency.formatUsdPrice(selectedPlan.baseUsdMonthly)
                Button(
                    onClick = {
                        if (checkoutUrl.isNotBlank()) {
                            onActivatePlan(
                                organization,
                                selectedPlan,
                                selectedGateway,
                                currency.code,
                                priceLabel,
                                SubscriptionStatus.PENDING_CHECKOUT,
                                checkoutUrl
                            )
                            runCatching {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(checkoutUrl)))
                            }
                            onDismiss()
                        } else {
                            onGatewayMissingNotice(
                                "Set ${selectedGateway.displayName} checkout URL in AI Studio Secrets, or activate Starter Free."
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("launch_gateway_checkout_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Launch, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("${selectedGateway.displayName} • $priceLabel ${strings.monthlyPlanLabel}")
                }

                OutlinedButton(
                    onClick = {
                        val freeLabel = currency.formatUsdPrice(0.0)
                        onActivatePlan(
                            organization,
                            PlanTier.STARTER,
                            PaymentGateway.SELF_FREE,
                            currency.code,
                            freeLabel,
                            SubscriptionStatus.ACTIVE,
                            "self-activated"
                        )
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(strings.selfActivateFree)
                }
            }
        }
    }
}
