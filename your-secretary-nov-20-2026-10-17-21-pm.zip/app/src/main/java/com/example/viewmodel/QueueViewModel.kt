package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.QueueRepository
import com.example.data.SecretaryAiRepository
import com.example.i18n.AppLanguages
import com.example.i18n.SupportedLanguage
import com.example.model.BookingType
import com.example.model.BusinessSector
import com.example.model.BusinessSubscription
import com.example.model.CustomerVisitSummary
import com.example.model.Organization
import com.example.model.PaymentGateway
import com.example.model.PlanTier
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.SubscriptionStatus
import com.example.model.TicketStatus
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class QueueViewModel(
    private val repository: QueueRepository,
    private val aiRepository: SecretaryAiRepository,
    private val currentUserId: String,
    val userDisplayName: String
) : ViewModel() {

    val publicOrganizationsState: StateFlow<UiState<List<Organization>>> =
        repository.observePublicOrganizations()
            .map<List<Organization>, UiState<List<Organization>>> { UiState.Success(it) }
            .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load organizations"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    private val _selectedOwnedOrgId = MutableStateFlow<String?>(null)
    val selectedOwnedOrgId: StateFlow<String?> = _selectedOwnedOrgId.asStateFlow()

    val ownedOrganizationsState: StateFlow<UiState<List<Organization>>> =
        repository.observeOwnedOrganizations(currentUserId)
            .onEach { list ->
                val currentId = _selectedOwnedOrgId.value
                if (currentId == null || list.none { it.id == currentId }) {
                    _selectedOwnedOrgId.value = list.firstOrNull()?.id
                }
            }
            .map<List<Organization>, UiState<List<Organization>>> { UiState.Success(it) }
            .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load your activities"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    private val _inspectingPublicOrgId = MutableStateFlow<String?>(null)

    val publicCountersState: StateFlow<UiState<List<QueueCounter>>> =
        _inspectingPublicOrgId
            .flatMapLatest { orgId ->
                if (orgId.isNullOrBlank()) {
                    flowOf(UiState.Success(emptyList()))
                } else {
                    repository.observePublicCounters(orgId)
                        .map<List<QueueCounter>, UiState<List<QueueCounter>>> { UiState.Success(it) }
                        .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load counters"))) }
                }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Success(emptyList()))

    val ownedCountersState: StateFlow<UiState<List<QueueCounter>>> =
        _selectedOwnedOrgId
            .flatMapLatest { orgId ->
                if (orgId.isNullOrBlank()) {
                    flowOf(UiState.Success(emptyList()))
                } else {
                    repository.observeOwnedCounters(orgId, currentUserId)
                        .map<List<QueueCounter>, UiState<List<QueueCounter>>> { UiState.Success(it) }
                        .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load activity counters"))) }
                }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Success(emptyList()))

    val visitorTicketsState: StateFlow<UiState<List<QueueTicket>>> =
        repository.observeVisitorTickets(currentUserId)
            .map<List<QueueTicket>, UiState<List<QueueTicket>>> { UiState.Success(it) }
            .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load queue tickets"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    val ownerTicketsState: StateFlow<UiState<List<QueueTicket>>> =
        repository.observeOwnerTickets(currentUserId)
            .map<List<QueueTicket>, UiState<List<QueueTicket>>> { UiState.Success(it) }
            .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load visitor queue"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    val subscriptionsState: StateFlow<UiState<List<BusinessSubscription>>> =
        repository.observeSubscriptions(currentUserId)
            .map<List<BusinessSubscription>, UiState<List<BusinessSubscription>>> { UiState.Success(it) }
            .catch { emit(UiState.Error(extractErrorMessage(it, "Failed to load subscriptions"))) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    val activeOrgCustomers: StateFlow<List<CustomerVisitSummary>> =
        combine(ownerTicketsState, _selectedOwnedOrgId) { ticketsState, orgId ->
            val tickets = (ticketsState as? UiState.Success)?.data.orEmpty()
                .filter { orgId == null || it.orgId == orgId }
            tickets.groupBy { it.visitorId }
                .values
                .map { group ->
                    val latest = group.maxByOrNull { it.createdAt?.seconds ?: 0L } ?: group.first()
                    CustomerVisitSummary(
                        visitorId = latest.visitorId,
                        visitorName = latest.visitorName,
                        visitorPhone = group.firstOrNull { it.visitorPhone.isNotBlank() }?.visitorPhone.orEmpty(),
                        totalVisits = group.size,
                        activeTickets = group.count { it.resolvedStatus().isActiveQueue() },
                        completedVisits = group.count { it.resolvedStatus() == TicketStatus.COMPLETED },
                        lastTicketCode = latest.ticketCode,
                        lastOrgName = latest.orgName
                    )
                }
                .sortedByDescending { it.activeTickets * 1000 + it.totalVisits }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), emptyList())

    private val _aiMatchedOrgIds = MutableStateFlow<List<String>?>(null)
    val aiMatchedOrgIds: StateFlow<List<String>?> = _aiMatchedOrgIds.asStateFlow()

    private val _isRunningAiSearch = MutableStateFlow(false)
    val isRunningAiSearch: StateFlow<Boolean> = _isRunningAiSearch.asStateFlow()

    private val _isSubmittingBooking = MutableStateFlow(false)
    val isSubmittingBooking: StateFlow<Boolean> = _isSubmittingBooking.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    private var activeAppLanguage: SupportedLanguage = AppLanguages.defaultDeviceLanguage()

    fun updateAppLanguage(language: SupportedLanguage) {
        activeAppLanguage = language
    }

    fun selectPublicOrg(orgId: String?) {
        _inspectingPublicOrgId.value = orgId
    }

    fun selectOwnedOrg(orgId: String) {
        _selectedOwnedOrgId.value = orgId
    }

    fun clearAiSmartSearch() {
        _aiMatchedOrgIds.value = null
    }

    fun runAiSmartSearch(query: String, organizations: List<Organization>) {
        if (query.isBlank() || organizations.isEmpty()) {
            _aiMatchedOrgIds.value = null
            return
        }
        viewModelScope.launch {
            _isRunningAiSearch.value = true
            try {
                val ids = aiRepository.smartMatchOrganizations(
                    query = query,
                    organizations = organizations,
                    appLanguage = activeAppLanguage
                )
                _aiMatchedOrgIds.value = ids
            } catch (e: Exception) {
                Log.w(TAG, "AI smart search failed", e)
                _snackbarMessages.emit(e.localizedMessage ?: "AI smart search unavailable")
            } finally {
                _isRunningAiSearch.value = false
            }
        }
    }

    fun saveOrganization(
        existingId: String?,
        name: String,
        sector: BusinessSector,
        profession: String,
        description: String,
        city: String,
        address: String,
        deskPhone: String,
        workingHours: String,
        currencyCode: String,
        maxDailyCapacity: Int,
        acceptingBookings: Boolean,
        listedPublicly: Boolean
    ) {
        viewModelScope.launch {
            val res = repository.saveOrganization(
                existingId = existingId,
                ownerName = userDisplayName,
                name = name,
                sector = sector,
                profession = profession,
                description = description,
                city = city,
                address = address,
                deskPhone = deskPhone,
                workingHours = workingHours,
                currencyCode = currencyCode,
                maxDailyCapacity = maxDailyCapacity,
                acceptingBookings = acceptingBookings,
                listedPublicly = listedPublicly
            )
            res.fold(
                onSuccess = { newId ->
                    _selectedOwnedOrgId.value = newId
                    _snackbarMessages.emit("Activity saved to cloud")
                },
                onFailure = { err ->
                    _snackbarMessages.emit(err.localizedMessage ?: "Unable to save activity")
                }
            )
        }
    }

    fun saveCounter(
        org: Organization,
        existingCounterId: String?,
        name: String,
        serviceTrack: String,
        prefix: String,
        avgServiceMinutes: Int,
        maxWaitingLimit: Int,
        open: Boolean,
        acceptingQueue: Boolean,
        acceptingAppointments: Boolean
    ) {
        viewModelScope.launch {
            val res = repository.saveCounter(
                org = org,
                existingCounterId = existingCounterId,
                name = name,
                serviceTrack = serviceTrack,
                prefix = prefix,
                avgServiceMinutes = avgServiceMinutes,
                maxWaitingLimit = maxWaitingLimit,
                open = open,
                acceptingQueue = acceptingQueue,
                acceptingAppointments = acceptingAppointments
            )
            res.fold(
                onSuccess = { _snackbarMessages.emit("Counter saved") },
                onFailure = { _snackbarMessages.emit(it.localizedMessage ?: "Unable to save counter") }
            )
        }
    }

    fun toggleCounterOpen(orgId: String, counterId: String, open: Boolean) {
        viewModelScope.launch {
            repository.toggleCounterOpen(orgId, counterId, open).onFailure {
                _snackbarMessages.emit(it.localizedMessage ?: "Unable to update counter status")
            }
        }
    }

    fun resetCounterQueue(orgId: String, counterId: String) {
        viewModelScope.launch {
            repository.resetCounterQueue(orgId, counterId).fold(
                onSuccess = { _snackbarMessages.emit("Queue numbers reset for today") },
                onFailure = { _snackbarMessages.emit(it.localizedMessage ?: "Unable to reset counter") }
            )
        }
    }

    fun bookQueueTicket(
        org: Organization,
        counter: QueueCounter,
        visitorName: String,
        visitorPhone: String,
        visitorNotes: String,
        bookingType: BookingType,
        dateKey: String,
        slotLabel: String,
        onBooked: (QueueTicket) -> Unit
    ) {
        viewModelScope.launch {
            _isSubmittingBooking.value = true
            try {
                val res = repository.issueQueueTicket(
                    org = org,
                    counter = counter,
                    visitorName = visitorName,
                    visitorPhone = visitorPhone,
                    visitorNotes = visitorNotes,
                    bookingType = bookingType,
                    dateKey = dateKey,
                    slotLabel = slotLabel
                )
                res.fold(
                    onSuccess = { ticket ->
                        _snackbarMessages.emit("${ticket.ticketCode} • $0 booking fee")
                        onBooked(ticket)
                    },
                    onFailure = { err ->
                        _snackbarMessages.emit(err.localizedMessage ?: "Booking failed")
                    }
                )
            } finally {
                _isSubmittingBooking.value = false
            }
        }
    }

    fun cancelVisitorTicket(ticket: QueueTicket) {
        viewModelScope.launch {
            repository.cancelVisitorTicket(ticket).fold(
                onSuccess = { _snackbarMessages.emit("Ticket ${ticket.ticketCode} cancelled") },
                onFailure = { _snackbarMessages.emit(it.localizedMessage ?: "Unable to cancel ticket") }
            )
        }
    }

    fun callNextForCounter(
        counter: QueueCounter,
        ownerTickets: List<QueueTicket>
    ) {
        viewModelScope.launch {
            val counterTickets = ownerTickets.filter { it.counterId == counter.id }
            val activeServing = counterTickets.firstOrNull {
                it.resolvedStatus() == TicketStatus.CALLED || it.resolvedStatus() == TicketStatus.SERVING
            }
            val waiting = counterTickets.filter { it.resolvedStatus() == TicketStatus.WAITING }
            repository.callNextForCounter(counter, waiting, activeServing).fold(
                onSuccess = { called ->
                    val code = called?.ticketCode ?: counter.nextIssuedPreviewCode()
                    _snackbarMessages.emit("Now calling $code")
                },
                onFailure = { _snackbarMessages.emit(it.localizedMessage ?: "Unable to call next number") }
            )
        }
    }

    fun updateTicketStatus(ticket: QueueTicket, status: TicketStatus) {
        viewModelScope.launch {
            repository.updateTicketStatusByOwner(ticket, status).onFailure {
                _snackbarMessages.emit(it.localizedMessage ?: "Unable to update ticket status")
            }
        }
    }

    fun activateSubscription(
        org: Organization,
        planTier: PlanTier,
        gateway: PaymentGateway,
        currencyCode: String,
        monthlyPriceDisplay: String,
        status: SubscriptionStatus,
        externalRef: String = ""
    ) {
        viewModelScope.launch {
            repository.activateOwnerSubscription(
                org = org,
                planTier = planTier,
                gateway = gateway,
                currencyCode = currencyCode,
                monthlyPriceDisplay = monthlyPriceDisplay,
                status = status,
                externalRef = externalRef
            ).fold(
                onSuccess = {
                    val msg = if (status == SubscriptionStatus.ACTIVE) {
                        "${planTier.name} plan activated for ${org.name}"
                    } else {
                        "Checkout initiated via ${gateway.displayName}"
                    }
                    _snackbarMessages.emit(msg)
                },
                onFailure = {
                    _snackbarMessages.emit(it.localizedMessage ?: "Subscription update failed")
                }
            )
        }
    }

    private fun extractErrorMessage(error: Throwable, fallback: String): String {
        val fsErr = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fsErr == null && error is CancellationException) throw error
        val root = fsErr ?: error
        Log.w(TAG, fallback, root)
        return root.localizedMessage ?: fallback
    }

    private companion object {
        const val TAG = "QueueViewModel"
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
