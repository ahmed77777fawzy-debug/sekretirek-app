package com.example.model

import androidx.annotation.Keep
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CategoryCallColor
import com.example.ui.theme.CategoryFocusColor
import com.example.ui.theme.CategoryMeetingColor
import com.example.ui.theme.CategoryPersonalColor
import com.example.ui.theme.CategoryTravelColor
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AppointmentCategory(val label: String, val accentColor: Color) {
    MEETING("Meeting", CategoryMeetingColor),
    FOCUS("Focus", CategoryFocusColor),
    CALL("Call", CategoryCallColor),
    PERSONAL("Personal", CategoryPersonalColor),
    TRAVEL("Travel", CategoryTravelColor);

    companion object {
        fun fromRaw(raw: String?): AppointmentCategory =
            entries.firstOrNull { it.name == raw } ?: MEETING
    }
}

enum class TaskPriority(val label: String) {
    HIGH("High"),
    NORMAL("Normal"),
    LOW("Low");

    companion object {
        fun fromRaw(raw: String?): TaskPriority =
            entries.firstOrNull { it.name == raw } ?: NORMAL
    }
}

enum class ScheduleViewMode(val label: String) {
    DAY("Day"),
    WEEK("Week"),
    MONTH("Month")
}

@Keep
@IgnoreExtraProperties
data class Appointment(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val dateKey: String = "",
    val startMinute: Long = 540L,
    val endMinute: Long = 600L,
    val allDay: Boolean = false,
    val category: String = AppointmentCategory.MEETING.name,
    val location: String = "",
    val attendees: String = "",
    val linkedContactIds: List<String> = emptyList(),
    val notes: String = "",
    val reminderEnabled: Boolean = false,
    val reminderMinutesBefore: Long = 15L,
    val completed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedCategory(): AppointmentCategory = AppointmentCategory.fromRaw(category)
}

@Keep
@IgnoreExtraProperties
data class SecretaryTask(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val details: String = "",
    val dueDateKey: String = "",
    val linkedAppointmentId: String = "",
    val linkedAppointmentTitle: String = "",
    val priority: String = TaskPriority.NORMAL.name,
    val completed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedPriority(): TaskPriority = TaskPriority.fromRaw(priority)
    val isLinkedToAgenda: Boolean
        get() = dueDateKey.isNotBlank() || linkedAppointmentId.isNotBlank()
}

@Keep
@IgnoreExtraProperties
data class ExecutiveMemo(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val body: String = "",
    val pinned: Boolean = false,
    val aiDraft: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class ContactGroup(val label: String) {
    COLLEAGUE("Colleague"),
    CLIENT("Client"),
    LEADERSHIP("Leadership"),
    PERSONAL("Personal"),
    VENDOR("Vendor");

    companion object {
        fun fromRaw(raw: String?): ContactGroup =
            entries.firstOrNull { it.name == raw } ?: COLLEAGUE
    }
}

@Keep
@IgnoreExtraProperties
data class SecretaryContact(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val role: String = "",
    val company: String = "",
    val email: String = "",
    val phone: String = "",
    val location: String = "",
    val category: String = ContactGroup.COLLEAGUE.name,
    val notes: String = "",
    val favorite: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedGroup(): ContactGroup = ContactGroup.fromRaw(category)
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface AiStreamState {
    data object Idle : AiStreamState
    data object Loading : AiStreamState
    data class Streaming(val text: String) : AiStreamState
    data class Success(val text: String) : AiStreamState
    data class Error(val message: String) : AiStreamState
}

enum class UrgencyLevel(val label: String) {
    CRITICAL("Critical"),
    HIGH("High"),
    FOCUS("Focus");

    companion object {
        fun fromRaw(raw: String?): UrgencyLevel =
            entries.firstOrNull { it.name == raw?.uppercase() } ?: HIGH
    }
}

data class PrioritizedBriefingItem(
    val rank: Int,
    val itemType: String,
    val referenceId: String,
    val title: String,
    val urgencyLevel: UrgencyLevel,
    val timeHint: String,
    val rationale: String
)

data class SmartBriefingContent(
    val executiveSummary: String,
    val urgentItems: List<PrioritizedBriefingItem>,
    val secretaryTip: String
)

sealed interface SmartBriefingState {
    data object Idle : SmartBriefingState
    data object Loading : SmartBriefingState
    data class Success(val content: SmartBriefingContent) : SmartBriefingState
    data class Error(val message: String) : SmartBriefingState
}

enum class ProposalKind {
    APPOINTMENT,
    TASK,
    MEMO
}

data class AiActionProposal(
    val kind: ProposalKind,
    val title: String,
    val dateKey: String,
    val startMinute: Int,
    val endMinute: Int,
    val allDay: Boolean,
    val category: AppointmentCategory,
    val location: String,
    val attendees: String,
    val notes: String,
    val reminderEnabled: Boolean,
    val reminderMinutesBefore: Int,
    val priority: TaskPriority
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val translatedText: String? = null,
    val translatedLanguageName: String? = null,
    val isTranslating: Boolean = false,
    val showTranslation: Boolean = true
)

data class ConversationTurn(
    val id: String,
    val speakerLabel: String,
    val sourceLanguageName: String,
    val originalText: String,
    val targetLanguageName: String,
    val translatedText: String
)
