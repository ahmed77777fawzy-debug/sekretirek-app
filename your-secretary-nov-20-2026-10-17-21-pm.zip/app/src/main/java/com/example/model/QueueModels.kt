package com.example.model

import androidx.annotation.Keep
import com.example.i18n.AppStrings
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class BusinessSector(val code: String) {
    COMPANY("COMPANY"),
    CLINIC("CLINIC"),
    HOSPITAL("HOSPITAL"),
    FACTORY("FACTORY"),
    INTERVIEWS("INTERVIEWS"),
    GOVERNMENT("GOVERNMENT"),
    FINANCE("FINANCE"),
    LEGAL_ENGINEERING("LEGAL_ENGINEERING"),
    EDUCATION("EDUCATION"),
    SALON_WELLNESS("SALON_WELLNESS"),
    AUTO_SERVICE("AUTO_SERVICE"),
    OTHER("OTHER");

    fun label(strings: AppStrings): String = when (this) {
        COMPANY -> strings.sectorCompany
        CLINIC -> strings.sectorClinic
        HOSPITAL -> strings.sectorHospital
        FACTORY -> strings.sectorFactory
        INTERVIEWS -> strings.sectorInterviews
        GOVERNMENT -> strings.sectorGovernment
        FINANCE -> strings.sectorFinance
        LEGAL_ENGINEERING -> strings.sectorLegalEngineering
        EDUCATION -> strings.sectorEducation
        SALON_WELLNESS -> strings.sectorSalonWellness
        AUTO_SERVICE -> strings.sectorAutoService
        OTHER -> strings.sectorOther
    }

    companion object {
        fun fromRaw(raw: String?): BusinessSector =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: COMPANY
    }
}

enum class BookingType {
    WALK_IN,
    APPOINTMENT;

    companion object {
        fun fromRaw(raw: String?): BookingType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: WALK_IN
    }
}

enum class TicketStatus {
    WAITING,
    CALLED,
    SERVING,
    COMPLETED,
    CANCELLED,
    NO_SHOW;

    fun isTerminal(): Boolean = this == COMPLETED || this == CANCELLED || this == NO_SHOW

    fun isActiveQueue(): Boolean = this == WAITING || this == CALLED || this == SERVING

    companion object {
        fun fromRaw(raw: String?): TicketStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: WAITING
    }
}

enum class PlanTier(val baseUsdMonthly: Double) {
    STARTER(0.0),
    PRO(19.0),
    ENTERPRISE(49.0);

    companion object {
        fun fromRaw(raw: String?): PlanTier =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: STARTER
    }
}

enum class PaymentGateway(val displayName: String) {
    SELF_FREE("Self-Service Free"),
    STRIPE("Stripe Global"),
    PAYPAL("PayPal"),
    GOOGLE_PAY("Google Pay"),
    APPLE_PAY("Apple Pay"),
    MOYASAR("Moyasar / Mada"),
    TAP("Tap Payments");

    companion object {
        fun fromRaw(raw: String?): PaymentGateway =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: SELF_FREE
    }
}

enum class SubscriptionStatus {
    ACTIVE,
    PENDING_CHECKOUT,
    CANCELLED;

    companion object {
        fun fromRaw(raw: String?): SubscriptionStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: ACTIVE
    }
}

@Keep
@IgnoreExtraProperties
data class Organization(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val ownerName: String = "",
    val name: String = "",
    val sector: String = BusinessSector.COMPANY.name,
    val profession: String = "",
    val description: String = "",
    val city: String = "",
    val address: String = "",
    val deskPhone: String = "",
    val workingHours: String = "09:00 - 18:00",
    val currencyCode: String = "USD",
    val planTier: String = PlanTier.STARTER.name,
    val subscriptionActive: Boolean = true,
    val acceptingBookings: Boolean = true,
    val listedPublicly: Boolean = true,
    val maxDailyCapacity: Int = 150,
    val activeCounterCount: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedSector(): BusinessSector = BusinessSector.fromRaw(sector)
    fun resolvedPlan(): PlanTier = PlanTier.fromRaw(planTier)
}

@Keep
@IgnoreExtraProperties
data class QueueCounter(
    @DocumentId val id: String = "",
    val orgId: String = "",
    val ownerId: String = "",
    val listedPublicly: Boolean = true,
    val name: String = "",
    val serviceTrack: String = "",
    val prefix: String = "A",
    val avgServiceMinutes: Int = 10,
    val maxWaitingLimit: Int = 30,
    val open: Boolean = true,
    val acceptingQueue: Boolean = true,
    val acceptingAppointments: Boolean = true,
    val currentServingNumber: Int = 0,
    val lastIssuedNumber: Int = 0,
    val waitingCount: Int = 0,
    val dateKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun currentServingCode(): String = formatTicketCode(prefix, currentServingNumber)
    fun nextIssuedPreviewCode(): String = formatTicketCode(prefix, lastIssuedNumber + 1)
    fun estimatedWaitMinutes(): Int = (waitingCount.coerceAtLeast(0)) * avgServiceMinutes.coerceAtLeast(1)
    fun atCapacity(): Boolean = waitingCount >= maxWaitingLimit
}

@Keep
@IgnoreExtraProperties
data class QueueTicket(
    @DocumentId val id: String = "",
    val visitorId: String = "",
    val visitorName: String = "",
    val visitorPhone: String = "",
    val visitorNotes: String = "",
    val orgId: String = "",
    val orgName: String = "",
    val orgSector: String = BusinessSector.COMPANY.name,
    val orgOwnerId: String = "",
    val counterId: String = "",
    val counterName: String = "",
    val bookingType: String = BookingType.WALK_IN.name,
    val dateKey: String = "",
    val slotLabel: String = "",
    val ticketNumber: Int = 1,
    val ticketCode: String = "A-001",
    val bookingFeePaid: Int = 0,
    val status: String = TicketStatus.WAITING.name,
    val estimatedWaitMinutes: Int = 10,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedBookingType(): BookingType = BookingType.fromRaw(bookingType)
    fun resolvedStatus(): TicketStatus = TicketStatus.fromRaw(status)
    fun resolvedSector(): BusinessSector = BusinessSector.fromRaw(orgSector)
}

@Keep
@IgnoreExtraProperties
data class BusinessSubscription(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orgId: String = "",
    val orgName: String = "",
    val planTier: String = PlanTier.STARTER.name,
    val gateway: String = PaymentGateway.SELF_FREE.name,
    val currencyCode: String = "USD",
    val monthlyPriceDisplay: String = "$0.00",
    val status: String = SubscriptionStatus.ACTIVE.name,
    val billingCycleDays: Int = 30,
    val activatedFromPhone: Boolean = true,
    val externalRef: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun resolvedPlan(): PlanTier = PlanTier.fromRaw(planTier)
    fun resolvedGateway(): PaymentGateway = PaymentGateway.fromRaw(gateway)
    fun resolvedStatus(): SubscriptionStatus = SubscriptionStatus.fromRaw(status)
}

data class CustomerVisitSummary(
    val visitorId: String,
    val visitorName: String,
    val visitorPhone: String,
    val totalVisits: Int,
    val activeTickets: Int,
    val completedVisits: Int,
    val lastTicketCode: String,
    val lastOrgName: String
)

fun formatTicketCode(prefix: String, number: Int): String {
    val cleanPrefix = prefix.trim().uppercase().ifBlank { "A" }.take(3)
    return if (number <= 0) "$cleanPrefix-000" else "$cleanPrefix-${number.toString().padStart(3, '0')}"
}
