package com.example.data

import android.content.Context
import com.example.R
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.BookingType
import com.example.model.BusinessSector
import com.example.model.BusinessSubscription
import com.example.model.Organization
import com.example.model.PaymentGateway
import com.example.model.PlanTier
import com.example.model.QueueCounter
import com.example.model.QueueTicket
import com.example.model.SubscriptionStatus
import com.example.model.TicketStatus
import com.example.model.formatTicketCode
import com.example.util.DateUtils
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class QueueRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observePublicOrganizations(): Flow<List<Organization>> = flow {
        val uid = requireUserId()
        val path = "organizations"
        emitAll(
            db.collection("organizations")
                .whereEqualTo("listedPublicly", true)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Organization::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareByDescending<Organization> { it.acceptingBookings && it.subscriptionActive }
                            .thenByDescending { it.activeCounterCount }
                            .thenBy { it.name.lowercase() }
                    )
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeOwnedOrganizations(userId: String): Flow<List<Organization>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "organizations"
        emitAll(
            db.collection("organizations")
                .whereEqualTo("ownerId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Organization::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.name.lowercase() }
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observePublicCounters(orgId: String): Flow<List<QueueCounter>> = flow {
        val uid = requireUserId()
        require(orgId.isNotBlank()) { "Organization ID cannot be blank" }
        val path = "organizations/$orgId/counters"
        emitAll(
            db.collection("organizations").document(orgId)
                .collection("counters")
                .whereEqualTo("listedPublicly", true)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        QueueCounter::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.prefix + it.name.lowercase() }
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeOwnedCounters(orgId: String, ownerId: String): Flow<List<QueueCounter>> = flow {
        val uid = requireUserId()
        require(uid == ownerId) { "Signed-in user mismatch" }
        require(orgId.isNotBlank()) { "Organization ID cannot be blank" }
        val path = "organizations/$orgId/counters"
        emitAll(
            db.collection("organizations").document(orgId)
                .collection("counters")
                .whereEqualTo("ownerId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        QueueCounter::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.prefix + it.name.lowercase() }
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeVisitorTickets(userId: String): Flow<List<QueueTicket>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "queueTickets"
        emitAll(
            db.collection("queueTickets")
                .whereEqualTo("visitorId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        QueueTicket::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareBy<QueueTicket> { !it.resolvedStatus().isActiveQueue() }
                            .thenByDescending { it.updatedAt?.seconds ?: 0L }
                    )
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeOwnerTickets(userId: String): Flow<List<QueueTicket>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "queueTickets"
        emitAll(
            db.collection("queueTickets")
                .whereEqualTo("orgOwnerId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        QueueTicket::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareBy<QueueTicket> { !it.resolvedStatus().isActiveQueue() }
                            .thenBy { it.ticketNumber }
                    )
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeSubscriptions(userId: String): Flow<List<BusinessSubscription>> = flow {
        val uid = requireUserId()
        require(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/subscriptions"
        emitAll(
            db.collection("users").document(uid)
                .collection("subscriptions")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        BusinessSubscription::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val fsErr = extractFirestoreException(error)
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveOrganization(
        existingId: String?,
        ownerName: String,
        name: String,
        sector: BusinessSector,
        profession: String,
        description: String,
        city: String,
        address: String,
        deskPhone: String,
        workingHours: String,
        currencyCode: String,
        maxDailyCapacity: Int,
        acceptingBookings: Boolean,
        listedPublicly: Boolean
    ): Result<String> {
        val cleanName = name.trim().take(120)
        val cleanProf = profession.trim().take(120)
        if (cleanName.isBlank() || cleanProf.isBlank()) {
            return Result.failure(IllegalArgumentException("Activity name and profession are required."))
        }
        val cleanOwnerName = ownerName.trim().ifBlank { "Business Owner" }.take(120)
        val cleanCapacity = maxDailyCapacity.coerceIn(1, 10000)
        val cleanCurrency = currencyCode.trim().uppercase().take(6).ifBlank { "USD" }
        val op = if (existingId.isNullOrBlank()) OperationType.CREATE else OperationType.UPDATE
        var path = "organizations"

        return try {
            val uid = requireUserId()
            val col = db.collection("organizations")
            val docRef = if (existingId.isNullOrBlank()) col.document() else col.document(existingId)
            path = docRef.path

            if (existingId.isNullOrBlank()) {
                val orgPayload = mapOf(
                    "ownerId" to uid,
                    "ownerName" to cleanOwnerName,
                    "name" to cleanName,
                    "sector" to sector.name,
                    "profession" to cleanProf,
                    "description" to description.trim().take(600),
                    "city" to city.trim().take(100),
                    "address" to address.trim().take(200),
                    "deskPhone" to deskPhone.trim().take(40),
                    "workingHours" to workingHours.trim().take(120),
                    "currencyCode" to cleanCurrency,
                    "planTier" to PlanTier.STARTER.name,
                    "subscriptionActive" to true,
                    "acceptingBookings" to acceptingBookings,
                    "listedPublicly" to listedPublicly,
                    "maxDailyCapacity" to cleanCapacity.toLong(),
                    "activeCounterCount" to 1L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(orgPayload).await()

                // Provision initial default reception counter so the activity is immediately bookable
                val defaultCounter = docRef.collection("counters").document()
                defaultCounter.set(
                    mapOf(
                        "orgId" to docRef.id,
                        "ownerId" to uid,
                        "listedPublicly" to listedPublicly,
                        "name" to "Reception Desk A",
                        "serviceTrack" to cleanProf.take(100),
                        "prefix" to "A",
                        "avgServiceMinutes" to 10L,
                        "maxWaitingLimit" to 40L,
                        "open" to true,
                        "acceptingQueue" to true,
                        "acceptingAppointments" to true,
                        "currentServingNumber" to 0L,
                        "lastIssuedNumber" to 0L,
                        "waitingCount" to 0L,
                        "dateKey" to DateUtils.todayDateKey(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "ownerName" to cleanOwnerName,
                        "name" to cleanName,
                        "sector" to sector.name,
                        "profession" to cleanProf,
                        "description" to description.trim().take(600),
                        "city" to city.trim().take(100),
                        "address" to address.trim().take(200),
                        "deskPhone" to deskPhone.trim().take(40),
                        "workingHours" to workingHours.trim().take(120),
                        "currencyCode" to cleanCurrency,
                        "maxDailyCapacity" to cleanCapacity.toLong(),
                        "acceptingBookings" to acceptingBookings,
                        "listedPublicly" to listedPublicly,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()

                // Keep counters' listedPublicly aligned with organization visibility
                val countersSnap = docRef.collection("counters")
                    .whereEqualTo("ownerId", uid)
                    .get()
                    .await()
                if (!countersSnap.isEmpty) {
                    val batch = db.batch()
                    countersSnap.documents.forEach { counterDoc ->
                        batch.update(
                            counterDoc.reference,
                            mapOf(
                                "listedPublicly" to listedPublicly,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    batch.commit().await()
                }
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    suspend fun saveCounter(
        org: Organization,
        existingCounterId: String?,
        name: String,
        serviceTrack: String,
        prefix: String,
        avgServiceMinutes: Int,
        maxWaitingLimit: Int,
        open: Boolean,
        acceptingQueue: Boolean,
        acceptingAppointments: Boolean
    ): Result<String> {
        val cleanName = name.trim().take(100)
        val cleanTrack = serviceTrack.trim().take(100)
        val cleanPrefix = prefix.trim().uppercase().filter { it.isLetterOrDigit() }.take(3).ifBlank { "A" }
        if (cleanName.isBlank() || cleanTrack.isBlank()) {
            return Result.failure(IllegalArgumentException("Counter name and service track are required."))
        }
        val op = if (existingCounterId.isNullOrBlank()) OperationType.CREATE else OperationType.UPDATE
        var path = "organizations/${org.id}/counters"
        return try {
            val uid = requireUserId()
            require(org.ownerId == uid) { "Only the organization owner can manage counters." }
            val countersCol = db.collection("organizations").document(org.id).collection("counters")
            val docRef = if (existingCounterId.isNullOrBlank()) countersCol.document() else countersCol.document(existingCounterId)
            path = docRef.path

            if (existingCounterId.isNullOrBlank()) {
                docRef.set(
                    mapOf(
                        "orgId" to org.id,
                        "ownerId" to uid,
                        "listedPublicly" to org.listedPublicly,
                        "name" to cleanName,
                        "serviceTrack" to cleanTrack,
                        "prefix" to cleanPrefix,
                        "avgServiceMinutes" to avgServiceMinutes.coerceIn(1, 240).toLong(),
                        "maxWaitingLimit" to maxWaitingLimit.coerceIn(1, 2000).toLong(),
                        "open" to open,
                        "acceptingQueue" to acceptingQueue,
                        "acceptingAppointments" to acceptingAppointments,
                        "currentServingNumber" to 0L,
                        "lastIssuedNumber" to 0L,
                        "waitingCount" to 0L,
                        "dateKey" to DateUtils.todayDateKey(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                syncOrgActiveCounterCount(org.id, uid)
            } else {
                docRef.update(
                    mapOf(
                        "listedPublicly" to org.listedPublicly,
                        "name" to cleanName,
                        "serviceTrack" to cleanTrack,
                        "prefix" to cleanPrefix,
                        "avgServiceMinutes" to avgServiceMinutes.coerceIn(1, 240).toLong(),
                        "maxWaitingLimit" to maxWaitingLimit.coerceIn(1, 2000).toLong(),
                        "open" to open,
                        "acceptingQueue" to acceptingQueue,
                        "acceptingAppointments" to acceptingAppointments,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    suspend fun toggleCounterOpen(orgId: String, counterId: String, open: Boolean): Result<Unit> {
        val path = "organizations/$orgId/counters/$counterId"
        return try {
            requireUserId()
            db.collection("organizations").document(orgId)
                .collection("counters").document(counterId)
                .update(
                    mapOf(
                        "open" to open,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun resetCounterQueue(orgId: String, counterId: String): Result<Unit> {
        val path = "organizations/$orgId/counters/$counterId"
        return try {
            requireUserId()
            db.collection("organizations").document(orgId)
                .collection("counters").document(counterId)
                .update(
                    mapOf(
                        "currentServingNumber" to 0L,
                        "lastIssuedNumber" to 0L,
                        "waitingCount" to 0L,
                        "dateKey" to DateUtils.todayDateKey(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun issueQueueTicket(
        org: Organization,
        counter: QueueCounter,
        visitorName: String,
        visitorPhone: String,
        visitorNotes: String,
        bookingType: BookingType,
        dateKey: String,
        slotLabel: String
    ): Result<QueueTicket> {
        val cleanVisitor = visitorName.trim().ifBlank { "Visitor" }.take(120)
        val cleanDateKey = if (DateUtils.isValidDateKey(dateKey)) dateKey else DateUtils.todayDateKey()
        val counterRef = db.collection("organizations").document(org.id)
            .collection("counters").document(counter.id)
        val ticketRef = db.collection("queueTickets").document()

        return try {
            val uid = requireUserId()
            val issuedTicket = db.runTransaction { tx ->
                val snap = tx.get(counterRef)
                val isOpen = snap.getBoolean("open") ?: false
                val acceptsQueue = snap.getBoolean("acceptingQueue") ?: false
                val maxLimit = (snap.getLong("maxWaitingLimit") ?: 40L).toInt()
                val waiting = (snap.getLong("waitingCount") ?: 0L).toInt()
                val currentDateKey = snap.getString("dateKey") ?: cleanDateKey
                val prevLast = (snap.getLong("lastIssuedNumber") ?: 0L).toInt()
                val avgMins = (snap.getLong("avgServiceMinutes") ?: 10L).toInt()
                val prefix = snap.getString("prefix") ?: counter.prefix

                if (!isOpen || !acceptsQueue) {
                    throw IllegalStateException("This counter is currently paused.")
                }
                if (waiting >= maxLimit) {
                    throw IllegalStateException("Counter waiting capacity ($maxLimit) reached to prevent crowding.")
                }

                val targetDateKey = if (bookingType == BookingType.WALK_IN) DateUtils.todayDateKey() else cleanDateKey
                val nextNum = if (currentDateKey == targetDateKey) prevLast + 1 else 1
                val nextWaiting = waiting + 1
                val ticketCode = formatTicketCode(prefix, nextNum)
                val estMinutes = waiting * avgMins

                tx.update(
                    counterRef,
                    mapOf(
                        "lastIssuedNumber" to nextNum.toLong(),
                        "waitingCount" to nextWaiting.toLong(),
                        "dateKey" to targetDateKey,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                val cleanSlot = if (bookingType == BookingType.WALK_IN) "Walk-In" else slotLabel.trim().take(40)
                tx.set(
                    ticketRef,
                    mapOf(
                        "visitorId" to uid,
                        "visitorName" to cleanVisitor,
                        "visitorPhone" to visitorPhone.trim().take(40),
                        "visitorNotes" to visitorNotes.trim().take(400),
                        "orgId" to org.id,
                        "orgName" to org.name.take(120),
                        "orgSector" to org.sector,
                        "orgOwnerId" to org.ownerId,
                        "counterId" to counter.id,
                        "counterName" to counter.name.take(100),
                        "bookingType" to bookingType.name,
                        "dateKey" to targetDateKey,
                        "slotLabel" to cleanSlot,
                        "ticketNumber" to nextNum.toLong(),
                        "ticketCode" to ticketCode,
                        "bookingFeePaid" to 0L,
                        "status" to TicketStatus.WAITING.name,
                        "estimatedWaitMinutes" to estMinutes.toLong(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                QueueTicket(
                    id = ticketRef.id,
                    visitorId = uid,
                    visitorName = cleanVisitor,
                    visitorPhone = visitorPhone.trim().take(40),
                    visitorNotes = visitorNotes.trim().take(400),
                    orgId = org.id,
                    orgName = org.name,
                    orgSector = org.sector,
                    orgOwnerId = org.ownerId,
                    counterId = counter.id,
                    counterName = counter.name,
                    bookingType = bookingType.name,
                    dateKey = targetDateKey,
                    slotLabel = cleanSlot,
                    ticketNumber = nextNum,
                    ticketCode = ticketCode,
                    bookingFeePaid = 0,
                    status = TicketStatus.WAITING.name,
                    estimatedWaitMinutes = estMinutes
                )
            }.await()
            Result.success(issuedTicket)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ticketRef.path)
            Result.failure(e)
        }
    }

    suspend fun cancelVisitorTicket(ticket: QueueTicket): Result<Unit> {
        val ticketRef = db.collection("queueTickets").document(ticket.id)
        val counterRef = db.collection("organizations").document(ticket.orgId)
            .collection("counters").document(ticket.counterId)
        return try {
            requireUserId()
            db.runTransaction { tx ->
                val counterSnap = tx.get(counterRef)
                val waiting = (counterSnap.getLong("waitingCount") ?: 0L).toInt()
                tx.update(
                    ticketRef,
                    mapOf(
                        "status" to TicketStatus.CANCELLED.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (waiting > 0 && !ticket.resolvedStatus().isTerminal()) {
                    tx.update(
                        counterRef,
                        mapOf(
                            "waitingCount" to (waiting - 1).toLong(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ticketRef.path)
            Result.failure(e)
        }
    }

    suspend fun callNextForCounter(
        counter: QueueCounter,
        waitingTicketsForCounter: List<QueueTicket>,
        activeServingTicket: QueueTicket?
    ): Result<QueueTicket?> {
        val counterRef = db.collection("organizations").document(counter.orgId)
            .collection("counters").document(counter.id)
        return try {
            requireUserId()
            val nextTicket = waitingTicketsForCounter
                .filter { it.resolvedStatus() == TicketStatus.WAITING }
                .minByOrNull { it.ticketNumber }

            db.runTransaction { tx ->
                val snap = tx.get(counterRef)
                val currentServing = (snap.getLong("currentServingNumber") ?: 0L).toInt()
                val waiting = (snap.getLong("waitingCount") ?: 0L).toInt()

                if (activeServingTicket != null && !activeServingTicket.resolvedStatus().isTerminal()) {
                    tx.update(
                        db.collection("queueTickets").document(activeServingTicket.id),
                        mapOf(
                            "status" to TicketStatus.COMPLETED.name,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                if (nextTicket != null) {
                    tx.update(
                        db.collection("queueTickets").document(nextTicket.id),
                        mapOf(
                            "status" to TicketStatus.CALLED.name,
                            "estimatedWaitMinutes" to 0L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    tx.update(
                        counterRef,
                        mapOf(
                            "currentServingNumber" to nextTicket.ticketNumber.toLong(),
                            "waitingCount" to (waiting - 1).coerceAtLeast(0).toLong(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    tx.update(
                        counterRef,
                        mapOf(
                            "currentServingNumber" to (currentServing + 1).toLong(),
                            "waitingCount" to (waiting - 1).coerceAtLeast(0).toLong(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
            Result.success(nextTicket)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, counterRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateTicketStatusByOwner(
        ticket: QueueTicket,
        newStatus: TicketStatus
    ): Result<Unit> {
        val ticketRef = db.collection("queueTickets").document(ticket.id)
        val counterRef = db.collection("organizations").document(ticket.orgId)
            .collection("counters").document(ticket.counterId)
        return try {
            requireUserId()
            db.runTransaction { tx ->
                val counterSnap = tx.get(counterRef)
                val waiting = (counterSnap.getLong("waitingCount") ?: 0L).toInt()
                val wasWaiting = ticket.resolvedStatus() == TicketStatus.WAITING
                tx.update(
                    ticketRef,
                    mapOf(
                        "status" to newStatus.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (wasWaiting && newStatus.isTerminal() && waiting > 0) {
                    tx.update(
                        counterRef,
                        mapOf(
                            "waitingCount" to (waiting - 1).toLong(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ticketRef.path)
            Result.failure(e)
        }
    }

    suspend fun activateOwnerSubscription(
        org: Organization,
        planTier: PlanTier,
        gateway: PaymentGateway,
        currencyCode: String,
        monthlyPriceDisplay: String,
        status: SubscriptionStatus,
        externalRef: String = ""
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val subRef = db.collection("users").document(uid)
            .collection("subscriptions").document(org.id)
        val orgRef = db.collection("organizations").document(org.id)

        return try {
            subRef.set(
                mapOf(
                    "userId" to uid,
                    "orgId" to org.id,
                    "orgName" to org.name.take(120),
                    "planTier" to planTier.name,
                    "gateway" to gateway.name,
                    "currencyCode" to currencyCode.take(6),
                    "monthlyPriceDisplay" to monthlyPriceDisplay.take(40),
                    "status" to status.name,
                    "billingCycleDays" to 30L,
                    "activatedFromPhone" to true,
                    "externalRef" to externalRef.take(160),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (status == SubscriptionStatus.ACTIVE) {
                orgRef.update(
                    mapOf(
                        "planTier" to planTier.name,
                        "subscriptionActive" to true,
                        "currencyCode" to currencyCode.take(6),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(subRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, subRef.path)
            Result.failure(e)
        }
    }

    private suspend fun syncOrgActiveCounterCount(orgId: String, ownerId: String) {
        runCatching {
            val snap = db.collection("organizations").document(orgId)
                .collection("counters")
                .whereEqualTo("ownerId", ownerId)
                .get()
                .await()
            db.collection("organizations").document(orgId)
                .update(
                    mapOf(
                        "activeCounterCount" to snap.size().toLong(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        }
    }

    private fun extractFirestoreException(error: Throwable): FirebaseFirestoreException? =
        generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
}
