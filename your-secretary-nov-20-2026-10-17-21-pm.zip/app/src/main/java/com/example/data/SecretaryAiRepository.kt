package com.example.data

import com.example.i18n.AppLanguages
import com.example.i18n.SupportedLanguage
import com.example.model.AiActionProposal
import com.example.model.Appointment
import com.example.model.AppointmentCategory
import com.example.model.ChatMessage
import com.example.model.ExecutiveMemo
import com.example.model.PrioritizedBriefingItem
import com.example.model.ProposalKind
import com.example.model.SecretaryTask
import com.example.model.SmartBriefingContent
import com.example.model.TaskPriority
import com.example.model.UrgencyLevel
import com.example.util.DateUtils
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class SecretaryAiRepository {

    private val generalModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "You are an attentive, concise, high-caliber personal executive secretary. " +
                        "Respond clearly with actionable structure, warm professionalism, and zero filler."
                )
            }
        )
    }

    private val smartBriefingSchema = Schema.obj(
        properties = mapOf(
            "executiveSummary" to Schema.string(
                description = "2-3 concise sentences summarizing today's appointments, pending tasks, and overall day pace."
            ),
            "urgentItems" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "rank" to Schema.integer(description = "1-based priority rank (1 is most urgent)"),
                        "itemType" to Schema.enumeration(
                            values = listOf("APPOINTMENT", "TASK"),
                            description = "Whether this urgent item is a scheduled appointment or a pending task"
                        ),
                        "referenceId" to Schema.string(
                            description = "Exact ID of the matching appointment or task from the provided input, or empty string if none"
                        ),
                        "title" to Schema.string(description = "Clear title of the urgent appointment or task"),
                        "urgencyLevel" to Schema.enumeration(
                            values = listOf("CRITICAL", "HIGH", "FOCUS"),
                            description = "Urgency tier"
                        ),
                        "timeHint" to Schema.string(
                            description = "Short time or deadline cue such as '10:00 AM', 'Overdue', or 'Due Today'"
                        ),
                        "rationale" to Schema.string(
                            description = "One concise sentence explaining why this item is prioritized right now"
                        )
                    )
                ),
                description = "Top 1 to 5 urgent appointments or pending tasks ranked by immediacy, deadlines, and priority."
            ),
            "secretaryTip" to Schema.string(
                description = "One practical recommendation for managing today's schedule and focus blocks."
            )
        )
    )

    private val smartBriefingModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = smartBriefingSchema
            }
        )
    }

    private val commandSchema = Schema.obj(
        properties = mapOf(
            "kind" to Schema.enumeration(
                values = listOf("APPOINTMENT", "TASK", "MEMO"),
                description = "Whether the user wants to schedule a calendar appointment, create a task, or save a memo."
            ),
            "title" to Schema.string(description = "Concise title, max 120 characters"),
            "dateKey" to Schema.string(description = "ISO date YYYY-MM-DD based on the current date provided"),
            "startMinute" to Schema.integer(description = "Start time in minutes since midnight (0-1439). Default 540 (9:00 AM) if unspecified."),
            "endMinute" to Schema.integer(description = "End time in minutes since midnight (1-1440), strictly greater than startMinute."),
            "allDay" to Schema.boolean(description = "True only if explicitly an all-day event"),
            "category" to Schema.enumeration(
                values = listOf("MEETING", "FOCUS", "CALL", "PERSONAL", "TRAVEL"),
                description = "Best matching appointment category"
            ),
            "location" to Schema.string(description = "Location or meeting link if mentioned, otherwise empty string"),
            "attendees" to Schema.string(description = "People mentioned, comma-separated, or empty string"),
            "notes" to Schema.string(description = "Relevant details, agenda, or body text"),
            "reminderEnabled" to Schema.boolean(description = "True if a reminder is mentioned or helpful for an appointment"),
            "reminderMinutesBefore" to Schema.integer(description = "Reminder lead time in minutes (0, 10, 15, 30, 60, or 1440)"),
            "priority" to Schema.enumeration(
                values = listOf("HIGH", "NORMAL", "LOW"),
                description = "Task priority if kind is TASK"
            )
        )
    )

    private val structuredModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = commandSchema
            }
        )
    }

    suspend fun generateSmartDailyBriefing(
        todayDateKey: String,
        currentMinuteOfDay: Int,
        userName: String,
        todayAppointments: List<Appointment>,
        pendingTasks: List<SecretaryTask>,
        appLanguage: SupportedLanguage = AppLanguages.ENGLISH
    ): SmartBriefingContent {
        val currentTimeLabel = DateUtils.formatMinuteOfDay(currentMinuteOfDay)
        val apptsBlock = if (todayAppointments.isEmpty()) {
            "None scheduled today."
        } else {
            todayAppointments.joinToString("\n") { appt ->
                val time = DateUtils.formatTimeRange(appt.startMinute, appt.endMinute, appt.allDay)
                val status = if (appt.completed) "COMPLETED" else "UPCOMING/ACTIVE"
                val reminder = if (appt.reminderEnabled) "Reminder ${appt.reminderMinutesBefore}m before" else "No reminder"
                val loc = if (appt.location.isNotBlank()) "Location: ${appt.location}" else ""
                "- [ID:${appt.id}] $time | ${appt.title} | Category: ${appt.category} | $status | $reminder $loc"
            }
        }

        val tasksBlock = if (pendingTasks.isEmpty()) {
            "No pending tasks."
        } else {
            pendingTasks.take(25).joinToString("\n") { task ->
                val due = when {
                    task.dueDateKey.isBlank() -> "No due date"
                    task.dueDateKey < todayDateKey -> "OVERDUE (${task.dueDateKey})"
                    task.dueDateKey == todayDateKey -> "DUE TODAY ($todayDateKey)"
                    else -> "Due ${task.dueDateKey}"
                }
                val linked = if (task.linkedAppointmentTitle.isNotBlank()) " | Linked to: ${task.linkedAppointmentTitle}" else ""
                "- [ID:${task.id}] Priority: ${task.priority} | ${task.title} | $due$linked"
            }
        }

        val prompt = """
            Prepare a Smart Daily Briefing for $userName.
            Current date: $todayDateKey (${DateUtils.formatFullDate(todayDateKey)}), current local time: $currentTimeLabel.
            Output language for executiveSummary, timeHint, rationale, and secretaryTip: ${appLanguage.englishName} (${appLanguage.nativeName}, code ${appLanguage.code}).
            
            TODAY'S SCHEDULED APPOINTMENTS:
            $apptsBlock
            
            PENDING TASKS:
            $tasksBlock
            
            Instructions:
            - Write all natural-language text (executiveSummary, timeHint, rationale, secretaryTip) in ${appLanguage.englishName} (${appLanguage.nativeName}).
            - Aggregate today's appointments and pending tasks into a concise executiveSummary.
            - Rank the top urgent items (up to 5) in urgentItems based on:
              1. Overdue tasks or tasks due today with HIGH priority
              2. Imminent or uncompleted appointments happening soon after $currentTimeLabel
              3. Tasks linked to today's scheduled appointments
            - Preserve exact [ID:...] values in referenceId (without the "ID:" prefix). Keep itemType as APPOINTMENT or TASK and urgencyLevel as CRITICAL, HIGH, or FOCUS.
            - Provide one crisp secretaryTip for structuring focus around today's commitments.
        """.trimIndent()

        val response = withTimeout(60_000L) {
            smartBriefingModel.generateContent(prompt)
        }
        val jsonText = response.text ?: throw IllegalStateException("Secretary returned an empty briefing.")
        val json = JSONObject(jsonText)

        val summary = json.optString("executiveSummary", "").ifBlank {
            "You have ${todayAppointments.size} appointments today and ${pendingTasks.size} pending tasks."
        }
        val tip = json.optString("secretaryTip", "").ifBlank {
            "Protect a focused block before your next scheduled commitment."
        }
        val urgentJson = json.optJSONArray("urgentItems")
        val urgentList = if (urgentJson != null) {
            (0 until urgentJson.length()).map { idx ->
                val obj = urgentJson.getJSONObject(idx)
                PrioritizedBriefingItem(
                    rank = obj.optInt("rank", idx + 1),
                    itemType = obj.optString("itemType", "TASK").uppercase(),
                    referenceId = obj.optString("referenceId", ""),
                    title = obj.optString("title", "Priority Item"),
                    urgencyLevel = UrgencyLevel.fromRaw(obj.optString("urgencyLevel", "HIGH")),
                    timeHint = obj.optString("timeHint", "Today"),
                    rationale = obj.optString("rationale", "")
                )
            }.sortedBy { it.rank }
        } else {
            emptyList()
        }

        return SmartBriefingContent(
            executiveSummary = summary,
            urgentItems = urgentList,
            secretaryTip = tip
        )
    }

    fun streamDailyBriefing(
        todayDateKey: String,
        userName: String,
        appointments: List<Appointment>,
        tasks: List<SecretaryTask>,
        memos: List<ExecutiveMemo>
    ): Flow<String> = flow {
        val scheduleSummary = buildScheduleContext(todayDateKey, appointments, tasks, memos)
        val prompt = """
            Prepare a crisp, executive morning briefing for $userName for today (${DateUtils.formatFullDate(todayDateKey)}, $todayDateKey).
            
            Current workspace state:
            $scheduleSummary
            
            Format with 3 short, scannable sections using plain bullets (no heavy markdown tables):
            1. Today's Flow & Key Time Blocks
            2. Priority Actions & Deadlines
            3. Secretary Prep Tip (one practical suggestion based on the day's density or gaps)
            Keep it concise (under 180 words).
        """.trimIndent()

        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            generalModel.generateContentStream(prompt).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
        }
    }

    suspend fun parseNaturalLanguageCommand(
        userInput: String,
        todayDateKey: String
    ): AiActionProposal {
        val dayName = DateUtils.dayOfWeekShort(todayDateKey)
        val prompt = """
            Current local date: $todayDateKey ($dayName).
            Parse this executive assistant request into a structured calendar appointment, task, or memo:
            "$userInput"
            
            Rules:
            - Resolve relative dates like "today", "tomorrow", or weekdays accurately against $todayDateKey.
            - Convert times to minutes from midnight (e.g., 9:00 AM = 540, 1:30 PM = 810). Default duration is 60 minutes if only start time is given.
            - Enable reminderEnabled=true with reminderMinutesBefore=15 for appointments unless the user specifies another lead time or explicitly disables reminders.
        """.trimIndent()

        val response = withTimeout(60_000L) {
            structuredModel.generateContent(prompt)
        }
        val jsonText = response.text ?: throw IllegalStateException("Secretary returned an empty response.")
        val json = JSONObject(jsonText)

        val kind = when (json.optString("kind", "APPOINTMENT").uppercase()) {
            "TASK" -> ProposalKind.TASK
            "MEMO" -> ProposalKind.MEMO
            else -> ProposalKind.APPOINTMENT
        }
        val rawDateKey = json.optString("dateKey", todayDateKey)
        val safeDateKey = if (DateUtils.isValidDateKey(rawDateKey)) rawDateKey else todayDateKey
        val allDay = json.optBoolean("allDay", false)
        val startMin = if (allDay) 0 else json.optInt("startMinute", 540).coerceIn(0, 1380)
        val endMin = if (allDay) 1440 else json.optInt("endMinute", startMin + 60).coerceIn(startMin + 15, 1440)
        val reminderMin = json.optInt("reminderMinutesBefore", 15).coerceIn(0, 10080)

        return AiActionProposal(
            kind = kind,
            title = json.optString("title", userInput.take(80)).ifBlank { userInput.take(80) }.take(120),
            dateKey = safeDateKey,
            startMinute = startMin,
            endMinute = endMin,
            allDay = allDay,
            category = AppointmentCategory.fromRaw(json.optString("category", "MEETING")),
            location = json.optString("location", "").take(200),
            attendees = json.optString("attendees", "").take(300),
            notes = json.optString("notes", "").take(1000),
            reminderEnabled = json.optBoolean("reminderEnabled", true),
            reminderMinutesBefore = reminderMin,
            priority = TaskPriority.fromRaw(json.optString("priority", "NORMAL"))
        )
    }

    fun streamSecretaryChat(
        history: List<ChatMessage>,
        userMessage: String,
        todayDateKey: String,
        appointments: List<Appointment>,
        tasks: List<SecretaryTask>,
        memos: List<ExecutiveMemo>,
        appLanguage: SupportedLanguage = AppLanguages.ENGLISH
    ): Flow<String> = flow {
        val scheduleContext = buildScheduleContext(todayDateKey, appointments, tasks, memos)
        val systemPreamble = """
            Today's date is $todayDateKey (${DateUtils.formatFullDate(todayDateKey)}).
            User's preferred app language is ${appLanguage.englishName} (${appLanguage.nativeName}, code ${appLanguage.code}).
            Respond in the language the user writes in, or default to ${appLanguage.englishName} (${appLanguage.nativeName}) if unclear. If the user asks to translate or speak in another language, follow their request immediately.
            User's current calendar, tasks, and memos:
            $scheduleContext
        """.trimIndent()

        val chatHistory = buildList {
            add(content("user") { text("Context for my schedule:\n$systemPreamble") })
            add(content("model") { text("Understood. I have your current calendar, tasks, and memos ready and can assist or translate in any language.") })
            history.filter { !it.isStreaming && !it.isError && it.text.isNotBlank() }
                .takeLast(10)
                .forEach { msg ->
                    add(content(if (msg.isUser) "user" else "model") { text(msg.text) })
                }
        }

        val chat = generalModel.startChat(history = chatHistory)
        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            chat.sendMessageStream(userMessage).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
        }
    }

    fun streamMemoFollowUpDraft(
        title: String,
        body: String,
        appLanguage: SupportedLanguage = AppLanguages.ENGLISH
    ): Flow<String> = flow {
        val prompt = """
            Based on this executive memo, draft a concise, polished follow-up email or action summary ready to send.
            Write the draft in ${appLanguage.englishName} (${appLanguage.nativeName}) unless the memo clearly dictates another target language.
            Include a clear Subject line, brief greeting, key points / next steps, and a professional closing.
            
            Memo Title: $title
            Memo Notes:
            $body
        """.trimIndent()

        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            generalModel.generateContentStream(prompt).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
        }
    }

    suspend fun translateText(
        text: String,
        targetLanguage: SupportedLanguage,
        sourceLanguageHint: SupportedLanguage? = null
    ): String {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return ""
        val sourceClause = if (sourceLanguageHint != null) {
            "from ${sourceLanguageHint.englishName} (${sourceLanguageHint.nativeName}) "
        } else {
            ""
        }
        val prompt = """
            Translate the following message ${sourceClause}into ${targetLanguage.englishName} (${targetLanguage.nativeName}, code ${targetLanguage.code}).
            Preserve the original tone, formatting, names, numbers, and bullet points accurately.
            Return ONLY the translated text with no commentary or quotation marks.

            Message:
            $trimmed
        """.trimIndent()

        val response = withTimeout(60_000L) {
            generalModel.generateContent(prompt)
        }
        return response.text?.trim()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Translation returned empty output.")
    }

    suspend fun translateConversationBlock(
        transcript: String,
        targetLanguage: SupportedLanguage
    ): String {
        val trimmed = transcript.trim()
        if (trimmed.isBlank()) return ""
        val prompt = """
            Translate every turn of the following conversation or chat transcript into ${targetLanguage.englishName} (${targetLanguage.nativeName}, code ${targetLanguage.code}).
            Preserve speaker names, timestamps, and line breaks cleanly so each message remains easy to follow.
            Return ONLY the translated conversation without extra commentary.

            Conversation:
            $trimmed
        """.trimIndent()

        val response = withTimeout(60_000L) {
            generalModel.generateContent(prompt)
        }
        return response.text?.trim()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Conversation translation returned empty output.")
    }

    suspend fun translateUiStrings(
        targetLanguage: SupportedLanguage,
        sourceStrings: Map<String, String>
    ): Map<String, String> {
        val schema = Schema.obj(
            properties = sourceStrings.keys.associateWith { key ->
                Schema.string(description = "Translation of '$key'")
            }
        )
        val model = Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            }
        )
        val inputJson = JSONObject()
        sourceStrings.forEach { (k, v) -> inputJson.put(k, v) }

        val prompt = """
            Translate all values in this JSON UI string table from English into ${targetLanguage.englishName} (${targetLanguage.nativeName}, code ${targetLanguage.code}).
            Keep keys identical, keep UI labels natural and concise, and preserve placeholders/ellipsis where appropriate.
            JSON:
            $inputJson
        """.trimIndent()

        val response = withTimeout(60_000L) {
            model.generateContent(prompt)
        }
        val raw = response.text ?: throw IllegalStateException("Empty UI translation response.")
        val json = JSONObject(raw)
        return buildMap {
            sourceStrings.keys.forEach { key ->
                val value = json.optString(key, "")
                if (value.isNotBlank()) put(key, value)
            }
        }
    }

    suspend fun smartMatchOrganizations(
        query: String,
        organizations: List<com.example.model.Organization>,
        appLanguage: SupportedLanguage = AppLanguages.ENGLISH
    ): List<String> {
        val trimmed = query.trim()
        if (trimmed.isBlank() || organizations.isEmpty()) return organizations.map { it.id }

        val orgListBlock = organizations.take(40).joinToString("\n") { org ->
            "- [ID:${org.id}] Name: ${org.name} | Sector: ${org.sector} | Profession: ${org.profession} | City: ${org.city} | Desc: ${org.description.take(120)}"
        }
        val schema = Schema.obj(
            properties = mapOf(
                "matchedIds" to Schema.array(
                    items = Schema.string(description = "Exact ID of matching organization"),
                    description = "Ordered list of most relevant organization IDs from the provided directory."
                )
            )
        )
        val model = Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            }
        )
        val prompt = """
            User query (${appLanguage.englishName}): "$trimmed"
            Match the user's intent (company, medical clinic, hospital, factory, personal interview, legal, etc.) against these cloud organizations and return the matching IDs ranked by relevance:
            $orgListBlock
        """.trimIndent()

        val response = withTimeout(45_000L) { model.generateContent(prompt) }
        val json = JSONObject(response.text ?: return emptyList())
        val arr = json.optJSONArray("matchedIds") ?: return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val id = arr.optString(i, "")
                if (id.isNotBlank()) add(id)
            }
        }
    }

    private fun buildScheduleContext(
        todayDateKey: String,
        appointments: List<Appointment>,
        tasks: List<SecretaryTask>,
        memos: List<ExecutiveMemo>
    ): String {
        val upcomingAppointments = appointments
            .filter { it.dateKey >= todayDateKey && !it.completed }
            .take(15)
        val openTasks = tasks.filter { !it.completed }.take(12)
        val pinnedMemos = memos.filter { it.pinned }.take(5)

        return buildString {
            appendLine("Upcoming Appointments (${upcomingAppointments.size}):")
            if (upcomingAppointments.isEmpty()) {
                appendLine("- None scheduled")
            } else {
                upcomingAppointments.forEach { appt ->
                    val time = DateUtils.formatTimeRange(appt.startMinute, appt.endMinute, appt.allDay)
                    val reminder = if (appt.reminderEnabled) " [Reminder: ${DateUtils.formatReminderLabel(appt.reminderMinutesBefore)}]" else ""
                    val loc = if (appt.location.isNotBlank()) " @ ${appt.location}" else ""
                    appendLine("- ${appt.dateKey} $time: ${appt.title} (${appt.category})$loc$reminder")
                }
            }
            appendLine()
            appendLine("Open Action Items (${openTasks.size}):")
            if (openTasks.isEmpty()) {
                appendLine("- All caught up")
            } else {
                openTasks.forEach { task ->
                    val due = if (task.dueDateKey.isNotBlank()) " (Due ${task.dueDateKey})" else ""
                    appendLine("- [${task.priority}] ${task.title}$due")
                }
            }
            if (pinnedMemos.isNotEmpty()) {
                appendLine()
                appendLine("Pinned Memos:")
                pinnedMemos.forEach { memo ->
                    appendLine("- ${memo.title}: ${memo.body.take(120)}")
                }
            }
        }
    }
}
