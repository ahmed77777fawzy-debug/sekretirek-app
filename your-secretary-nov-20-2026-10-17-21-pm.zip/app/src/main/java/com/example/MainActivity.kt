package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.QueueRepository
import com.example.data.SecretaryAiRepository
import com.example.data.SecretaryRepository
import com.example.firebase.configureAppCheck
import com.example.i18n.CurrencyManager
import com.example.i18n.LanguageManager
import com.example.i18n.LocalAppCurrency
import com.example.i18n.LocalAppLanguage
import com.example.i18n.LocalAppStrings
import com.example.notifications.ReminderScheduler
import com.example.ui.MainScaffold
import com.example.ui.screens.AuthScreen
import com.example.ui.theme.YourSecretaryTheme
import com.example.viewmodel.QueueViewModel
import com.example.viewmodel.SecretaryViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before UI, ViewModels, or Firebase calls
        configureAppCheck(this, intent)

        // STEP 2: Enable Edge-to-Edge & Render Compose UI
        enableEdgeToEdge()
        setContent {
            YourSecretaryTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val languageManager = remember(context.applicationContext) {
        LanguageManager(
            context = context.applicationContext,
            aiRepository = SecretaryAiRepository()
        )
    }
    val currencyManager = remember(context.applicationContext) {
        CurrencyManager(context = context.applicationContext)
    }
    val appLanguage by languageManager.appLanguage.collectAsStateWithLifecycle()
    val appStrings by languageManager.appStrings.collectAsStateWithLifecycle()
    val isTranslatingUi by languageManager.isTranslatingUi.collectAsStateWithLifecycle()
    val appCurrency by currencyManager.selectedCurrency.collectAsStateWithLifecycle()
    val layoutDirection = if (appLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    CompositionLocalProvider(
        LocalAppLanguage provides appLanguage,
        LocalAppStrings provides appStrings,
        LocalAppCurrency provides appCurrency,
        LocalLayoutDirection provides layoutDirection
    ) {
        val user = currentUser
        if (user == null) {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                },
                isTranslatingUi = isTranslatingUi,
                onSelectLanguage = languageManager::selectAppLanguage
            )
        } else {
            val uid = user.uid
            key(uid) {
                AuthenticatedSecretaryHost(
                    user = user,
                    languageManager = languageManager,
                    currencyManager = currencyManager
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedSecretaryHost(
    user: FirebaseUser,
    languageManager: LanguageManager,
    currencyManager: CurrencyManager
) {
    val uid = user.uid
    val displayName = user.displayName?.takeIf { it.isNotBlank() } ?: "Executive"
    val userEmail = user.email.orEmpty()
    val appLanguage by languageManager.appLanguage.collectAsStateWithLifecycle()

    val viewModel: SecretaryViewModel = viewModel(
        key = "secretary_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                SecretaryViewModel(
                    repository = SecretaryRepository(db),
                    aiRepository = SecretaryAiRepository(),
                    reminderScheduler = ReminderScheduler(app),
                    currentUserId = uid,
                    userDisplayName = displayName
                )
            }
        }
    )

    val queueViewModel: QueueViewModel = viewModel(
        key = "queue_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                QueueViewModel(
                    repository = QueueRepository(db),
                    aiRepository = SecretaryAiRepository(),
                    currentUserId = uid,
                    userDisplayName = displayName
                )
            }
        }
    )

    LaunchedEffect(appLanguage) {
        viewModel.updateAppLanguage(appLanguage)
        queueViewModel.updateAppLanguage(appLanguage)
    }

    MainScaffold(
        viewModel = viewModel,
        queueViewModel = queueViewModel,
        languageManager = languageManager,
        currencyManager = currencyManager,
        userEmail = userEmail
    )
}
