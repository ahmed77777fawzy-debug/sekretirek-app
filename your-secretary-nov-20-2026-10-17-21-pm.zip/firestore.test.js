const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write appointments, tasks, memos, contacts, organizations, counters, tickets, or subscriptions", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection(`users/${ALICE_UID}/appointments`).get()
  );
  await assertFails(
    unauthDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").set({
      userId: ALICE_UID,
      title: "Unauthorized",
      dateKey: "2026-11-20",
      startMinute: 540,
      endMinute: 600,
      allDay: false,
      category: "MEETING",
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      completed: false,
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/tasks`).get());
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/memos`).get());
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/contacts`).get());
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/subscriptions`).get());
  await assertFails(unauthDb.collection("organizations").where("listedPublicly", "==", true).get());
  await assertFails(unauthDb.collection("queueTickets").where("visitorId", "==", ALICE_UID).get());
});

test("Owner: valid Kotlin appointment with linkedContactIds create, partial update, and delete succeed; invalid payloads fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").set({
      userId: ALICE_UID,
      title: "Quarterly Board Sync",
      dateKey: "2026-11-20",
      startMinute: 600,
      endMinute: 660,
      allDay: false,
      category: "MEETING",
      location: "Conference Room B",
      attendees: "Elena Rostova, Marcus Vance",
      linkedContactIds: ["contact_1", "contact_2"],
      notes: "Bring Q4 forecast",
      reminderEnabled: true,
      reminderMinutesBefore: 30,
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").update({
      completed: true,
      linkedContactIds: ["contact_1"],
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field & @DocumentId 'id' injection
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_2").set({
      id: "appt_2",
      userId: ALICE_UID,
      title: "Shadow",
      dateKey: "2026-11-20",
      startMinute: 600,
      endMinute: 660,
      allDay: false,
      category: "MEETING",
      reminderEnabled: false,
      reminderMinutesBefore: 0,
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject endMinute <= startMinute
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_3").set({
      userId: ALICE_UID,
      title: "Invalid time",
      dateKey: "2026-11-20",
      startMinute: 700,
      endMinute: 600,
      allDay: false,
      category: "CALL",
      reminderEnabled: false,
      reminderMinutesBefore: 0,
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject immutable createdAt mutation
  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/appointments`).doc("appt_1").delete()
  );
});

test("Cross-user isolation: Bob cannot read or modify Alice's appointments, tasks, memos, contacts, or subscriptions", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const now = new Date(Date.now() - 10000);
    await db.collection(`users/${ALICE_UID}/appointments`).doc("a1").set({
      userId: ALICE_UID,
      title: "Confidential 1:1",
      dateKey: "2026-11-20",
      startMinute: 540,
      endMinute: 570,
      allDay: false,
      category: "MEETING",
      reminderEnabled: true,
      reminderMinutesBefore: 10,
      completed: false,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/tasks`).doc("t1").set({
      userId: ALICE_UID,
      title: "Review contract",
      priority: "HIGH",
      completed: false,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/memos`).doc("m1").set({
      userId: ALICE_UID,
      title: "Board Notes",
      body: "Key takeaways",
      pinned: true,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/contacts`).doc("c1").set({
      userId: ALICE_UID,
      name: "Elena Rostova",
      role: "VP Strategy",
      company: "Northstar Capital",
      email: "elena@northstar.example",
      phone: "+1 555-0192",
      category: "CLIENT",
      notes: "Prefers morning briefings",
      favorite: true,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection(`users/${ALICE_UID}/subscriptions`).doc("sub_1").set({
      userId: ALICE_UID,
      orgId: "org_1",
      orgName: "Al-Noor Clinic",
      planTier: "PRO",
      gateway: "STRIPE",
      currencyCode: "USD",
      monthlyPriceDisplay: "$19.00",
      status: "ACTIVE",
      billingCycleDays: 30,
      activatedFromPhone: true,
      createdAt: now,
      updatedAt: now,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection(`users/${ALICE_UID}/appointments`).get());
  await assertFails(
    bobDb.collection(`users/${ALICE_UID}/appointments`).doc("a1").get()
  );
  await assertFails(
    bobDb
      .collection(`users/${ALICE_UID}/appointments`)
      .doc("a1")
      .update({ title: "Hijacked" })
  );
  await assertFails(bobDb.collection(`users/${ALICE_UID}/tasks`).get());
  await assertFails(bobDb.collection(`users/${ALICE_UID}/memos`).get());
  await assertFails(bobDb.collection(`users/${ALICE_UID}/contacts`).get());
  await assertFails(
    bobDb.collection(`users/${ALICE_UID}/contacts`).doc("c1").get()
  );
  await assertFails(bobDb.collection(`users/${ALICE_UID}/subscriptions`).get());

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/appointments`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/tasks`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/memos`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/contacts`).get());
  await assertSucceeds(aliceDb.collection(`users/${ALICE_UID}/subscriptions`).get());
});

test("Owner: task creation, agenda linking, editing, and completion succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/tasks`).doc("task_1").set({
      userId: ALICE_UID,
      title: "Prepare quarterly deck",
      details: "Include revenue slides",
      dueDateKey: "2026-11-20",
      linkedAppointmentId: "appt_1",
      linkedAppointmentTitle: "Quarterly Board Sync",
      priority: "HIGH",
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/tasks`).doc("task_1").update({
      completed: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/tasks`).doc("task_1").update({
      userId: BOB_UID,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Owner: contact create, favorite update, delete, and invalid schema rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_1").set({
      userId: ALICE_UID,
      name: "Marcus Vance",
      role: "General Counsel",
      company: "Vance Advisory",
      email: "marcus@vance.example",
      phone: "+1 555-0148",
      location: "450 Market St, San Francisco",
      category: "LEADERSHIP",
      notes: "Send agenda 24h prior",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_1").update({
      favorite: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_long_loc").set({
      userId: ALICE_UID,
      name: "Long Location",
      location: "x".repeat(201),
      category: "PERSONAL",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_bad").set({
      userId: ALICE_UID,
      name: "Invalid Group",
      category: "UNKNOWN_GROUP",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertFails(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_ghost").set({
      id: "contact_ghost",
      userId: ALICE_UID,
      name: "Ghost Field",
      category: "PERSONAL",
      favorite: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/contacts`).doc("contact_1").delete()
  );
});

test("Cloud Queue: owner creates org & counter, public directory query obeys listedPublicly, visitor books zero-fee ticket & cancels atomically", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  // Alice creates a public clinic organization
  await assertSucceeds(
    aliceDb.collection("organizations").doc("org_clinic").set({
      ownerId: ALICE_UID,
      ownerName: "Dr. Alice",
      name: "Al-Noor Dental Clinic",
      sector: "CLINIC",
      profession: "Dental Surgery",
      description: "Digital implant & family dentistry",
      city: "Riyadh",
      address: "Olaya District, Tower 4",
      deskPhone: "+966 11 555 0100",
      workingHours: "09:00 - 21:00",
      currencyCode: "SAR",
      planTier: "STARTER",
      subscriptionActive: true,
      acceptingBookings: true,
      listedPublicly: true,
      maxDailyCapacity: 120,
      activeCounterCount: 1,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice creates a private (unlisted) factory organization
  await assertSucceeds(
    aliceDb.collection("organizations").doc("org_private").set({
      ownerId: ALICE_UID,
      ownerName: "Alice Ops",
      name: "Internal Plant Gate",
      sector: "FACTORY",
      profession: "Logistics Receiving",
      currencyCode: "USD",
      planTier: "PRO",
      subscriptionActive: true,
      acceptingBookings: true,
      listedPublicly: false,
      maxDailyCapacity: 80,
      activeCounterCount: 0,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Unfiltered blanket list on organizations must FAIL for Bob
  await assertFails(bobDb.collection("organizations").get());

  // Filtered public list must SUCCEED for Bob
  await assertSucceeds(
    bobDb.collection("organizations").where("listedPublicly", "==", true).get()
  );

  // Bob cannot get Alice's unlisted org or modify Alice's public org
  await assertFails(bobDb.collection("organizations").doc("org_private").get());
  await assertFails(
    bobDb.collection("organizations").doc("org_clinic").update({
      name: "Hacked Clinic",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Alice creates Counter A under org_clinic
  await assertSucceeds(
    aliceDb
      .collection("organizations/org_clinic/counters")
      .doc("counter_a")
      .set({
        orgId: "org_clinic",
        ownerId: ALICE_UID,
        listedPublicly: true,
        name: "Reception Desk A",
        serviceTrack: "General Checkup",
        prefix: "A",
        avgServiceMinutes: 10,
        maxWaitingLimit: 25,
        open: true,
        acceptingQueue: true,
        acceptingAppointments: true,
        currentServingNumber: 0,
        lastIssuedNumber: 0,
        waitingCount: 0,
        dateKey: "2026-11-20",
        createdAt: created,
        updatedAt: created,
      })
  );

  // Bob reads public counters
  await assertSucceeds(
    bobDb
      .collection("organizations/org_clinic/counters")
      .where("listedPublicly", "==", true)
      .get()
  );

  // Bob atomically increments counter_a (+1) & books zero-fee ticket
  await assertSucceeds(
    bobDb.collection("organizations/org_clinic/counters").doc("counter_a").update({
      lastIssuedNumber: 1,
      waitingCount: 1,
      dateKey: "2026-11-20",
      updatedAt: new Date(Date.now() - 2000),
    })
  );

  // Bob cannot jump counter by +5
  await assertFails(
    bobDb.collection("organizations/org_clinic/counters").doc("counter_a").update({
      lastIssuedNumber: 6,
      waitingCount: 2,
      dateKey: "2026-11-20",
      updatedAt: new Date(Date.now() - 1500),
    })
  );

  // Bob creates his queue ticket (bookingFeePaid MUST be 0)
  await assertSucceeds(
    bobDb.collection("queueTickets").doc("ticket_1").set({
      visitorId: BOB_UID,
      visitorName: "Bob Visitor",
      visitorPhone: "+966 50 000 0000",
      visitorNotes: "Annual checkup",
      orgId: "org_clinic",
      orgName: "Al-Noor Dental Clinic",
      orgSector: "CLINIC",
      orgOwnerId: ALICE_UID,
      counterId: "counter_a",
      counterName: "Reception Desk A",
      bookingType: "WALK_IN",
      dateKey: "2026-11-20",
      slotLabel: "Walk-In",
      ticketNumber: 1,
      ticketCode: "A-001",
      bookingFeePaid: 0,
      status: "WAITING",
      estimatedWaitMinutes: 10,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject charging visitor a booking fee (>0)
  await assertFails(
    bobDb.collection("queueTickets").doc("ticket_fee").set({
      visitorId: BOB_UID,
      visitorName: "Bob Visitor",
      orgId: "org_clinic",
      orgName: "Al-Noor Dental Clinic",
      orgSector: "CLINIC",
      orgOwnerId: ALICE_UID,
      counterId: "counter_a",
      counterName: "Reception Desk A",
      bookingType: "WALK_IN",
      dateKey: "2026-11-20",
      ticketNumber: 2,
      ticketCode: "A-002",
      bookingFeePaid: 5,
      status: "WAITING",
      estimatedWaitMinutes: 20,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Unfiltered queueTickets list must FAIL
  await assertFails(bobDb.collection("queueTickets").get());

  // Filtered visitor list & owner list SUCCEED
  await assertSucceeds(
    bobDb.collection("queueTickets").where("visitorId", "==", BOB_UID).get()
  );
  await assertSucceeds(
    aliceDb.collection("queueTickets").where("orgOwnerId", "==", ALICE_UID).get()
  );

  // Alice calls ticket -> CALLED -> COMPLETED
  await assertSucceeds(
    aliceDb.collection("queueTickets").doc("ticket_1").update({
      status: "CALLED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(
    aliceDb.collection("queueTickets").doc("ticket_1").update({
      status: "COMPLETED",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Terminal state lock: once COMPLETED, ticket cannot be mutated again
  await assertFails(
    aliceDb.collection("queueTickets").doc("ticket_1").update({
      status: "WAITING",
      updatedAt: new Date(Date.now() - 200),
    })
  );
});
